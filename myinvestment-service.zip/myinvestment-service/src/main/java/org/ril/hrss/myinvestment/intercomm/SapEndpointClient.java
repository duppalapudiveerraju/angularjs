package org.ril.hrss.myinvestment.intercomm;

import javax.validation.constraints.NotNull;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.GET, value = "/sap/myInvestment/financialyear")
	String getfinancialYear(@NotNull @RequestHeader("userID") String userId);

}
