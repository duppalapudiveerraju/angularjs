package org.ril.hrss.myinvestment.util;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.logging.Logger;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.ril.hrss.myinvestment.intercomm.SapEndpointClient;
import org.ril.hrss.myinvestment.model.FinancialVideo;
import org.ril.hrss.myinvestment.model.FinancialYear;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MyInvestmentUtil {

	protected static final Logger logger = Logger.getLogger(MyInvestmentUtil.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public FinancialYear getfinancialYear(String userId) {
		logger.info("MyInvestmentUtil.getfinancialYear()");
		return getfinancialYearDetailObjectMapped(sapEndpointClient.getfinancialYear(userId));
	}

	private FinancialYear getfinancialYearDetailObjectMapped(String feed) {
		logger.info("MyInvestmentUtil.getfinancialYearDetailObjectMapped()");
		FinancialYear result = new FinancialYear();
		try {
			ObjectMapper objectMapper = objectMapperUtil.get();
			JsonNode rootNode = objectMapper.readTree(feed);
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
			objectMapper.setDateFormat(df);
			result = objectMapper.readValue(rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).toString(),
					FinancialYear.class);

			String endValue = String.valueOf(result.getEndFinancialYear());
			result.setFinalYear(result.getStartFinancialYear() + "-" + endValue.substring(2, 4));
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return result;
	}

	public FinancialVideo getfinancialVideos(String userId) {

		FinancialVideo videoPlayList = new FinancialVideo();
		String jsonStr = getFinancialVideoJSONString();
		try {
			if (jsonStr != null && !jsonStr.isEmpty()) {
				ObjectMapper objectMapper = objectMapperUtil.get();
				videoPlayList = objectMapper.readValue(jsonStr, new TypeReference<FinancialVideo>() {
				});
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
		}

		return videoPlayList;
	}

	private String getFinancialVideoJSONString() {

		StringBuilder result = new StringBuilder(HRSSConstantUtil.EMPTY_STRING);
		String fileName = "file/finacialvideolist.txt";

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(fileName).getFile());
		try (Scanner scanner = new Scanner(file)) {

			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				result.append(line);//.append("\n");
			}
			scanner.close();
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return result.toString();
	}
}