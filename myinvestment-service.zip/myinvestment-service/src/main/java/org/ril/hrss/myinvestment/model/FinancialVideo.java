package org.ril.hrss.myinvestment.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FinancialVideo {
	private String id;
	private String name;
	private String description;
	private String mediaType;
	private String duration;
	private String url;
	private String sequenceNumber;

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("description")
	public String getDescription() {
		return description;
	}

	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}

	@JsonProperty("mediaType")
	public String getMediaType() {
		return mediaType;
	}

	@JsonProperty("mediaType")
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}

	@JsonProperty("duration")
	public String getDuration() {
		return duration;
	}

	@JsonProperty("duration")
	public void setDuration(String duration) {
		this.duration = duration;
	}

	@JsonProperty("url")
	public String getUrl() {
		return url;
	}

	@JsonProperty("url")
	public void setUrl(String url) {
		this.url = url;
	}

	@JsonProperty("sequenceNumber")
	public String getSequenceNumber() {
		return sequenceNumber;
	}

	@JsonProperty("sequenceNumber")
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	@Override
	public String toString() {
		return "FinancialVideo [id=" + id + ", name=" + name + ", description=" + description + ", mediaType="
				+ mediaType + ", duration=" + duration + ", url=" + url + ", sequenceNumber=" + sequenceNumber + "]";
	}

}
