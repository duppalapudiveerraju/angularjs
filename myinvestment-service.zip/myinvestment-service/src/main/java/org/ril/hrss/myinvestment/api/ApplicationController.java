package org.ril.hrss.myinvestment.api;

import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.myinvestment.model.FinancialVideo;
import org.ril.hrss.myinvestment.model.FinancialYear;
import org.ril.hrss.myinvestment.util.MyInvestmentUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/myInvestment")
@Api(value = " myInvestment details", description = "Operations pertaining to find myInvestment details")
public class ApplicationController {

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());
	@Autowired
	private MyInvestmentUtil myInvestmentUtil;

	@RequestMapping(value = "/financialyear", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get the current finacial year.", response = FinancialYear.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved current finacial year"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public FinancialYear getfinancialYear(@NotNull @RequestHeader("userID") String userId) {
		logger.info("myinverstment-service-controller.getfinancialYear()");
		return myInvestmentUtil.getfinancialYear(userId);
	}

	@RequestMapping(value = "/financialvideos", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of financial year  videos for myInvestment", response = FinancialVideo.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved current finacial videos"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public FinancialVideo getfinancialVideos(@NotNull @RequestHeader("userID") String userId) {
		logger.info("myinverstment-service-controller.getfinancialVideos()");
		return myInvestmentUtil.getfinancialVideos(userId);
	}

}
