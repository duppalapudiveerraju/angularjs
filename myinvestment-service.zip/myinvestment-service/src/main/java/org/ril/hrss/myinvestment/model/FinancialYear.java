package org.ril.hrss.myinvestment.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FinancialYear {

	private int startFinancialYear;

	private int endFinancialYear;

	private String finalYear;

	public String getFinalYear() {
		return finalYear;
	}

	public void setFinalYear(String finalYear) {
		this.finalYear = finalYear;
	}

	public FinancialYear() {

	}

	@JsonProperty("SYear")
	public int getStartFinancialYear() {
		return startFinancialYear;
	}

	public void setStartFinancialYear(int startFinancialYear) {
		this.startFinancialYear = startFinancialYear;
	}

	@JsonProperty("EYear")
	public int getEndFinancialYear() {
		return endFinancialYear;
	}

	public void setEndFinancialYear(int endFinancialYear) {
		this.endFinancialYear = endFinancialYear;
	}

	@Override
	public String toString() {
		return "FinencialYearDetails [startFinancialYear=" + startFinancialYear + ", endFinancialYear="
				+ endFinancialYear + "]";
	}

}
