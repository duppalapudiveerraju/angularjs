package org.ril.hrss.form12bb.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Form12BBDTO {

	@JsonProperty("Action")
	private String action;

	public Form12BBDTO() {
		super();
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "Form12BBDTO [action=" + action + "]";
	}

}