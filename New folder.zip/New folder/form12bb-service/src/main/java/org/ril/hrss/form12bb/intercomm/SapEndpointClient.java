package org.ril.hrss.form12bb.intercomm;

import java.util.Map;

import javax.validation.constraints.NotNull;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.GET, value = "/sap/form12bb/details", produces = "application/json")
	String getForm12BBDetails(@NotNull @RequestHeader("userId") String userId);

	@RequestMapping(method = RequestMethod.GET, value = "/sap/form12bb/letter", produces = "application/octet-stream")
	ResponseEntity<Resource> getForm12bbLetter(@NotNull @RequestHeader("userId") String userId);

	@RequestMapping(method = RequestMethod.POST, value = "/sap/form12bb/save", produces = "application/json", consumes = "application/json")
	Map<String, String> saveForm12bb(@NotNull @RequestHeader("userId") String userId, @RequestBody String form12bbStr);
}