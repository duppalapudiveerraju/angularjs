package org.ril.hrss.form12bb.intercomm;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getForm12BBDetails(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public ResponseEntity<Resource> getForm12bbLetter(String userId) {
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Override
	public Map<String, String> saveForm12bb(String userId, String form12bbStr) {
		return new HashMap<String, String>();
	}
}