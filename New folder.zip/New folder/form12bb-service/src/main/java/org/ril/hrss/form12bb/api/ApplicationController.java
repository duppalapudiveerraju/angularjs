package org.ril.hrss.form12bb.api;

import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.form12bb.model.Form12BB;
import org.ril.hrss.form12bb.model.Form12BBDTO;
import org.ril.hrss.form12bb.util.Form12BBUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import feign.FeignException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Form12BB", description = "Operations pertaining to find Form12BB")
public class ApplicationController {

	@Autowired
	private Form12BBUtil form12BBUtil;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	@RequestMapping(value = "/details", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View details of Form12BB", response = Form12BB.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public Form12BB getForm12BBDetails(@NotNull @RequestHeader("userId") String userId) throws ClientException {
		logger.info("form12BB-service-controller.getForm12BBDetails()");
		return form12BBUtil.getForm12BBDetails(userId);
	}

	@RequestMapping(value = "/letter", method = RequestMethod.GET, produces = "application/octet-stream")
	@ApiOperation(value = "Get Form12bb Letter", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrived Letter"),
			@ApiResponse(code = 204, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Resource> getForm12bbLetter(@NotNull @RequestHeader("userId") String userId)
			throws FeignException, ClientException {
		logger.info("form12BB-service-controller.getForm12bbLetter()");
		return form12BBUtil.getForm12bbLetter(userId);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save Form 12 BB Details", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully saved form 12 bb details"),
			@ApiResponse(code = 201, message = "Successfully saved form 12 bb details"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Form12BBDTO> saveHouseRentDec(@NotNull @RequestHeader("userID") String userId,
			@RequestBody Form12BBDTO input) throws ClientException {
		logger.info("form12BB-service-controller.saveForm12BBDetails()");
		return form12BBUtil.saveForm12bb(userId, input);
	}

}