package org.ril.hrss.form12bb.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.DoubleToStrSerializer;
import org.ril.hrss.msf.custom.serializer.EmptyStringSerializer;
import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class Form12BB {

	private String pernr;
	private Date fsDate;
	private Date feDate;
	private String fYear;
	private Double invAmt;
	private String status;
	private String statusDesc;
	private boolean dispFlag;
	private boolean editFlag;
	private boolean printFlag;
	private boolean tabFlag;
	private boolean dataFlag;
	private boolean createFlag;

	public Form12BB() {
		super();
	}

	@JsonProperty("Pernr")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getPernr() {
		return pernr;
	}

	@JsonProperty("Pernr")
	public void setPernr(String pernr) {
		this.pernr = pernr;
	}

	@JsonProperty("Fsdate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public Date getFsDate() {
		return fsDate;
	}

	@JsonProperty("Fsdate")
	public void setFsDate(Date fsDate) {
		this.fsDate = fsDate;
	}

	@JsonProperty("Fedate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public Date getFeDate() {
		return feDate;
	}

	@JsonProperty("Fedate")
	public void setFeDate(Date feDate) {
		this.feDate = feDate;
	}

	@JsonProperty("Fyear")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getfYear() {
		return fYear;
	}

	@JsonProperty("Fyear")
	public void setfYear(String fYear) {
		this.fYear = fYear;
	}

	@JsonProperty("Invamt")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	public Double getInvAmt() {
		return invAmt;
	}

	@JsonProperty("Invamt")
	public void setInvAmt(Double invAmt) {
		this.invAmt = invAmt;
	}

	@JsonProperty("Status")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getStatus() {
		return status;
	}

	@JsonProperty("Status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("StatusDesc")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getStatusDesc() {
		return statusDesc;
	}

	@JsonProperty("StatusDesc")
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	@JsonProperty("DispFlag")
	public boolean getDispFlag() {
		return dispFlag;
	}

	@JsonProperty("DispFlag")
	public void setDispFlag(String dispFlag) {
		this.dispFlag = dispFlag.equals("X") ? Boolean.TRUE : Boolean.FALSE;
	}

	@JsonProperty("EditFlag")
	public boolean getEditFlag() {
		return editFlag;
	}

	@JsonProperty("EditFlag")
	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag.equals("X") ? Boolean.TRUE : Boolean.FALSE;
	}

	@JsonProperty("PrintFlag")
	public boolean getPrintFlag() {
		return printFlag;
	}

	@JsonProperty("PrintFlag")
	public void setPrintFlag(String printFlag) {
		this.printFlag = printFlag.equals("X") ? Boolean.TRUE : Boolean.FALSE;
	}

	@JsonProperty("TabFlag")
	public boolean getTabFlag() {
		return tabFlag;
	}

	@JsonProperty("TabFlag")
	public void setTabFlag(String tabFlag) {
		this.tabFlag = tabFlag.equals("X") ? Boolean.TRUE : Boolean.FALSE;
	}

	@JsonProperty("DataFlag")
	public boolean getDataFlag() {
		return dataFlag;
	}

	@JsonProperty("DataFlag")
	public void setDataFlag(String dataFlag) {
		this.dataFlag = dataFlag.equals("X") ? Boolean.TRUE : Boolean.FALSE;
	}

	@JsonProperty("CreateFlag")
	public boolean getCreateFlag() {
		return createFlag;
	}

	@JsonProperty("CreateFlag")
	public void setCreateFlag(String createFlag) {
		this.createFlag = createFlag.equals("X") ? Boolean.TRUE : Boolean.FALSE;
	}

	@Override
	public String toString() {
		return "Form12BB [pernr=" + pernr + ", fsDate=" + fsDate + ", feDate=" + feDate + ", fYear=" + fYear
				+ ", invAmt=" + invAmt + ", status=" + status + ", statusDesc=" + statusDesc + ", dispFlag=" + dispFlag
				+ ", editFlag=" + editFlag + ", printFlag=" + printFlag + ", tabFlag=" + tabFlag + ", dataFlag="
				+ dataFlag + ", createFlag=" + createFlag + "]";
	}
}