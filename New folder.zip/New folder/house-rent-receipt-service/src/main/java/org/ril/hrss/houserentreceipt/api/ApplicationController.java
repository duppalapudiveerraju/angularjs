package org.ril.hrss.houserentreceipt.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.houserentreceipt.model.HouseRentReceipt;
import org.ril.hrss.houserentreceipt.model.HouseRentReceiptJson;
import org.ril.hrss.houserentreceipt.model.HouseRentReceiptSave;
import org.ril.hrss.houserentreceipt.util.HouseRentReceiptUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "HouseRentReceipt Request", description = "Operations pertaining to HouseRentReceipt Request")
public class ApplicationController {

	@Autowired
	private HouseRentReceiptUtil houseRentReceiptUtil;

	protected Logger logger = Logger.getLogger(ApplicationController.class.getName());

	@RequestMapping(value = "/receipt", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "HouseRentReceipt", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<HouseRentReceipt> getHouseRentReceipt(@NotNull @RequestHeader("userID") String userId)
			throws ClientException {
		logger.info("HouseRentReceipt-service-controller.getHouseRentReceipt()");
		List<HouseRentReceipt> houseRentReceipts = houseRentReceiptUtil.getHouseRentReceipt(userId);
		return houseRentReceipts;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save a list of House Rent Receipt Save request", response = ResponseEntity.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully saved list of House Rent Receipt Save request"),
			@ApiResponse(code = 201, message = "Successfully saved list of House Rent Receipt Save request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<HouseRentReceiptSave> houseRentRequest(@NotNull @RequestHeader("userID") String userId,
			@RequestBody HouseRentReceiptSave input) throws ClientException {
		logger.info("HouseRentReceipt-service-controller.houseRentRequest()");
		return houseRentReceiptUtil.houseRentResponse(userId, input);
	}

	@RequestMapping(value = "/update/{reqNumber}", method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Update a list of House Rent Declaration request", response = ResponseEntity.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully update list of House Rent Declaration request"),
			@ApiResponse(code = 201, message = "Successfully update list of House Rent Declaration request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<HouseRentReceiptSave> updateHouseRentRequest(@NotNull @RequestHeader("userID") String userId,
			@RequestBody HouseRentReceiptSave input, @PathVariable("reqNumber") String reqNumber)
			throws ClientException {
		logger.info("HouseRentReceipt-service-controller.updateHouseRentRequest()");
		return houseRentReceiptUtil.updateHouseRentResponse(userId, input, reqNumber);
	}

	@RequestMapping(value = "/delete/{reqNumber}", method = RequestMethod.DELETE, produces = "application/json")
	@ApiOperation(value = "Delete a list of House Rent Declaration request", response = List.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully delete list of House Rent Declaration request"),
			@ApiResponse(code = 201, message = "Successfully delete list of House Rent Declaration request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<HouseRentReceiptJson> deleteHouseRentRequest(@NotNull @RequestHeader("userID") String userId,
			@PathVariable("reqNumber") String reqNumber) throws ClientException {
		logger.info("HouseRentReceipt-service-controller.deleteHouseRentRequest()");
		return houseRentReceiptUtil.deleteHouseRentResponse(userId, reqNumber);
	}

}