package org.ril.hrss.houserentreceipt.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HouseRentReceiptJson {

	private String reqNo;
	private String msg;
	private String action;
	private List<HRReceiptItem> hRReceiptItemList;

	public HouseRentReceiptJson() {
		super();
	}

	@JsonProperty("ReqNo")
	public String getReqNo() {
		return reqNo;
	}

	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	@JsonProperty("msg")
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@JsonProperty("Action")
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@JsonProperty("HRAReceiptsItmSet")
	public List<HRReceiptItem> gethRReceiptItemList() {
		return hRReceiptItemList;
	}

	public void sethRReceiptItemList(List<HRReceiptItem> hRReceiptItemList) {
		this.hRReceiptItemList = hRReceiptItemList;
	}

	@Override
	public String toString() {
		return "HouseRentReceiptJson [msg=" + msg + ", action=" + action + ", hRReceiptItemList=" + hRReceiptItemList
				+ "]";
	}

}