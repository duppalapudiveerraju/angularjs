package org.ril.hrss.houserentreceipt.model;

import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class HouseRentReceipt {

	@JsonProperty("Reqno")
	private String reqNo;

	@JsonProperty("FromDate")
	private String fromDate;

	@JsonProperty("ToDate")
	private String toDate;

	@JsonProperty("Reqcrdt")
	private String reqCrdt;

	@JsonProperty("Claimamt")
	private String claimAmt;

	@JsonProperty("Appramt")
	private String apprAmt;

	@JsonProperty("ReqStatusKey")
	private String reqStatusKey;

	@JsonProperty("EmpComments")
	private String empComments;

	@JsonProperty("ApprComments")
	private String apprComments;

	@JsonProperty("ReqStatusText")
	private String reqStatusText;

	@JsonProperty("Action")
	private String action;

	@JsonProperty("DocNum")
	private String docNum;

	@JsonProperty("SeqNo")
	private String seqNo;

	@JsonProperty("NewCreate")
	private String newCreate;

	public HouseRentReceipt() {
		super();
	}

	public String getReqNo() {
		return reqNo;
	}

	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	@JsonSerialize(converter = SAPStringToDateSerializer.class)
	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	@JsonSerialize(converter = SAPStringToDateSerializer.class)
	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	@JsonSerialize(converter = SAPStringToDateSerializer.class)
	public String getReqCrdt() {
		return reqCrdt;
	}

	public void setReqCrdt(String reqCrdt) {
		this.reqCrdt = reqCrdt;
	}

	public String getClaimAmt() {
		return claimAmt;
	}

	public void setClaimAmt(String claimAmt) {
		this.claimAmt = claimAmt;
	}

	public String getApprAmt() {
		return apprAmt;
	}

	public void setApprAmt(String apprAmt) {
		this.apprAmt = apprAmt;
	}

	public String getReqStatusKey() {
		return reqStatusKey;
	}

	public void setReqStatusKey(String reqStatusKey) {
		this.reqStatusKey = reqStatusKey;
	}

	public String getEmpComments() {
		return empComments;
	}

	public void setEmpComments(String empComments) {
		this.empComments = empComments;
	}

	public String getApprComments() {
		return apprComments;
	}

	public void setApprComments(String apprComments) {
		this.apprComments = apprComments;
	}

	public String getReqStatusText() {
		return reqStatusText;
	}

	public void setReqStatusText(String reqStatusText) {
		this.reqStatusText = reqStatusText;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getDocNum() {
		return docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	public String getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	public String getNewCreate() {
		return newCreate;
	}

	public void setNewCreate(String newCreate) {
		this.newCreate = newCreate;
	}
}