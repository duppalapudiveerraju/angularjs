package org.ril.hrss.houserentreceipt.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HRReceiptItem {
	private String reqNo;
	private String fromDate;
	private String toDate;
	private String reqcrdt;
	private String claimAmount;
	private String empComments;
	private String docNumber;

	public HRReceiptItem() {
		super();
	}

	@JsonProperty("Reqno")
	public String getReqNo() {
		return reqNo;
	}

	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	@JsonProperty("FromDate")
	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	@JsonProperty("ToDate")
	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	@JsonProperty("Reqcrdt")
	public String getReqcrdt() {
		return reqcrdt;
	}

	public void setReqcrdt(String reqcrdt) {
		this.reqcrdt = reqcrdt;
	}

	@JsonProperty("Claimamt")
	public String getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(String claimAmount) {
		this.claimAmount = claimAmount;
	}

	@JsonProperty("EmpComments")
	public String getEmpComments() {
		return empComments;
	}

	public void setEmpComments(String empComments) {
		this.empComments = empComments;
	}

	@JsonProperty("DocNumber")
	public String getDocNumber() {
		return docNumber;
	}

	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}

	@Override
	public String toString() {
		return "HRReceiptItem [reqNo=" + reqNo + ", fromDate=" + fromDate + ", toDate=" + toDate + ", reqcrdt="
				+ reqcrdt + ", claimAmount=" + claimAmount + ", empComments=" + empComments + ", docNumber=" + docNumber
				+ "]";
	}

}