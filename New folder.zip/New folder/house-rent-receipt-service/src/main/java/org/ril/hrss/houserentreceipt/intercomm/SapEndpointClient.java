package org.ril.hrss.houserentreceipt.intercomm;

import java.util.Map;

import javax.validation.constraints.NotNull;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(value = "/sap/houseRentRecList", method = RequestMethod.GET, produces = "application/json")
	String getHouseRentReceipt(@NotNull @RequestHeader("userID") String userId);

	@RequestMapping(method = RequestMethod.POST, value = "/sap/houseRent/receipt/save", produces = "application/json", consumes = "application/json")
	Map<String, String> houseRentDetailsRequest(@NotNull @RequestHeader("userID") String userId,
			@RequestBody String receiptJSONString);

	@RequestMapping(value = "/sap/houseRent/receipt/update/{reqNumber}", method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
	Map<String, String> updateHouseRentRequest(@NotNull @RequestHeader("userID") String userId,
			@RequestBody String receiptJSONString, @PathVariable("reqNumber") String reqNumber);

	@RequestMapping(value = "/sap/houseRent/receipt/delete/{reqNumber}", method = RequestMethod.DELETE, produces = "application/json", consumes = "application/json")
	Map<String, String> deleteHouseRentRequest(@NotNull @RequestHeader("userID") String userId,
			@PathVariable("reqNumber") String reqNumber);

}