package org.ril.hrss.houserentreceipt.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.ril.hrss.houserentreceipt.intercomm.SapEndpointClient;
import org.ril.hrss.houserentreceipt.model.HouseRentReceipt;
import org.ril.hrss.houserentreceipt.model.HouseRentReceiptJson;
import org.ril.hrss.houserentreceipt.model.HouseRentReceiptSave;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.client.ClientException;

@Component
public class HouseRentReceiptUtil {

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	protected Logger logger = Logger.getLogger(HouseRentReceiptUtil.class.getName());

	public List<HouseRentReceipt> getHouseRentReceipt(String userId) throws ClientException {
		logger.info("HouseRentReceiptUtil.getHouseRentReceipt()");
		String response = sapEndpointClient.getHouseRentReceipt(userId);
		List<HouseRentReceipt> houseRentReceiptsResponse = null;
		if (response == null) {
			houseRentReceiptsResponse = new ArrayList<>();
		} else {
			houseRentReceiptsResponse = getHouseRentReceiptObjectMapped(response);
		}
		return houseRentReceiptsResponse;
	}

	private List<HouseRentReceipt> getHouseRentReceiptObjectMapped(String feed) {
		logger.info("HouseRentReceiptUtil.getHouseRentReceiptObjectMapped()");
		List<HouseRentReceipt> list = new ArrayList<HouseRentReceipt>();
		try {
			ObjectMapper objectMapper = objectMapperUtil.get();
			JsonNode rootNode = objectMapper.readTree(feed);
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
			objectMapper.setDateFormat(df);
			list = objectMapper.readValue(
					rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
					new TypeReference<List<HouseRentReceipt>>() {
					});
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list;
	}

	public ResponseEntity<HouseRentReceiptSave> houseRentResponse(String userId,
			HouseRentReceiptSave houseRentReceiptSave) throws ClientException {
		logger.info("HouseRentReceiptUtil.houseRentResponse()");
		if (houseRentReceiptSave.getReqNo() == null) {
			houseRentReceiptSave.setReqNo(HRSSConstantUtil.EMPTY_STRING);
		}
		for (int i = 0; i < houseRentReceiptSave.gethRReceiptItemList().size(); i++) {
			if (houseRentReceiptSave.gethRReceiptItemList().get(i).getReqNo() == null) {
				houseRentReceiptSave.gethRReceiptItemList().get(i).setReqNo(HRSSConstantUtil.EMPTY_STRING);
			}
		}
		String jsonData = null;
		try {
			jsonData = objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST).writeValueAsString(houseRentReceiptSave);
		} catch (JsonProcessingException e) {
			logger.info(e.getMessage());
		}
		Map<String, String> map = sapEndpointClient.houseRentDetailsRequest(userId, jsonData);
		return parseSAPResponse(houseRentReceiptSave, map);
	}

	public ResponseEntity<HouseRentReceiptSave> updateHouseRentResponse(String userId,
			HouseRentReceiptSave houseRentReceiptSave, String reqNumber) throws ClientException {
		logger.info("HouseRentReceiptUtil.updateHouseRentResponse()");
		String jsonData = null;
		try {
			jsonData = objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST).writeValueAsString(houseRentReceiptSave);
		} catch (JsonProcessingException e) {
			logger.info(e.getMessage());
		}
		Map<String, String> map = sapEndpointClient.updateHouseRentRequest(userId, jsonData, reqNumber);
		return parseSAPResponse(houseRentReceiptSave, map);
	}

	public List<HouseRentReceiptJson> deleteHouseRentResponse(String userId, String reqNumber) throws ClientException {
		logger.info("HouseRentDecUtil.deleteHouseRentResponse()");
		try {
			Map<String, String> map = sapEndpointClient.deleteHouseRentRequest(userId, reqNumber);
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return null;
	}

	private ResponseEntity<HouseRentReceiptSave> parseSAPResponse(HouseRentReceiptSave obj, Map<String, String> map) {
		if (map.get(HRSSConstantUtil.POST_RESPONSE_STATUS).equals(HRSSConstantUtil.POST_RESPONSE_STATUS_SUCCESS))
			return new ResponseEntity<HouseRentReceiptSave>(obj, HttpStatus.OK);
		else
			return new ResponseEntity<HouseRentReceiptSave>(obj, HttpStatus.BAD_REQUEST);
	}

}