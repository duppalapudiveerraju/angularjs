package org.ril.hrss.houserentreceipt.intercomm;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getHouseRentReceipt(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public Map<String, String> houseRentDetailsRequest(String userId, String receiptJSONString) {
		return new HashMap<String, String>();
	}

	@Override
	public Map<String, String> updateHouseRentRequest(String userId, String receiptJSONString, String reqNumber) {

		return new HashMap<String, String>();
	}

	@Override
	public Map<String, String> deleteHouseRentRequest(String userId, String reqNumber) {

		return new HashMap<String, String>();
	}

}