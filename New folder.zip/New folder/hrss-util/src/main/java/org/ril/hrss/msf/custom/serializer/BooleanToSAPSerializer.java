package org.ril.hrss.msf.custom.serializer;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class BooleanToSAPSerializer extends StdConverter<Boolean, String>{

	@Override
	public String convert(Boolean obj) {
		return obj ? "X" : HRSSConstantUtil.EMPTY_STRING;
	}

}