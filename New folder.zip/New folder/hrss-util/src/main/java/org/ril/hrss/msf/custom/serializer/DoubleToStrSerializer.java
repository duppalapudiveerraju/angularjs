package org.ril.hrss.msf.custom.serializer;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class DoubleToStrSerializer extends StdConverter<Double, String> {

	@Override
	public String convert(Double obj) {
		return obj != null ? obj.toString() : HRSSConstantUtil.EMPTY_STRING;
	}

}