package org.ril.hrss.msf.util;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateUtil {

	public static final String TIME_PATTERN = "^PT(\\d{2})H(\\d{2})M(\\d{2})S$";
	public static final String TIME_ZZ_PATTERN = "^(\\d{2}):(\\d{2})$";
	public static final String SHIFT_TIME_PATTERN = "^(\\d{6})-(\\d{6})$";
	public static final String PERIOD_TIME_PATTERN = "^(\\d{2}\\.d{2}\\.d{4}) - (\\d{2}\\.d{2}\\.d{4})$";
	public static final String DATE_TIME_PATTERN = "yyyy/MM/dd HH:mm:ss";
	public static final String SIMPLE_DATE_TIME_PATTERN = "dd MMM yyyy HH:mm";
	public static final String SIMPLE_DATE_PATTERN = "dd MMM yyyy";
	public static final String SIMPLE_MONTH_PATTERN = "MMM";
	public static final String PERIOD_DATE_PATTERN = "dd.MM.yyyy";
	public static final String CLOCK_TIME_PATTERN = "HHmmss";
	public static final DecimalFormat DECIMAL_FORMATTER_2 = new DecimalFormat(".##");
	public static final DecimalFormat DECIMAL_FORMATTER_1 = new DecimalFormat(".#");
	public static final Date DEFAULT_DATE_TS = new Date(0);

	protected static final Logger logger = Logger.getLogger(DateUtil.class.getName());

	public static Long getDaysOffset(int i) {
		return (long) (i * (24 * 60 * 60 * 1000));
	}

	public static Date getEndOfTheDay(Date date) {
		return new Date((date.getTime() + getDaysOffset(1)) - 1);
	}

	public static Date getDate(String dateStr) {
		if (dateStr != null) {
			Long dateLong = Long.parseLong(dateStr);
			return new Date(dateLong);
		} else {
			return new Date();
		}
	}

	@SuppressWarnings("deprecation")
	private String getDateStrfromDateYYYYMMDD(Date date) {
		return getActualYear(date.getYear()) + "/" + getActualMonth(date.getMonth()) + "/" + date.getDate();
	}

	public static int getActualYear(int year) {
		return 1900 + year;
	}

	public static int getActualMonth(int month) {
		return 1 + month;
	}

	public static Date getUTCDateFromSimpleFormat(String dateStr) {
		Date formattedDate = null;
		if (dateStr != null) {
			try {
				SimpleDateFormat utcDateformatter = new SimpleDateFormat(SIMPLE_DATE_TIME_PATTERN);
				utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
				formattedDate = utcDateformatter.parse(dateStr);
			} catch (ParseException e) {
				logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
			}
		}
		return formattedDate;
	}

	public static Date getUTCDateFormat(Date date) {
		Date formattedDate = null;
		if (date != null) {
			try {
				SimpleDateFormat utcDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
				utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
				SimpleDateFormat istDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
				istDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_IST));
				formattedDate = utcDateformatter.parse(istDateformatter.format(date));
			} catch (ParseException e) {
				logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
			}
		}
		return formattedDate;
	}

	public static Date getDateFromISTTimeFormat(String sapFormat, Date currentDate) {
		Date formattedDate = null;
		DateUtil dateUtil = new DateUtil();
		if (sapFormat != null) {
			Matcher m = Pattern.compile(TIME_PATTERN).matcher(sapFormat);
			if (m.find()) {
				try {
					SimpleDateFormat istDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
					istDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_IST));
					String hrMinSecStr = m.group(1) + ":" + m.group(2) + ":" + m.group(3);
					String yyyyMmDdStr = dateUtil.getDateStrfromDateYYYYMMDD(currentDate);
					formattedDate = istDateformatter.parse(yyyyMmDdStr + " " + hrMinSecStr);
				} catch (ParseException e) {
					logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
				}
			}
		}
		return formattedDate;
	}

	public static Date getDateFromTimeFormat(String sapFormat, Date currentDate) {
		Date formattedDate = null;
		DateUtil dateUtil = new DateUtil();
		if (sapFormat != null) {
			Matcher m = Pattern.compile(TIME_PATTERN).matcher(sapFormat);
			if (m.find()) {
				try {
					SimpleDateFormat istDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
					istDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_IST));
					String hrMinSecStr = m.group(1) + ":" + m.group(2) + ":" + m.group(3);
					String yyyyMmDdStr = dateUtil.getDateStrfromDateYYYYMMDD(currentDate);
					Date istformattedDate = istDateformatter.parse(yyyyMmDdStr + " " + hrMinSecStr);
					SimpleDateFormat utcDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
					utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
					formattedDate = utcDateformatter.parse(istDateformatter.format(istformattedDate));
				} catch (ParseException e) {
					logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
				}
			}
		}
		return formattedDate;
	}

	public static Date getDateFromZZFormat(String sapFormat, Date currentDate) {
		Date formattedDate = null;
		DateUtil dateUtil = new DateUtil();
		if (sapFormat != null) {
			Matcher m = Pattern.compile(TIME_ZZ_PATTERN).matcher(sapFormat);
			if (m.find()) {
				try {
					SimpleDateFormat istDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
					istDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_IST));
					String hrMinSecStr = m.group(1) + ":" + m.group(2) + ":00";
					String yyyyMmDdStr = dateUtil.getDateStrfromDateYYYYMMDD(currentDate);
					Date istformattedDate = istDateformatter.parse(yyyyMmDdStr + " " + hrMinSecStr);
					SimpleDateFormat utcDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
					utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
					formattedDate = utcDateformatter.parse(istDateformatter.format(istformattedDate));
				} catch (ParseException e) {
					logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
				}
			}
		}
		return formattedDate;
	}

	public static Date getDateFromFloatingTime(String floatTimeStr, Date currentDate) {
		Date formattedDate = null;
		DateUtil dateUtil = new DateUtil();
		if (floatTimeStr != null) {
			try {
				Double floatingTime = Double.parseDouble(floatTimeStr);
				Double hrs = (floatingTime - (floatingTime - floatingTime.intValue()));
				Double min = Double.parseDouble(DECIMAL_FORMATTER_2.format(((floatingTime - hrs) * 60)));
				String yyyyMmDdStr = dateUtil.getDateStrfromDateYYYYMMDD(currentDate);
				SimpleDateFormat utcDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
				utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
				formattedDate = utcDateformatter
						.parse(yyyyMmDdStr + " " + hrs.intValue() + ":" + min.intValue() + ":00");
			} catch (ParseException e) {
				logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
			}
		}
		return formattedDate;
	}

	public static Date getDateFromNumberFormat(String shiftTimeStr, Date currentDate, boolean flag) {
		Date formattedDate = null;
		DateUtil dateUtil = new DateUtil();
		if (shiftTimeStr != null) {
			Matcher m = Pattern.compile(SHIFT_TIME_PATTERN).matcher(shiftTimeStr);
			if (m.find()) {
				String shiftStr = dateUtil.getShiftTimeString(m, flag);
				formattedDate = getFormattedDateFromNum(shiftStr, currentDate);
			}
		}
		return formattedDate;
	}

	public static Date getFormattedDate(String dateStr) {
		Date formattedDate = null;
		try {
			SimpleDateFormat utcDateformatter = new SimpleDateFormat(PERIOD_DATE_PATTERN);
			utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
			formattedDate = utcDateformatter.parse(dateStr);
		} catch (ParseException e) {
			logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
		}
		return formattedDate;
	}

	public static String getSimpleFormatDate(Date dateStr) {
		String formattedDate = null;
		if (dateStr != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(SIMPLE_DATE_PATTERN);
			formattedDate = dateFormat.format(dateStr);
		} else {
			logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
		}
		return formattedDate;
	}

	public static String getSimpleFormatMonth(Date dateStr) {
		String formattedDate = null;
		if (dateStr != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(SIMPLE_MONTH_PATTERN);
			formattedDate = dateFormat.format(dateStr);
		} else {
			logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
		}
		return formattedDate;
	}

	public static Date getFormattedDateFromNum(String shiftStr, Date currentDate) {
		Date formattedDate = null;
		DateUtil dateUtil = new DateUtil();
		try {
			Integer floatingTime = Integer.parseInt(shiftStr);
			int hrs = floatingTime / 10000;
			int min = (floatingTime - (hrs * 10000)) / 100;
			int sec = (floatingTime - (hrs * 10000) - (min * 100));
			String yyyyMmDdStr = dateUtil.getDateStrfromDateYYYYMMDD(currentDate);
			SimpleDateFormat utcDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
			utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
			formattedDate = utcDateformatter
					.parse(yyyyMmDdStr + " " + hrs + ":" + min + ":" + (sec <= 9 ? "0" + sec : sec));
		} catch (ParseException e) {
			logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
		}
		return formattedDate;
	}

	public static Date getFormattedDateFromClockFormat(String clockStr, Date currentDate) {
		Date formattedDate = null;
		DateUtil dateUtil = new DateUtil();
		if (clockStr != null) {
			try {
				SimpleDateFormat istDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
				istDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_IST));
				String hrMinSecStr = clockStr + ":00";
				String yyyyMmDdStr = dateUtil.getDateStrfromDateYYYYMMDD(currentDate);
				Date istformattedDate = istDateformatter.parse(yyyyMmDdStr + " " + hrMinSecStr);
				SimpleDateFormat utcDateformatter = new SimpleDateFormat(DATE_TIME_PATTERN);
				utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
				formattedDate = utcDateformatter.parse(istDateformatter.format(istformattedDate));
			} catch (ParseException e) {
				logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
			}
		}
		return formattedDate;
	}

	public static String getFormattedClockTimeFromDate(Date date) {
		String formattedStr = null;
		if (date != null) {
			SimpleDateFormat utcDateformatter = new SimpleDateFormat(CLOCK_TIME_PATTERN);
			utcDateformatter.setTimeZone(TimeZone.getTimeZone(HRSSConstantUtil.TIMEZONE_UTC));
			formattedStr = utcDateformatter.format(date);
		}
		return formattedStr;
	}

	@SuppressWarnings("deprecation")
	public static String getFormattedStrFromDate(Date date) {
		String formattedStr = null;
		if (date != null) {
			formattedStr = "PT" + getFormattedStr(date.getHours()) + "H" + getFormattedStr(date.getMinutes()) + "M"
					+ getFormattedStr(date.getSeconds()) + "S";
		}
		return formattedStr;
	}

	private static String getFormattedStr(int num) {
		if (num < 10) {
			return "0" + num;
		} else {
			return HRSSConstantUtil.EMPTY_STRING + num;
		}
	}

	private String getShiftTimeString(Matcher m, boolean flag) {
		if (flag) {
			return m.group(1);
		} else {
			return m.group(2);
		}
	}

	public static long getMilsecFromDouble(Double num) {
		Double hrs = (num - (num - num.intValue()));
		Double min = Double.parseDouble(DECIMAL_FORMATTER_2.format(((num - hrs) * 60)));
		Double sec = Double.parseDouble(DECIMAL_FORMATTER_2.format(((min - min.intValue()) * 60)));
		return ((hrs.longValue() * 60 * 60) + (min.longValue() * 60) + sec.longValue()) * 1000;
	}

	public static String getMonthStrfromStr(String month) {
		int mInt = Integer.parseInt(month);
		if (mInt > 9) {
			return month;
		} else {
			return "0" + mInt;
		}
	}

	private static String getMonthStrfromInt(int mInt) {
		if (mInt > 9) {
			return HRSSConstantUtil.EMPTY_STRING + mInt;
		} else {
			return "0" + mInt;
		}
	}

	public static String getPrevYearStr(String month, String year) {
		int mInt = Integer.parseInt(month);
		if (mInt == 1) {
			return HRSSConstantUtil.EMPTY_STRING + (Integer.parseInt(year) - 1);
		} else {
			return year;
		}
	}

	public static String getNextYearStr(String month, String year) {
		int mInt = Integer.parseInt(month);
		if (mInt == 12) {
			return HRSSConstantUtil.EMPTY_STRING + (Integer.parseInt(year) + 1);
		} else {
			return year;
		}
	}

	public static String getPrevMonthStr(String month) {
		int mInt = Integer.parseInt(month) - 1;
		if (mInt < 1) {
			return "12";
		} else {
			return getMonthStrfromInt(mInt);
		}
	}

	public static String getNextMonthStr(String month) {
		int mInt = Integer.parseInt(month) + 1;
		if (mInt > 12) {
			return "01";
		} else {
			return getMonthStrfromInt(mInt);
		}
	}

	@SuppressWarnings("deprecation")
	public static Integer getMonthFromDate(Date date) {
		return getActualMonth(date.getMonth());
	}

	@SuppressWarnings("deprecation")
	public static Integer getYearFromDate(Date date) {
		return getActualYear(date.getYear());
	}

	public static String getSAPDateStr(Date dateStr) {
		return "/Date(" + dateStr.getTime() + ")/";
	}

	public static Double getDoubleFromDateTime(Date dateStart, Date dateEnd) {
		Long dateStartMillis = 0L;
		Long dateEndMillis = 0L;
		if (dateStart.equals(dateEnd)) {
			return HRSSConstantUtil.ZERO;
		} else if (dateStart.before(dateEnd)) {
			dateStartMillis = dateStart.getTime();
			dateEndMillis = dateEnd.getTime();
		} else {
			dateStartMillis = dateStart.getTime();
			dateEndMillis = dateEnd.getTime() + getDaysOffset(1);
		}
		Long dateDifMillis = dateEndMillis - dateStartMillis;
		Long hours = TimeUnit.MILLISECONDS.toHours(dateDifMillis);
		dateDifMillis -= TimeUnit.HOURS.toMillis(hours);
		Long minutes = TimeUnit.MILLISECONDS.toMinutes(dateDifMillis);
		dateDifMillis -= TimeUnit.MINUTES.toMillis(minutes);
		Long seconds = TimeUnit.MILLISECONDS.toSeconds(dateDifMillis);
		minutes += TimeUnit.MILLISECONDS.toMinutes(seconds);
		return Double.parseDouble(DECIMAL_FORMATTER_2.format(hours.doubleValue() + minutes.doubleValue() / 60));
	}

	public static Date addDayOffset(Date dateIn, Date dateOut) {
		if (dateIn != null && dateOut != null && dateOut.before(dateIn)) {
			return new Date(dateOut.getTime() + DateUtil.getDaysOffset(1));
		} else {
			return dateOut;
		}
	}

	public static List<Date> getListOfDaysBetweenTwoDates(Date leaveFromDate, Date leaveToDate) {
		List<Date> result = new ArrayList<Date>();
		Calendar start = Calendar.getInstance();
		start.setTime(leaveFromDate);
		Calendar end = Calendar.getInstance();
		end.setTime(leaveToDate);
		end.add(Calendar.DAY_OF_YEAR, HRSSConstantUtil.ONE.intValue());
		while (start.before(end)) {
			result.add(start.getTime());
			start.add(Calendar.DAY_OF_YEAR, HRSSConstantUtil.ONE.intValue());
		}
		return result;
	}

}