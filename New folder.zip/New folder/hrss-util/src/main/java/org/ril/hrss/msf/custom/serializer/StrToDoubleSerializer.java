package org.ril.hrss.msf.custom.serializer;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class StrToDoubleSerializer extends StdConverter<String, Double> {

	@Override
	public Double convert(String obj) {
		return obj != null ? !obj.isEmpty() ? Double.parseDouble(obj) : HRSSConstantUtil.ZERO : HRSSConstantUtil.ZERO;
	}

}
