package org.ril.hrss.msf.custom.serializer;

import java.util.Date;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class SAPStringToDateSerializer extends StdConverter<String, Date> {

	@Override
	public Date convert(String obj) {
		return obj != null
				? new Date(
						Long.parseLong(obj.replaceAll(HRSSConstantUtil.REGEX_ONLY_NUM, HRSSConstantUtil.EMPTY_STRING)))
				: null;
	}

}