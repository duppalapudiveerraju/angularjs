package org.ril.hrss.msf.util.enumeration;

public enum ServiceType {

	LEAVE, REGULARIZE, APPROVALS, MANAGE_MY_ATTENDANCE;

}