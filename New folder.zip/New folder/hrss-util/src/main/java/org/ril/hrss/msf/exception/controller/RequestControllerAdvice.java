package org.ril.hrss.msf.exception.controller;

import java.util.Date;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;

import org.ril.hrss.msf.model.ResponeBean;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.netflix.client.ClientException;
import com.netflix.client.ClientException.ErrorType;

import feign.FeignException;

@ControllerAdvice
public class RequestControllerAdvice {

	protected static final Logger logger = Logger.getLogger(RequestControllerAdvice.class.getName());

	@ExceptionHandler(ClientException.class)
	@ResponseBody
	public ResponseEntity<ResponeBean> handleException(ClientException exception, HttpServletRequest req) {
		logger.info(exception.getMessage());
		if (exception.getErrorType() == ErrorType.READ_TIMEOUT_EXCEPTION
				|| exception.getErrorType() == ErrorType.SOCKET_TIMEOUT_EXCEPTION
				|| exception.getErrorType() == ErrorType.NUMBEROF_RETRIES_EXEEDED
				|| exception.getErrorType() == ErrorType.NUMBEROF_RETRIES_NEXTSERVER_EXCEEDED) {
			return new ResponseEntity<ResponeBean>(setResponseBean(HRSSConstantUtil.REQUEST_TIMEOUT_MSG, exception),
					HttpStatus.REQUEST_TIMEOUT);
		} else {
			return new ResponseEntity<ResponeBean>(
					setResponseBean(HRSSConstantUtil.INTERNAL_SERVER_ERROR_MSG, exception),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseBody
	public ResponseEntity<ResponeBean> handleException(MethodArgumentNotValidException exception,
			HttpServletRequest req) {
		logger.info(exception.getMessage());
		BindingResult result = exception.getBindingResult();
		FieldError error = result.getFieldError();
		if (error != null) {
			return new ResponseEntity<ResponeBean>(setResponseBean(error.getDefaultMessage(), exception),
					HttpStatus.BAD_REQUEST);
		} else {
			return new ResponseEntity<ResponeBean>(new ResponeBean(), HttpStatus.OK);
		}
	}

	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseBody
	public ResponseEntity<ResponeBean> handleException(ConstraintViolationException exception, HttpServletRequest req) {
		logger.info("Exception message :: " + exception.getMessage());
		return new ResponseEntity<ResponeBean>(setResponseBean(exception.getLocalizedMessage(), exception),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(FeignException.class)
	@ResponseBody
	public ResponseEntity<ResponeBean> handleUnAuthorisedException(FeignException exception, HttpServletRequest req) {
		logger.info(exception.getMessage());
		if (exception.getMessage().contains(HRSSConstantUtil.READ_TIMEOUT_FILTER_MSG)) {
			return new ResponseEntity<ResponeBean>(setResponseBean(HRSSConstantUtil.REQUEST_TIMEOUT_MSG, exception),
					HttpStatus.REQUEST_TIMEOUT);
		} else {
			return new ResponseEntity<ResponeBean>(
					setResponseBean(HRSSConstantUtil.INTERNAL_SERVER_ERROR_MSG, exception),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private ResponeBean setResponseBean(String message, Exception exception) {
		return new ResponeBean(message, new Date(), exception.getMessage());
	}

}