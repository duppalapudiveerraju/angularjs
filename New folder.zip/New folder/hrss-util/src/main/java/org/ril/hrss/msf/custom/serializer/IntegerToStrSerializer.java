package org.ril.hrss.msf.custom.serializer;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class IntegerToStrSerializer  extends StdConverter<Integer, String>{
	
	@Override
	public String convert(Integer obj) {

		return obj != null ? obj.toString() : HRSSConstantUtil.EMPTY_STRING;
	}

}
