package org.ril.hrss.msf.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "multicast_id", "success", "failure", "canonical_ids", "results" })
public class NotificationFcmResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("multicast_id")
	private Long multicastId;
	@JsonProperty("success")
	private Integer success;
	@JsonProperty("failure")
	private Integer failure;
	@JsonProperty("canonical_ids")
	private Integer canonicalIds;
	@JsonProperty("results")
	private List<Result> results = null;

	public NotificationFcmResponse() {
		super();
	}

	public NotificationFcmResponse(Long multicastId, Integer success, Integer failure, Integer canonicalIds,
			List<Result> results) {
		super();
		this.multicastId = multicastId;
		this.success = success;
		this.failure = failure;
		this.canonicalIds = canonicalIds;
		this.results = results;
	}

	@JsonProperty("multicast_id")
	public Long getMulticastId() {
		return multicastId;
	}

	@JsonProperty("multicast_id")
	public void setMulticastId(Long multicastId) {
		this.multicastId = multicastId;
	}

	@JsonProperty("success")
	public Integer getSuccess() {
		return success;
	}

	@JsonProperty("success")
	public void setSuccess(Integer success) {
		this.success = success;
	}

	@JsonProperty("failure")
	public Integer getFailure() {
		return failure;
	}

	@JsonProperty("failure")
	public void setFailure(Integer failure) {
		this.failure = failure;
	}

	@JsonProperty("canonical_ids")
	public Integer getCanonicalIds() {
		return canonicalIds;
	}

	@JsonProperty("canonical_ids")
	public void setCanonicalIds(Integer canonicalIds) {
		this.canonicalIds = canonicalIds;
	}

	@JsonProperty("results")
	public List<Result> getResults() {
		return results;
	}

	@JsonProperty("results")
	public void setResults(List<Result> results) {
		this.results = results;
	}

	@Override
	public String toString() {
		return "NotificationFcmResponse [multicastId=" + multicastId + ", success=" + success + ", failure=" + failure
				+ ", canonicalIds=" + canonicalIds + ", results=" + results + "]";
	}

}
