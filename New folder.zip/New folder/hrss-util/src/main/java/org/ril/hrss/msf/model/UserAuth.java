package org.ril.hrss.msf.model;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

public class UserAuth {

	@NotNull
	private String userId;

	@NotNull
	private String userPass;

	public UserAuth() {
		super();
	}

	public UserAuth(String userId, String userPass) {
		super();
		this.userId = userId;
		this.userPass = userPass;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

}