package org.ril.hrss.msf.util.enumeration;

import org.ril.hrss.msf.util.HRSSConstantUtil;

public enum SAPGenericError {

	APPLY_LEAVE(HRSSConstantUtil.GENERIC_APPLY_LEAVE_ERROR_MESSAGE), APPLY_REGULARIZE(
			HRSSConstantUtil.GENERIC_APPLY_REG_ERROR_MESSAGE), APPROVE_LEAVE(
					HRSSConstantUtil.GENERIC_APPROVE_LEAVE_ERROR_MESSAGE), APPROVE_REGULARIZE(
							HRSSConstantUtil.GENERIC_APPROVE_REG_ERROR_MESSAGE);

	private String genericMsg;

	private SAPGenericError(String genericMsg) {
		this.genericMsg = genericMsg;
	}

	public String getGenericMsg() {
		return genericMsg;
	}

	public void setGenericMsg(String genericMsg) {
		this.genericMsg = genericMsg;
	}

	public static SAPGenericError fromString(String text) {
		for (SAPGenericError a : SAPGenericError.values()) {
			if (a.getGenericMsg().equalsIgnoreCase(text)) {
				return a;
			}
		}
		return null;
	}

}