package org.ril.hrss.msf.util.enumeration;

import java.util.Arrays;

public enum ApprovalStatus {

	APPROVED("approved"), REJECTED("rejected", "rejected by manager"), PENDING("pending", "pending with manager",
			"sent"), ERROR("error");

	private String[] statusArr;

	private ApprovalStatus(String... statusArr) {
		this.statusArr = statusArr;
	}

	public String[] getStatusArr() {
		return statusArr;
	}

	public void setStatusArr(String[] statusArr) {
		this.statusArr = statusArr;
	}

	public static ApprovalStatus fromString(String text) {
		for (ApprovalStatus a : ApprovalStatus.values()) {
			if (Arrays.asList(a.getStatusArr()).contains(text.toLowerCase())) {
				return a;
			}
		}
		return null;
	}

}