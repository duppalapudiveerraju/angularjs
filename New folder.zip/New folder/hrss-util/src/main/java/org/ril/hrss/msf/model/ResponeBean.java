package org.ril.hrss.msf.model;

import java.util.Date;

public class ResponeBean {

	private String info;
	private Date timestamp;
	private String errMessage;

	public ResponeBean() {
		super();
	}

	public ResponeBean(String info, Date timestamp, String errMessage) {
		super();
		this.info = info;
		this.timestamp = timestamp;
		this.errMessage = errMessage;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}

	@Override
	public String toString() {
		return "ResponeBean [info=" + info + ", timestamp=" + timestamp + ", errMessage=" + errMessage + "]";
	}

}