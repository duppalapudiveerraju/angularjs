package org.ril.hrss.msf.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class Result {

	@JsonProperty("error")
	private String error;

	@JsonProperty("message_id")
	private String messageId;

	public Result() {
		super();
	}

	public Result(String error, String messageId) {
		super();
		this.error = error;
		this.messageId = messageId;
	}

	@JsonProperty("error")
	public String getError() {
		return error;
	}

	@JsonProperty("error")
	public void setError(String error) {
		this.error = error;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	@Override
	public String toString() {
		return "Result [error=" + error + ", messageId=" + messageId + "]";
	}

}