package org.ril.hrss.msf.model;

import org.springframework.http.HttpStatus;

public class NotificationResponse {

	private String message;
	private HttpStatus statuscode;
	private String status;

	public NotificationResponse() {
		super();
	}

	public NotificationResponse(String message, HttpStatus statuscode, String status) {
		super();
		this.message = message;
		this.statuscode = statuscode;
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public HttpStatus getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(HttpStatus statuscode) {
		this.statuscode = statuscode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}