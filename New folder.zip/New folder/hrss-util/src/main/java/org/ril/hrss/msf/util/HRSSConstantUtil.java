package org.ril.hrss.msf.util;

public class HRSSConstantUtil {

	public static final String POST_RESPONSE_STATUS = "responseStatus";
	public static final String POST_RESPONSE_ERR_MSG = "responseErrMsg";
	public static final String POST_RESPONSE_SYSTEM_ERR_MSG = "systemErrMsg";
	public static final String POST_RESPONSE_STATUS_SUCCESS = "SUCCESS";
	public static final String POST_RESPONSE_STATUS_FAILED = "FAILED";
	public static final String POST_RESPONSE_STATUS_ERROR = "ERROR";
	public static final String POST_RESPONSE_STATUS_ERROR_MSG = "INTERNAL_SERVER_ERROR";
	public static final Integer LEAVE_PENDING_SLA = 7;
	public static final Integer REGULARIZE_PENDING_SLA = 7;
	public static final String APPROVAL_REQUEST = "A";
	public static final String REJECTION_REQUEST = "R";
	public static final String COMMA = ",";
	public static final String SPACE_COMMA = ", ";
	public static final String SPACE = " ";
	public static final String TO = " to ";
	public static final String SEMI_COLON = ";";
	public static final String UNEXPECTED_ERROR_OCCURRED = "Unexpected Error Occurred!!!";
	public static final String UNAUTHORISED_USER = "Unauthorised User Credentials!!!";
	public static final Double ZERO = 0D;
	public static final Double ONE = 1D;
	public static final String TIMEZONE_UTC = "UTC";
	public static final String TIMEZONE_IST = "IST";
	public static final String REGEX_ONLY_NUM = "[^0-9]";
	public static final String REGEX_REMOVE_QUOTES = "^\"|\"$";
	public static final String EMPTY_STRING = "";
	public static final String GENERIC_ERROR_MESSAGE = "Sorry for the inconveniance.";
	public static final String GENERIC_APPLY_LEAVE_ERROR_MESSAGE = "Sorry for the inconveniance .Please apply Leave after some time";
	public static final String GENERIC_APPLY_REG_ERROR_MESSAGE = "Sorry for the inconveniance .Please regularize for after some time";
	public static final String GENERIC_APPROVE_LEAVE_ERROR_MESSAGE = "Sorry! There was  some error while approving Leave Request .Please try again after some time";
	public static final String GENERIC_APPROVE_REG_ERROR_MESSAGE = "Sorry! There was  some error while approving Regularization Request .Please try again after some time";
	public static final String SAP_INTERNAL_ERROR_MSG = "INTERNAL ERROR";
	public static final String SAP_COLLISION_ERROR_MSG = "TIME COLLISION";
	public static final String APPROVALS_LEAVE_MSG = "{0} your Leave has been Approved {1}.";
	public static final String APPROVALS_REJECT_LEAVE_MSG = "{0} your Leave has been Rejected {1}";
	public static final String APPROVALS_REG_MSG = "{0} your Regularization has been Approved for {1}.";
	public static final String APPROVALS_REJECT_REG_MSG = "{0} your Regularization has been Rejected for {1}";
	public static final String REGULARIZE_PARTIAL_FAIL_MSG = "Successfully Partial Regularization Applied";
	public static final String REGULARIZE_FAIL_MSG = "{0} your Regularization application Failed for {1}. Apply Again!";
	public static final String REGULARIZE_SUCCESS_MSG = "{0} has applied Regularization on {1}. Approve Now!";
	public static final String LEAVE_PARTIAL_FAIL_MSG = "Successfully Partial Leave Applied";
	public static final String LEAVE_FAIL_MSG = "{0} your Leave application Failed for {1}. Apply Again!";
	public static final String LEAVE_SUCCESS_MSG = "{0} has applied for Leave on {1}. Approve Now!";

	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_FAILED = "FAILED";
	public static final String SUCCESS_CODE = "200";
	public static final String MESSAGE_SENT = "Message Sent successfully";
	public static final String MESSAGE_SENT_ERROR = "Sorry for the inconveniance.Please try again after some time";
	public static final String INTERNAL_SERVER_ERROR_CODE = "500";
	public static final String DATABASE_CODE = "404";
	public static final String DATABASE_MESSAGE_SENT = "EmployeeId not found";
	public static final String DATABASE_SAVED = "Message saved successfully";
	public static final String DATABASE_MESSAGE_SAVED = "Sorry for the inconveniance. Message not saved. Please try again after some time ";

	public static final String REQUEST_TIMEOUT_MSG = "Looks like the server is taking to long to respond, please try again in sometime";
	public static final String INTERNAL_SERVER_ERROR_MSG = "Request not processed due to Internal server error";
	public static final String BAD_REQUEST_MSG = "Bad request. The request could not be understood by the server due to malformed syntax. The client should not repeat the request without modifications.";
	public static final String UNAUTHORISED_MSG = "User not authorised to access this web source";
	public static final String CLEVERTAP_HttpsURL = "https://in.api.clevertap.com/1/send/push.json";
	public static final String CLEVERTAP_KEY = "X-CleverTap-Account-Id";
	public static final String CLEVERTAP_PASSCODE = "X-CleverTap-Passcode";
	public static final String CLEVERTAP_ENDPOINT_USERNAME = "TEST-ZRZ-586-KR5Z";
	public static final String CLEVERTAP_ENDPOINT_PASS = "GOK-JQY-GWKL";
	// public static final String PUSH_HttpsURL =
	// "https://fcm.googleapis.com/fcm/send";
	public static final String PUSH_KEY = "Authorization";
	// public static final String PUSH_ENDPOINT_KEY =
	// "key=AIzaSyC2TECo09spLuGriFgMIJ4CnxNncNT_oA4";
	public static final String HTTP_POST_REQUEST = "POST";
	public static final String HTTP_APPICATION_JSON = "application/json";
	public static final String HTTP_REQUEST_PROPERTY_AUTH = "Authorization";
	public static final String HTTP_REQUEST_PROPERTY_AUTH_BASIC = "Basic ";
	public static final String HTTP_REQUEST_CONTENT_TYPE = "Content-Type";
	public static final String DESIGNATION_MANAGER = "MANAGER";
	public static final String SOCKET_ID = "socketId";
	public static final String NOTIFICATION_HISTORY_TOPIC = "/topic/notification/history/";

	public static final String LEAVE_APPLY = "Leave";
	public static final String REGULARIZE = "Regularize";
	public static final String APPROVE_ICON = "approve_icon";
	public static final String APPROVE_TITLE = "APPROVE";
	public static final String APPROVE_CALLBACK = "approve";
	public static final String FOREGROUND = "False";
	public static final String REJECT_ICON = "reject_icon";
	public static final String REJECT_TITLE = "REJECT";
	public static final String REJECT_CALLBACK = "reject";
	public static final String IOS_BUTTON = "invite";

	public static final String IOS_NOT_ID = "1";
	public static final String ANDROID_CHANNEL_ID = "mychannel";
	public static final Integer FORCE_START = 1;
	public static final String CONTENT_AVAILABLE = "1";
	public static final String READ_TIMEOUT_FILTER_MSG = "Read timed out";
	public static final Integer REDIS_CACHE_TTL_MILLIS = 21600000; // 6 Hours
	public static final String AUTH_DELIMITER = ":";
	public static final String SAP_PERSON_PREFIX = "P";
	public static final String JSON_PROCESSING_FALIED_MSG = "JSON Processing Failed due to some reason, please debug";

	public static final String SAP_JSON_ROOT = "d";
	public static final String SAP_JSON_RESULTS = "results";
	public static final String SAP_ATTENDANCE_PROCESSED = "PRS";
	public static final Long NO_OF_DAYS_IN_WEEK = 7L;
	public static final String WEEKLY_OFF_SHFALL_IDENTIFIER = "WO/PL DED";
	public static final String WEEKLY_OFF_PROCESSED = "PRS/WO";
	public static final String WEEKLY_OFF_ATT_STATUS = "WO";
	public static final Double DEFAULT_SHIFT_TIME = 9.0;
	public static final String DEFAULT_EMPLYEEID = "00000000";

	public static final String HTTP_GET_REQUEST = "GET";
	public static final String HTTP_DELETE_REQUEST = "DELETE";
	public static final String HTTP_MULTIPART_DATA = "multipart/form-data";
	public static final String HTTP_REQUEST_PROPERTY_CSRF_TOKEN = "x-csrf-token";
	public static final String HTTP_REQUEST_PROPERTY_CSRF_TOKEN_PARAM = "fetch";
	public static final String HTTP_REQUEST_PROPERTY_COOKIE = "cookie";
	public static final String HTTP_REQUEST_PROPERTY_SET_COOKIE_CAPS = "Set-Cookie";
	public static final String HTTP_REQUEST_PROPERTY_SET_COOKIE = "set-cookie";
	public static final String HTTP_REQUEST_PROPERTY_SET_COOKIE_SESSIONID = "SAP_SESSIONID_NGD_186";
	public static final String HTTP_REQUEST_PROPERTY_SET_COOKIE_SSO2 = "MYSAPSSO2";
	public static final String HTTP_HEADER_REGEX_MANIPULATION = "[\r\n]";
	public static final String HTTP_REQUEST_ACCEPT = "Accept";
	public static final String SAP_ERROR_ROOT = "error";
	public static final String SAP_INNER_ERROR = "innererror";
	public static final String SAP_ERROR_DETAILS = "errordetails";
	public static final String DEFAULT_USER_KEY = "default";
	public static final String HYPEN = "-";
	public static final String PDF_FILE_TYPE = ".pdf";
	public static final String DEFAULT_FILE_NAME = "download";
	public static final String HTTP_HEADER_FILE_ATTACHMENT = "attachment";
	public static final String HTTP_HEADER_FILE_NAME = "filename";
	public static final String DEFAULT_SAP_TIME_FORMAT = "PT00H00M00S";
	public static final String LINE_FEED = "\\n";
	public static final String SAP_DUMMY_LEAVE_ID = "0000";

	public static final Float DUMMY_BALANCE = 2000f;
	public static final Float APL_DUMMY_BALANCE = 24f;
	public static final String APL_LEAVE_CODE = "0105";

	public static final String ATT_STATUS_WEEKLY_OFF = "WO";
	public static final String ATT_STATUS_PUBLIC_HOLIDAY = "PH";
	public static final String ATT_PROCESSED_STATUS_PUBLIC_HOLIDAY = "PRS/PH";
	public static final String SHIFT_TYPE_WEEKLY_OFF = "OFF";
	public static final String ATT_STATUS_PENDING = "Pending";
	public static final String WEEK_IDENTIFIER = "week_";
	public static final String ATT_STATUS_APPROVED = "Approved";
	public static final String FILTER_HYPHEN = "-";

	public static final String HTTP_APPICATION_PDF = "application/pdf";
	public static final String HTTP_SAP_FILE_SLUG = "slug";
	public static final String STRING_EQUAL = "=";
	public static final String HTTP_HEADER_CACHE_CONTROL = "Cache-Control";
	public static final String HTTP_HEADER_CACHE_CONTROL_REVALIDATE = "cache, must-revalidate";
	public static final String HTTP_HEADER_PRAGMA = "Pragma";
	public static final String HTTP_HEADER_PRAGMA_PUBLIC = "public";
	public static final String HTTP_HEADER_CONTENT_DISPOSITION = "Content-Disposition";
	public static final String HTTP_HEADER_CONTENT_DISPOSITION_ATTACH_FILE = "attachment; filename=";
	public static final String HTTP_HEADER_CONTENT_DISPOSITION_VIEW_FILE = "inline; filename=";
	public static final String HTTP_PUT_REQUEST = "PUT";
	public static final String COLON = ":";

}