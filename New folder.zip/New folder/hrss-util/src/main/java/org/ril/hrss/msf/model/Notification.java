package org.ril.hrss.msf.model;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Notification {

	private String message;
	private String title;
	private String[] registration_ids;

	public Notification() {
		super();
	}

	public Notification(String message, String title, String[] registration_ids) {
		super();
		this.message = message;
		this.title = title;
		this.registration_ids = registration_ids;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String[] getRegistration_ids() {
		return registration_ids;
	}

	public void setRegistration_ids(String[] registration_ids) {
		this.registration_ids = registration_ids;
	}

	@Override
	public String toString() {
		return "Notification [message=" + message + ", title=" + title + ", registration_ids="
				+ Arrays.toString(registration_ids) + "]";
	}

}
