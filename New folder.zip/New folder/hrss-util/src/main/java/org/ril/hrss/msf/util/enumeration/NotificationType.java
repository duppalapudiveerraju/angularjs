package org.ril.hrss.msf.util.enumeration;

public enum NotificationType {

	APPROVALS, ALERTS

}