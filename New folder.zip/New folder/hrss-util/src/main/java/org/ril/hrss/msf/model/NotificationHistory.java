package org.ril.hrss.msf.model;

import java.util.Date;

import org.ril.hrss.msf.util.enumeration.NotificationType;
import org.ril.hrss.msf.util.enumeration.ServiceType;

public class NotificationHistory {

	private String id;
	private Integer uniqueId;
	private String employeeId;
	private String title;
	private String description;
	private Date postedOn;
	private Boolean status;
	private String onUserAction;
	private NotificationType notificationType;
	private ServiceType serviceType;

	public NotificationHistory() {
		super();
	}

	public NotificationHistory(Integer uniqueId, String employeeId, String title, String description, Date postedOn,
			Boolean status, String onUserAction, NotificationType notificationType, ServiceType serviceType) {
		super();
		this.uniqueId = uniqueId;
		this.employeeId = employeeId;
		this.title = title;
		this.description = description;
		this.postedOn = postedOn;
		this.status = status;
		this.onUserAction = onUserAction;
		this.notificationType = notificationType;
		this.serviceType = serviceType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(Integer uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getPostedOn() {
		return postedOn;
	}

	public void setPostedOn(Date postedOn) {
		this.postedOn = postedOn;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getOnUserAction() {
		return onUserAction;
	}

	public void setOnUserAction(String onUserAction) {
		this.onUserAction = onUserAction;
	}

	public NotificationType getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(NotificationType notificationType) {
		this.notificationType = notificationType;
	}

	public ServiceType getServiceType() {
		return serviceType;
	}

	public void setServiceType(ServiceType serviceType) {
		this.serviceType = serviceType;
	}

	@Override
	public String toString() {
		return "NotificationHistory [id=" + id + ", uniqueId=" + uniqueId + ", employeeId=" + employeeId + ", title="
				+ title + ", description=" + description + ", postedOn=" + postedOn + ", status=" + status
				+ ", onUserAction=" + onUserAction + ", notificationType=" + notificationType + ", serviceType="
				+ serviceType + "]";
	}

}