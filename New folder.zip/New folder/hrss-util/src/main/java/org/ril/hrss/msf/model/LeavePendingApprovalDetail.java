package org.ril.hrss.msf.model;

import java.util.Date;

public class LeavePendingApprovalDetail {

	private String attachDocId;
	private Date applyDate;
	private String leaveRequestId;
	private boolean slaBreached;
	private String employeeId;
	private String employeeName;
	private Date leaveFromDate;
	private Date leaveToDate;
	private String leaveDesc;
	private Double leaveNoOfDays;
	private String leaveRemark;

	public LeavePendingApprovalDetail() {
		super();
	}

	public LeavePendingApprovalDetail(String attachDocId, Date applyDate, String leaveRequestId, boolean slaBreached,
			String employeeId, String employeeName, Date leaveFromDate, Date leaveToDate, String leaveDesc,
			Double leaveNoOfDays, String leaveRemark) {
		super();
		this.attachDocId = attachDocId;
		this.applyDate = applyDate;
		this.leaveRequestId = leaveRequestId;
		this.slaBreached = slaBreached;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.leaveFromDate = leaveFromDate;
		this.leaveToDate = leaveToDate;
		this.leaveDesc = leaveDesc;
		this.leaveNoOfDays = leaveNoOfDays;
		this.leaveRemark = leaveRemark;
	}

	public String getAttachDocId() {
		return attachDocId;
	}

	public void setAttachDocId(String attachDocId) {
		this.attachDocId = attachDocId;
	}

	public Date getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	public String getLeaveRequestId() {
		return leaveRequestId;
	}

	public void setLeaveRequestId(String leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	public boolean isSlaBreached() {
		return slaBreached;
	}

	public void setSlaBreached(boolean slaBreached) {
		this.slaBreached = slaBreached;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Date getLeaveFromDate() {
		return leaveFromDate;
	}

	public void setLeaveFromDate(Date leaveFromDate) {
		this.leaveFromDate = leaveFromDate;
	}

	public Date getLeaveToDate() {
		return leaveToDate;
	}

	public void setLeaveToDate(Date leaveToDate) {
		this.leaveToDate = leaveToDate;
	}

	public String getLeaveDesc() {
		return leaveDesc;
	}

	public void setLeaveDesc(String leaveDesc) {
		this.leaveDesc = leaveDesc;
	}

	public Double getLeaveNoOfDays() {
		return leaveNoOfDays;
	}

	public void setLeaveNoOfDays(Double leaveNoOfDays) {
		this.leaveNoOfDays = leaveNoOfDays;
	}

	public String getLeaveRemark() {
		return leaveRemark;
	}

	public void setLeaveRemark(String leaveRemark) {
		this.leaveRemark = leaveRemark;
	}

	@Override
	public String toString() {
		return "LeavePendingApprovalDetail [attachDocId=" + attachDocId + ", applyDate=" + applyDate
				+ ", leaveRequestId=" + leaveRequestId + ", slaBreached=" + slaBreached + ", employeeId=" + employeeId
				+ ", employeeName=" + employeeName + ", leaveFromDate=" + leaveFromDate + ", leaveToDate=" + leaveToDate
				+ ", leaveDesc=" + leaveDesc + ", leaveNoOfDays=" + leaveNoOfDays + ", leaveRemark=" + leaveRemark
				+ "]";
	}

}