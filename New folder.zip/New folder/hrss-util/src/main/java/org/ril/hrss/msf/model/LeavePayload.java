package org.ril.hrss.msf.model;

public class LeavePayload {
	private String employeeId;

	private String attachDocId;

	private String leaveRemark;

	private String leaveToDate;

	private String leaveFromDate;

	private String leaveDesc;

	private String leaveNoOfDays;

	private String slaBreached;

	private String leaveRequestId;

	private String approvalAction;

	private String employeeName;

	private String applyDate;

	public LeavePayload() {
		super();
	}

	public LeavePayload(String employeeId, String attachDocId, String leaveRemark, String leaveToDate,
			String leaveFromDate, String leaveDesc, String leaveNoOfDays, String slaBreached, String leaveRequestId,
			String approvalAction, String employeeName, String applyDate) {
		super();
		this.employeeId = employeeId;
		this.attachDocId = attachDocId;
		this.leaveRemark = leaveRemark;
		this.leaveToDate = leaveToDate;
		this.leaveFromDate = leaveFromDate;
		this.leaveDesc = leaveDesc;
		this.leaveNoOfDays = leaveNoOfDays;
		this.slaBreached = slaBreached;
		this.leaveRequestId = leaveRequestId;
		this.approvalAction = approvalAction;
		this.employeeName = employeeName;
		this.applyDate = applyDate;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getAttachDocId() {
		return attachDocId;
	}

	public void setAttachDocId(String attachDocId) {
		this.attachDocId = attachDocId;
	}

	public String getLeaveRemark() {
		return leaveRemark;
	}

	public void setLeaveRemark(String leaveRemark) {
		this.leaveRemark = leaveRemark;
	}

	public String getLeaveToDate() {
		return leaveToDate;
	}

	public void setLeaveToDate(String leaveToDate) {
		this.leaveToDate = leaveToDate;
	}

	public String getLeaveFromDate() {
		return leaveFromDate;
	}

	public void setLeaveFromDate(String leaveFromDate) {
		this.leaveFromDate = leaveFromDate;
	}

	public String getLeaveDesc() {
		return leaveDesc;
	}

	public void setLeaveDesc(String leaveDesc) {
		this.leaveDesc = leaveDesc;
	}

	public String getLeaveNoOfDays() {
		return leaveNoOfDays;
	}

	public void setLeaveNoOfDays(String leaveNoOfDays) {
		this.leaveNoOfDays = leaveNoOfDays;
	}

	public String getSlaBreached() {
		return slaBreached;
	}

	public void setSlaBreached(String slaBreached) {
		this.slaBreached = slaBreached;
	}

	public String getLeaveRequestId() {
		return leaveRequestId;
	}

	public void setLeaveRequestId(String leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	public String getApprovalAction() {
		return approvalAction;
	}

	public void setApprovalAction(String approvalAction) {
		this.approvalAction = approvalAction;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}

	@Override
	public String toString() {
		return "ClassPojo [employeeId = " + employeeId + ", attachDocId = " + attachDocId + ", leaveRemark = "
				+ leaveRemark + ", leaveToDate = " + leaveToDate + ", leaveFromDate = " + leaveFromDate
				+ ", leaveDesc = " + leaveDesc + ", leaveNoOfDays = " + leaveNoOfDays + ", slaBreached = " + slaBreached
				+ ", leaveRequestId = " + leaveRequestId + ", approvalAction = " + approvalAction + ", employeeName = "
				+ employeeName + ", applyDate = " + applyDate + "]";
	}
}
