package org.ril.hrss.msf.util.enumeration;

import org.ril.hrss.msf.util.HRSSConstantUtil;

public enum NotificationDetails {

	PLAN_MY_LEAVE("Plan My Leave", NotificationType.APPROVALS, ServiceType.LEAVE,
			"MANAGER_APPROVALS"), REG_MY_ATTENDANCE("Regularize My Attendance", NotificationType.APPROVALS,
					ServiceType.REGULARIZE, "MANAGER_APPROVALS"), MANAGER_APPROVALS("Manager Approvals",
							NotificationType.ALERTS, ServiceType.APPROVALS,
							"MANAGE_MY_ATTENDANCE"), MANAGE_MY_ATTENDANCE("Manage My Attendance",
									NotificationType.ALERTS, ServiceType.MANAGE_MY_ATTENDANCE,
									"MANAGE_MY_ATTENDANCE"), DEFAULT("", NotificationType.ALERTS,
											ServiceType.MANAGE_MY_ATTENDANCE,
											"MANAGE_MY_ATTENDANCE"), LEAVE_APPLICATION_FAILED(
													HRSSConstantUtil.LEAVE_FAIL_MSG, NotificationType.ALERTS,
													ServiceType.LEAVE, "PLAN_MY_LEAVE"), REG_APPLICATION_FAILED(
															HRSSConstantUtil.REGULARIZE_FAIL_MSG,
															NotificationType.ALERTS, ServiceType.REGULARIZE,
															"MANAGE_MY_ATTENDANCE");

	private String notificationTitle;
	private String onUserAction;
	private ServiceType serviceType;
	private NotificationType notificationType;

	NotificationDetails(String notificationTitle, NotificationType notificationType, ServiceType serviceType,
			String onUserAction) {
		this.notificationTitle = notificationTitle;
		this.onUserAction = onUserAction;
		this.serviceType = serviceType;
		this.notificationType = notificationType;
	}

	public String getNotificationTitle() {
		return notificationTitle;
	}

	public void setNotificationTitle(String notificationTitle) {
		this.notificationTitle = notificationTitle;
	}

	public String getOnUserAction() {
		return onUserAction;
	}

	public void setOnUserAction(String onUserAction) {
		this.onUserAction = onUserAction;
	}

	public NotificationType getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(NotificationType notificationType) {
		this.notificationType = notificationType;
	}

	public ServiceType getServiceType() {
		return serviceType;
	}

	public void setServiceType(ServiceType serviceType) {
		this.serviceType = serviceType;
	}

	public static NotificationDetails fromNotificationTitle(String text) {
		for (NotificationDetails a : NotificationDetails.values()) {
			if (a.getNotificationTitle().equals(text.trim())) {
				return a;
			}
		}
		return NotificationDetails.DEFAULT;
	}

}