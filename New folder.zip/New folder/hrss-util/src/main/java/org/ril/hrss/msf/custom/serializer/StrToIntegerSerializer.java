package org.ril.hrss.msf.custom.serializer;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class StrToIntegerSerializer extends StdConverter<String, Integer> {

	@Override
	public Integer convert(String obj) {
		return obj != null ? !obj.isEmpty() ? Integer.parseInt(obj) : HRSSConstantUtil.ZERO.intValue()
				: HRSSConstantUtil.ZERO.intValue();
	}

}
