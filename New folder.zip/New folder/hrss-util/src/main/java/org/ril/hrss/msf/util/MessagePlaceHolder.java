package org.ril.hrss.msf.util;

import java.text.MessageFormat;

public class MessagePlaceHolder {

	public static String formater(String msg, Object... obj) {
		return MessageFormat.format(msg, obj);
	}

}
