package org.ril.hrss.msf.custom.serializer;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class EmptyStringSerializer extends StdConverter<String, String> {

	@Override
	public String convert(String obj) {
		return obj != null ? obj : HRSSConstantUtil.EMPTY_STRING;
	}

}