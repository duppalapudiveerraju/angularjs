package org.ril.hrss.msf.custom.serializer;

import java.util.Date;

import org.ril.hrss.msf.util.DateUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class SAPStringToDateFormatSerailizer extends StdConverter<String, Date> {

	@Override
	public Date convert(String obj) {
		return obj != null ? DateUtil.getFormattedDateFromClockFormat(obj, new Date()) : null;
	}

}