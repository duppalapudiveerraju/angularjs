package org.ril.hrss.msf.util;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.enumeration.SAPGenericError;

public class SAPErrorHandlerUtil {

	private Map<String, String> errMap;

	public SAPErrorHandlerUtil() {
		super();
		errMap = setErrMap();
	}

	public String getCustomErrorMsg(String errCode, String errMsg) {
		if (errMap.containsKey(errCode.trim())) {
			return errMap.get(errCode.trim());
		} else if (errMap.containsKey(errMsg.trim())) {
			return errMap.get(errMsg.trim());
		} else if (errMsg.trim().toUpperCase().contains(HRSSConstantUtil.SAP_INTERNAL_ERROR_MSG)) {
			return HRSSConstantUtil.GENERIC_ERROR_MESSAGE;
		} else if (errMsg.trim().toUpperCase().contains(HRSSConstantUtil.SAP_COLLISION_ERROR_MSG)) {
			return HRSSConstantUtil.GENERIC_ERROR_MESSAGE;
		} else {
			return HRSSConstantUtil.GENERIC_ERROR_MESSAGE;
		}
	}

	public String setCustomErrMsg(final Map<String, String> map, SAPGenericError sapGenericError) {
		return map.get(HRSSConstantUtil.POST_RESPONSE_ERR_MSG) != null
				? map.get(HRSSConstantUtil.POST_RESPONSE_ERR_MSG).equals(HRSSConstantUtil.GENERIC_ERROR_MESSAGE)
						? sapGenericError.getGenericMsg()
						: map.get(HRSSConstantUtil.POST_RESPONSE_ERR_MSG)
				: null;
	}

	private Map<String, String> setErrMap() {
		Map<String, String> errMap = new HashMap<String, String>();
		errMap.put("Starting date not entered.", "Please enter the Start Date");
		errMap.put("Ending date not entered.", "Please enter the End Date");
		errMap.put("Leave request was sent successfully", "Congratulations! Leave request was sent successfully");
		errMap.put("Leave type does not exists in the system",
				"Sorry! This leave type does not exist!. Please select another Leave Type");
		errMap.put("ZHR_TMMMSG/007", "LTA has already been approved .PL Cancellation is not allowed now");
		errMap.put("Provide User, Workdate, Reg.In punch, Reg.Out punch",
				"Please fill in mandatory details User, Workdate, Reg.In punch, Reg.Out punch");
		errMap.put("WageCycle Table not maintained, Please Contact HR.",
				"Sorry! Wage cycle (Financial year cut off) has lapsed  .Please contact HR for further queries");
		errMap.put("One Wage Cycle has expired. You cannot apply.",
				"Sorry! Wage cycle (Financial year cut off) lapsed .Please contact HR for further queries");
		errMap.put("One Wage Cycle has expired. You cannot apply",
				"Sorry! Wage cycle (Financial year cut off) lapsed .Please contact HR for further queries");
		errMap.put("Regularisation beyond  &NoOfDays Days cannot be applied.",
				"Sorry! Regularization cut off has expired .Please contact HR for further queries");
		errMap.put("Half day leave exists. Full day Attendance Regularisation not allowed.",
				"Half day leave already exists. Full day Attendance Regularisation not allowed.");
		errMap.put("Regularised IN and OUT Timings are Same.",
				"Please make sure Regularized in and Out time are different");
		errMap.put("HRESS_PTARQ/010", "Please make sure End time does not match to begin time");
		errMap.put("ZTMMPOWL/002", "Sorry,there was some error .Please try after some time");
		errMap.put("ZTMMPOWL/003", "Please enter Employee id");
		return errMap;
	}

}