package org.ril.hrss.msf.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class FindDateRange {

	public static List<String> findRange(List<Date> regDateList) {
		Collections.sort(regDateList);
		List<String> resultSet = new ArrayList<>();
		List<Date> dateList = new ArrayList<>();
		long oneDay = DateUtil.getDaysOffset(HRSSConstantUtil.ONE.intValue());
		for (Date DateObj : regDateList) {
			if (dateList.isEmpty()) {
				dateList.add(DateObj);
			} else if ((dateList.get(dateList.size() - HRSSConstantUtil.ONE.intValue())).getTime() + oneDay == DateObj
					.getTime()) {
				dateList.add(DateObj);
			} else {
				resultSet.add(formatRange(dateList));
				dateList.clear();
				dateList.add(DateObj);
			}
		}
		resultSet.add(formatRange(dateList));
		return resultSet;
	}

	@SuppressWarnings("deprecation")
	private static String formatRange(List<Date> dateList) {
		if (!dateList.isEmpty()) {
			Date firstDate = dateList.get(HRSSConstantUtil.ZERO.intValue());
			Date lastDate = dateList.get(dateList.size() - HRSSConstantUtil.ONE.intValue());
			if (firstDate.equals(lastDate)) {
				return (int) firstDate.getDate() + HRSSConstantUtil.SPACE + DateUtil.getSimpleFormatMonth(firstDate)
						+ HRSSConstantUtil.SPACE_COMMA + DateUtil.getYearFromDate(firstDate);
			} else if (firstDate.getYear() == lastDate.getYear()) {
				return (int) firstDate.getDate() + HRSSConstantUtil.SPACE + DateUtil.getSimpleFormatMonth(firstDate)
						+ HRSSConstantUtil.TO + (int) lastDate.getDate() + HRSSConstantUtil.SPACE
						+ DateUtil.getSimpleFormatMonth(lastDate) + HRSSConstantUtil.SPACE_COMMA
						+ DateUtil.getYearFromDate(lastDate);
			} else {
				return (int) firstDate.getDate() + HRSSConstantUtil.SPACE + DateUtil.getSimpleFormatMonth(firstDate)
						+ HRSSConstantUtil.SPACE_COMMA + DateUtil.getYearFromDate(firstDate) + HRSSConstantUtil.TO
						+ (int) lastDate.getDate() + HRSSConstantUtil.SPACE + DateUtil.getSimpleFormatMonth(lastDate)
						+ HRSSConstantUtil.SPACE_COMMA + DateUtil.getYearFromDate(lastDate);
			}
		} else {
			return HRSSConstantUtil.EMPTY_STRING;
		}
	}

}