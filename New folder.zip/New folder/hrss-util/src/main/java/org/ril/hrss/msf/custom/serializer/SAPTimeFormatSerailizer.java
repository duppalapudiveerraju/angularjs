package org.ril.hrss.msf.custom.serializer;

import java.util.Date;

import org.ril.hrss.msf.util.DateUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class SAPTimeFormatSerailizer extends StdConverter<Date, String> {

	@Override
	public String convert(Date obj) {
		return obj != null ? DateUtil.getFormattedStrFromDate(obj) : "PT00H00M00S";
	}

}