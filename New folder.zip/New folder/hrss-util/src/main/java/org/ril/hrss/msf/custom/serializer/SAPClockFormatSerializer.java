package org.ril.hrss.msf.custom.serializer;

import java.util.Date;

import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class SAPClockFormatSerializer extends StdConverter<Date, String> {

	@Override
	public String convert(Date obj) {
		String strObj = obj != null ? DateUtil.getFormattedClockTimeFromDate(obj) : HRSSConstantUtil.EMPTY_STRING;
		return strObj;
	}

}