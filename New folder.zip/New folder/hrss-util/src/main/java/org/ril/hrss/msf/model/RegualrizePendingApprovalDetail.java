package org.ril.hrss.msf.model;

import java.util.Date;

public class RegualrizePendingApprovalDetail {

	private Date applyDate;
	private String employeeId;
	private boolean slaBreached;
	private String employeeName;
	private Date regDate;
	private String shiftType;
	private Date actualIn;
	private Date actualOut;
	private Date regIn;
	private Date regOut;
	private Double regHrs;
	private String regStatus;
	private String regReason;
	private String regRemark;
	private String regCounter;

	public RegualrizePendingApprovalDetail() {
		super();
	}

	public RegualrizePendingApprovalDetail(Date applyDate, String employeeId, boolean slaBreached, String employeeName,
			Date regDate, String shiftType, Date actualIn, Date actualOut, Date regIn, Date regOut, Double regHrs,
			String regStatus, String regReason, String regRemark, String regCounter) {
		super();
		this.applyDate = applyDate;
		this.employeeId = employeeId;
		this.slaBreached = slaBreached;
		this.employeeName = employeeName;
		this.regDate = regDate;
		this.shiftType = shiftType;
		this.actualIn = actualIn;
		this.actualOut = actualOut;
		this.regIn = regIn;
		this.regOut = regOut;
		this.regHrs = regHrs;
		this.regStatus = regStatus;
		this.regReason = regReason;
		this.regRemark = regRemark;
		this.regCounter = regCounter;
	}

	public Date getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public boolean isSlaBreached() {
		return slaBreached;
	}

	public void setSlaBreached(boolean slaBreached) {
		this.slaBreached = slaBreached;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getShiftType() {
		return shiftType;
	}

	public void setShiftType(String shiftType) {
		this.shiftType = shiftType;
	}

	public Date getActualIn() {
		return actualIn;
	}

	public void setActualIn(Date actualIn) {
		this.actualIn = actualIn;
	}

	public Date getActualOut() {
		return actualOut;
	}

	public void setActualOut(Date actualOut) {
		this.actualOut = actualOut;
	}

	public Date getRegIn() {
		return regIn;
	}

	public void setRegIn(Date regIn) {
		this.regIn = regIn;
	}

	public Date getRegOut() {
		return regOut;
	}

	public void setRegOut(Date regOut) {
		this.regOut = regOut;
	}

	public Double getRegHrs() {
		return regHrs;
	}

	public void setRegHrs(Double regHrs) {
		this.regHrs = regHrs;
	}

	public String getRegStatus() {
		return regStatus;
	}

	public void setRegStatus(String regStatus) {
		this.regStatus = regStatus;
	}

	public String getRegReason() {
		return regReason;
	}

	public void setRegReason(String regReason) {
		this.regReason = regReason;
	}

	public String getRegRemark() {
		return regRemark;
	}

	public void setRegRemark(String regRemark) {
		this.regRemark = regRemark;
	}

	public String getRegCounter() {
		return regCounter;
	}

	public void setRegCounter(String regCounter) {
		this.regCounter = regCounter;
	}

	@Override
	public String toString() {
		return "RegualrizePendingApprovalDetail [applyDate=" + applyDate + ", employeeId=" + employeeId
				+ ", slaBreached=" + slaBreached + ", employeeName=" + employeeName + ", regDate=" + regDate
				+ ", shiftType=" + shiftType + ", actualIn=" + actualIn + ", actualOut=" + actualOut + ", regIn="
				+ regIn + ", regOut=" + regOut + ", regHrs=" + regHrs + ", regStatus=" + regStatus + ", regReason="
				+ regReason + ", regRemark=" + regRemark + ", regCounter=" + regCounter + "]";
	}

}