package org.ril.hrss.msf.model;

import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class NotificationJson {

	private String message;
	private String title;
	private List<Object> payload;
	private String[] registration_ids;
	private String serviceType;
	private String serviceEndPoint;

	public NotificationJson() {
		super();
	}

	public NotificationJson(String message, String title, List<Object> payload, String[] registration_ids,
			String serviceType, String serviceEndPoint) {
		super();
		this.message = message;
		this.title = title;
		this.payload = payload;
		this.registration_ids = registration_ids;
		this.serviceType = serviceType;
		this.serviceEndPoint = serviceEndPoint;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Object> getPayload() {
		return payload;
	}

	public void setPayload(List<Object> payload) {
		this.payload = payload;
	}

	public String[] getRegistration_ids() {
		return registration_ids;
	}

	public void setRegistration_ids(String[] registration_ids) {
		this.registration_ids = registration_ids;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServiceEndPoint() {
		return serviceEndPoint;
	}

	public void setServiceEndPoint(String serviceEndPoint) {
		this.serviceEndPoint = serviceEndPoint;
	}

	@Override
	public String toString() {
		return "NotificationJson [message=" + message + ", title=" + title + ", payload=" + payload
				+ ", registration_ids=" + Arrays.toString(registration_ids) + ", serviceType=" + serviceType
				+ ", serviceEndPoint=" + serviceEndPoint + "]";
	}

}
