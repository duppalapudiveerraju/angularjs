package org.ril.hrss.msf.custom.serializer;

import com.fasterxml.jackson.databind.util.StdConverter;

public class SAPBooleanSerializer extends StdConverter<String, Boolean> {

	@Override
	public Boolean convert(String obj) {
		return obj != null ? obj.isEmpty() ? Boolean.FALSE : Boolean.TRUE : Boolean.FALSE;
	}

}