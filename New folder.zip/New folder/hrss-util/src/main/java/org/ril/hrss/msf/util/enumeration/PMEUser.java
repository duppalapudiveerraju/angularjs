package org.ril.hrss.msf.util.enumeration;

public enum PMEUser {

	SELF("SE"), SPOUSE("SP");

	private String shortTxt;

	private PMEUser(String shortTxt) {
		this.shortTxt = shortTxt;
	}

	public String getShortTxt() {
		return shortTxt;
	}

	public void setShortTxt(String shortTxt) {
		this.shortTxt = shortTxt;
	}

}