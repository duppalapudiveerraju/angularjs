package org.ril.hrss.bookmark.repository;

import java.util.List;

import org.ril.hrss.bookmark.model.BookmarkApp;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BookmarkAppRepository extends CrudRepository<BookmarkApp, Long> {

	@Query("SELECT a.id FROM BookmarkApp a WHERE a.appId = (SELECT b.id FROM ApplicationInfo b WHERE b.appName=:appName) AND user_id=:userId")
	Integer getBookmarkAppIdByAppNameAndUserId(@Param("appName") String appName, @Param("userId") String userId);

	@Query("SELECT a FROM BookmarkApp a WHERE a.appId = (SELECT b.id FROM ApplicationInfo b WHERE b.appName=:appName) AND user_id=:userId")
	BookmarkApp getBookmarkAppByAppNameAndUserId(@Param("appName") String appName, @Param("userId") String userId);

	@Query(value = "SELECT a.appName FROM BookmarkApp a WHERE a.bookmarkStatus = 1 AND user_id=:userId")
	List<BookmarkApp> getBookmarkAppByUserId(@Param("userId") String userId);

	@Query("SELECT a FROM BookmarkApp a WHERE a.appId = (SELECT b.id FROM ApplicationInfo b WHERE b.appName=:appName) AND a.bookmarkStatus = 1 AND a.userId=:userId")
	BookmarkApp getBookmarkAppByAppName(@Param("appName") String appName, @Param("userId") String userId);

}