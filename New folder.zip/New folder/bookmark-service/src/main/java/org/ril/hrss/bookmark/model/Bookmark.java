package org.ril.hrss.bookmark.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Bookmark {

	@NotNull(message = "The AppName is a required field")
	@Size(min = 3, max = 50, message = "The AppName should be between 3 and 50 characters")
	private String appName;
	
	@NotNull(message = "The Bookmark status is a required field")
	private Boolean bookmarkStatus;

	public Bookmark() {
		super();
	}

	public Bookmark(String appName, Boolean bookmarkStatus) {
		super();
		this.appName = appName;
		this.bookmarkStatus = bookmarkStatus;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public Boolean getBookmarkStatus() {
		return bookmarkStatus;
	}

	public void setBookmarkStatus(Boolean bookmarkStatus) {
		this.bookmarkStatus = bookmarkStatus;
	}

	@Override
	public String toString() {
		return "Bookmark [appName=" + appName + ", bookmarkStatus=" + bookmarkStatus + "]";
	}

}