package org.ril.hrss.bookmark.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table
public class BookmarkApp {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotNull(message = "The AppId is a required field")
	private Integer appId;

	@NotNull(message = "The UserId is a required field")
	private String userId;

	@NotNull(message = "The AppName is a required field")
	@Size(min = 3, max = 50, message = "The AppName should be between 3 and 50 characters")
	private String appName;

	@NotNull(message = "The Bookmark status is a required field")
	private Boolean bookmarkStatus;

	public BookmarkApp() {
		super();
	}

	public BookmarkApp(Integer id, Integer appId, String userId, String appName, Boolean bookmarkStatus) {
		super();
		this.id = id;
		this.appId = appId;
		this.userId = userId;
		this.appName = appName;
		this.bookmarkStatus = bookmarkStatus;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getUserId() {
		return userId;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Boolean getBookmarkStatus() {
		return bookmarkStatus;
	}

	public void setBookmarkStatus(Boolean bookmarkStatus) {
		this.bookmarkStatus = bookmarkStatus;
	}

	@Override
	public String toString() {
		return "BookmarkApp [id=" + id + ", appId=" + appId + ", userId=" + userId + ", appName=" + appName
				+ ", bookmarkStatus=" + bookmarkStatus + "]";
	}

}