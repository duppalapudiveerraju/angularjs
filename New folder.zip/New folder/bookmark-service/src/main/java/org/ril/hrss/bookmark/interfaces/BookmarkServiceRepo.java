package org.ril.hrss.bookmark.interfaces;

import java.util.List;

import org.ril.hrss.bookmark.model.Bookmark;
import org.ril.hrss.bookmark.model.BookmarkApp;
import org.springframework.http.ResponseEntity;

public interface BookmarkServiceRepo {
	
	public ResponseEntity<List<BookmarkApp>> getBookmarkUserInfo(String userId);
	
	public void saveBookmarkUserInfo(Bookmark input, String userId);

	public ResponseEntity<BookmarkApp> getBookmarkUserInfoByAppName(String userId, String appName);

}