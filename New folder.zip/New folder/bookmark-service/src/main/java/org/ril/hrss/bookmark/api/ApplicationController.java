package org.ril.hrss.bookmark.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.bookmark.interfaces.BookmarkServiceRepo;
import org.ril.hrss.bookmark.model.Bookmark;
import org.ril.hrss.bookmark.model.BookmarkApp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/details")
@Api(value = "Bookmark details", description = "Operations pertaining to bookmark details")
public class ApplicationController {

	@Autowired
	private BookmarkServiceRepo bookmarkServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/{userId}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get bookmark request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrived list"),
			@ApiResponse(code = 201, message = "Successfully saved"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<List<BookmarkApp>> getBookmarkInfo(@PathVariable("userId") String userId) {
		logger.info("bookmark-service.getBookmarkInfo()");
		return bookmarkServiceRepo.getBookmarkUserInfo(userId);
	}

	@RequestMapping(value = "/info/{appName}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get bookmark request", response = BookmarkApp.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrived bookmark object"),
			@ApiResponse(code = 201, message = "Successfully saved"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<BookmarkApp> getBookmarkInfoByAppName(@PathVariable("appName") String appName,
			@NotNull @RequestHeader("userId") String userId) {
		logger.info("bookmark-service.getBookmarkInfoByAppName()");
		return bookmarkServiceRepo.getBookmarkUserInfoByAppName(userId, appName);
	}

	@RequestMapping(value = "/save/{userId}", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save bookmark request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully saved"),
			@ApiResponse(code = 201, message = "Successfully saved"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Bookmark> saveBookmarkRequest(@PathVariable("userId") String userId,
			@Validated @RequestBody Bookmark input) {
		logger.info("bookmark-service.saveBookmarkRequest()");
		bookmarkServiceRepo.saveBookmarkUserInfo(input, userId);
		return new ResponseEntity<Bookmark>(input, HttpStatus.OK);

	}
}