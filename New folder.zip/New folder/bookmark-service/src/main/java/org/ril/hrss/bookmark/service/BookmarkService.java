package org.ril.hrss.bookmark.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.bookmark.interfaces.BookmarkServiceRepo;
import org.ril.hrss.bookmark.model.ApplicationInfo;
import org.ril.hrss.bookmark.model.Bookmark;
import org.ril.hrss.bookmark.model.BookmarkApp;
import org.ril.hrss.bookmark.model.BookmarkHistory;
import org.ril.hrss.bookmark.repository.ApplicationInfoRepository;
import org.ril.hrss.bookmark.repository.BookmarkAppRepository;
import org.ril.hrss.bookmark.repository.BookmarkHistoryRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BookmarkService implements BookmarkServiceRepo {

	@Autowired
	private BookmarkHistoryRepository bookmarkHistoryRepo;

	@Autowired
	private BookmarkAppRepository bookmarkAppRepo;

	@Autowired
	private ApplicationInfoRepository applicationInfoRepo;

	protected static final Logger logger = Logger.getLogger(BookmarkService.class.getName());

	public BookmarkService() {
		super();
	}

	@Override
	@Transactional
	public ResponseEntity<List<BookmarkApp>> getBookmarkUserInfo(String userId) {
		logger.info("bookmarkService.getBookmarkUserInfo()");
		List<BookmarkApp> appObj = bookmarkAppRepo.getBookmarkAppByUserId(userId);
		if (appObj != null) {
			return new ResponseEntity<List<BookmarkApp>>(appObj, HttpStatus.OK);
		} else {
			return new ResponseEntity<List<BookmarkApp>>(new ArrayList<>(), HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	@Transactional
	public void saveBookmarkUserInfo(Bookmark input, String userId) {
		logger.info("bookmarkService.saveBookmarkUserInfo()");
		BookmarkHistory saveObj = new BookmarkHistory();
		BeanUtils.copyProperties(input, saveObj);
		saveObj.setUserId(userId);
		ApplicationInfo appInfo = applicationInfoRepo.getApplicationInfoByAppName(input.getAppName());
		if (appInfo != null) {
			saveObj.setAppId(appInfo.getId());
		} else {
			appInfo = new ApplicationInfo();
			appInfo.setAppName(input.getAppName());
			applicationInfoRepo.save(appInfo);
		}
		BookmarkApp appObj = bookmarkAppRepo.getBookmarkAppByAppNameAndUserId(input.getAppName(), userId);
		if (appObj != null) {
			appObj.setBookmarkStatus(input.getBookmarkStatus());
			bookmarkAppRepo.save(appObj);
		} else {
			appObj = new BookmarkApp();
			appObj.setAppId(appInfo.getId());
			appObj.setAppName(input.getAppName());
			appObj.setBookmarkStatus(input.getBookmarkStatus());
			appObj.setUserId(userId);
			bookmarkAppRepo.save(appObj);
		}
		saveObj.setAppId(bookmarkAppRepo.getBookmarkAppIdByAppNameAndUserId(input.getAppName(), userId));
		bookmarkHistoryRepo.save(saveObj);
		appObj.setBookmarkStatus(input.getBookmarkStatus());
		bookmarkAppRepo.save(appObj);
	}

	@Override
	public ResponseEntity<BookmarkApp> getBookmarkUserInfoByAppName(String userId, String appName) {
		logger.info("bookmarkService.getBookmarkUserInfoByAppName()");
		return new ResponseEntity<BookmarkApp>(bookmarkAppRepo.getBookmarkAppByAppName(appName, userId),
				HttpStatus.OK);
	}

}