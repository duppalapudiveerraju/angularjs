package org.ril.hrss.bookmark.repository;

import org.ril.hrss.bookmark.model.ApplicationInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface ApplicationInfoRepository extends CrudRepository<ApplicationInfo, Long> {

	@Query("SELECT a.id FROM ApplicationInfo a WHERE a.appName=:appName")
	Integer getApplicationIdByAppName(@Param("appName") String appName);

	@Query("SELECT a FROM ApplicationInfo a WHERE a.appName=:appName")
	ApplicationInfo getApplicationInfoByAppName(@Param("appName") String appName);
}
