package org.ril.hrss.bookmark.repository;

import java.util.List;

import org.ril.hrss.bookmark.model.BookmarkHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface BookmarkHistoryRepository extends CrudRepository<BookmarkHistory, Long> {

	@Query("SELECT a FROM BookmarkHistory a WHERE a.appId=(SELECT b.id FROM ApplicationInfo b WHERE b.appName=:appName)")
	List<BookmarkHistory> fetchBookmarkHistoryByAppName(@Param("appName") String appName);

}
