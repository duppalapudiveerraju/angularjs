package org.ril.hrss.houseloan.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.houseloan.sap.model.HouseLoanScreenDTO;
import org.ril.hrss.houseloan.ui.model.HouseLoanDetails;
import org.ril.hrss.houseloan.ui.model.HouseLoanScreen;
import org.ril.hrss.houseloan.ui.model.HousingLoanDetailScreen;
import org.ril.hrss.houseloan.ui.model.LendersType;
import org.ril.hrss.houseloan.util.HouseLoanUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Interest on House loan details", description = "Operations pertaining to find Interest on House loan details")
public class ApplicationController {

	@Autowired
	private HouseLoanUtil houseLoanUtil;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/detail", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View Interest on House loan detail", response = HouseLoanDetails.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved detail"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public HouseLoanDetails getInterestHouseLoanDetails(@NotNull @RequestHeader("userId") String userId)
			throws ClientException {
		logger.info("houseloan-service-controller.getInterestHouseLoanDetails()");
		return houseLoanUtil.getInterestHouseLoanDetails(userId);
	}

	@RequestMapping(value = "/detail/screen", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of Interest on Housing Loan Detail Screen", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<HousingLoanDetailScreen> getLoanDetailScreen(@NotNull @RequestHeader("userId") String userId)
			throws ClientException {
		logger.info("houseloan-service-controller.getLoanDetailScreen()");
		return houseLoanUtil.getLoanDetailScreen(userId);
	}

	@RequestMapping(value = "/lenderstype", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of Lenders Type", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<LendersType> getLendersType(@NotNull @RequestHeader("userId") String userId) throws ClientException {
		logger.info("houseloan-service-controller.getLoanDetailScreen(userId)");
		return houseLoanUtil.getLendersType(userId);

	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save a list of House Rent Declaration request", response = ResponseEntity.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully saved list of Interest on Housing Loan Detail Screen Save request"),
			@ApiResponse(code = 201, message = "Successfully saved list of Interest on Housing Loan Detail Screen Save request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<HouseLoanScreenDTO> saveLoanScreen(@NotNull @RequestHeader("userId") String userId,
			@RequestBody HouseLoanScreen input) throws ClientException {
		logger.info("houseloan-service-controller.saveLoanScreen()");
		return houseLoanUtil.saveLoanDetailScreen(userId, input);
	}

}