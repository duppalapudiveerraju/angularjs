package org.ril.hrss.houseloan.ui.model;

import java.util.Date;

public class HousingLoanDetailScreen {
	private String reqNo;
	private String seqnr;
	private String rento;
	private String rentoTxt;
	private Double letvl;
	private Double int24;
	private Double rep24;
	private Double oth24;
	private String lenam;
	private String lead1;
	private String lead2;
	private String lead3;
	private String lepan;
	private String letyp;
	private String letypText;
	private String attachementref;
	private Date zzacqfromdt;
	private String acknowledge;
	private boolean delflg;
	private String propAddr;

	public HousingLoanDetailScreen() {
		super();
	}

	public String getReqNo() {
		return reqNo;
	}

	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	public String getSeqnr() {
		return seqnr;
	}

	public void setSeqnr(String seqnr) {
		this.seqnr = seqnr;
	}

	public String getRento() {
		return rento;
	}

	public void setRento(String rento) {
		this.rento = rento;
	}

	public String getRentoTxt() {
		return rentoTxt;
	}

	public void setRentoTxt(String rentoTxt) {
		this.rentoTxt = rentoTxt;
	}

	public Double getLetvl() {
		return letvl;
	}

	public void setLetvl(Double letvl) {
		this.letvl = letvl;
	}

	public Double getInt24() {
		return int24;
	}

	public void setInt24(Double int24) {
		this.int24 = int24;
	}

	public Double getRep24() {
		return rep24;
	}

	public void setRep24(Double rep24) {
		this.rep24 = rep24;
	}

	public Double getOth24() {
		return oth24;
	}

	public void setOth24(Double oth24) {
		this.oth24 = oth24;
	}

	public String getLenam() {
		return lenam;
	}

	public void setLenam(String lenam) {
		this.lenam = lenam;
	}

	public String getLead1() {
		return lead1;
	}

	public void setLead1(String lead1) {
		this.lead1 = lead1;
	}

	public String getLead2() {
		return lead2;
	}

	public void setLead2(String lead2) {
		this.lead2 = lead2;
	}

	public String getLead3() {
		return lead3;
	}

	public void setLead3(String lead3) {
		this.lead3 = lead3;
	}

	public String getLepan() {
		return lepan;
	}

	public void setLepan(String lepan) {
		this.lepan = lepan;
	}

	public String getLetyp() {
		return letyp;
	}

	public void setLetyp(String letyp) {
		this.letyp = letyp;
	}

	public String getLetypText() {
		return letypText;
	}

	public void setLetypText(String letypText) {
		this.letypText = letypText;
	}

	public String getAttachementref() {
		return attachementref;
	}

	public void setAttachementref(String attachementref) {
		this.attachementref = attachementref;
	}

	public Date getZzacqfromdt() {
		return zzacqfromdt;
	}

	public void setZzacqfromdt(Date zzacqfromdt) {
		this.zzacqfromdt = zzacqfromdt;
	}

	public String getAcknowledge() {
		return acknowledge;
	}

	public void setAcknowledge(String acknowledge) {
		this.acknowledge = acknowledge;
	}

	public boolean getDelflg() {
		return delflg;
	}

	public void setDelflg(boolean delflg) {
		this.delflg = delflg;
	}

	public String getPropAddr() {
		return propAddr;
	}

	public void setPropAddr(String propAddr) {
		this.propAddr = propAddr;
	}

	@Override
	public String toString() {
		return "HousingLoanDetailScreen [reqNo=" + reqNo + ", seqnr=" + seqnr + ", rento=" + rento + ", rentoTxt="
				+ rentoTxt + ", letvl=" + letvl + ", int24=" + int24 + ", rep24=" + rep24 + ", oth24=" + oth24
				+ ", lenam=" + lenam + ", lead1=" + lead1 + ", lead2=" + lead2 + ", lead3=" + lead3 + ", lepan=" + lepan
				+ ", letyp=" + letyp + ", letypText=" + letypText + ", attachementref=" + attachementref
				+ ", zzacqfromdt=" + zzacqfromdt + ", acknowledge=" + acknowledge + ", delflg=" + delflg + ", propAddr="
				+ propAddr + "]";
	}
}