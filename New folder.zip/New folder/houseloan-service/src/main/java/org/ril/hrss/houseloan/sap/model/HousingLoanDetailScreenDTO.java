package org.ril.hrss.houseloan.sap.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.DoubleToStrSerializer;
import org.ril.hrss.msf.custom.serializer.EmptyStringSerializer;
import org.ril.hrss.msf.custom.serializer.SAPDateFormatSerializer;
import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class HousingLoanDetailScreenDTO {

	@JsonProperty("Reqno")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String reqNo;

	@JsonProperty("Seqnr")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String seqnr;

	@JsonProperty("Rento")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String rento;

	@JsonProperty("RentoTxt")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String rentoTxt;

	@JsonProperty("Letvl")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	private Double letvl;

	@JsonProperty("Int24")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	private Double int24;

	@JsonProperty("Rep24")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	private Double rep24;

	@JsonProperty("Oth24")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	private Double oth24;

	@JsonProperty("Lenam")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String lenam;

	@JsonProperty("Lead1")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String lead1;

	@JsonProperty("Lead2")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String lead2;

	@JsonProperty("Lead3")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String lead3;

	@JsonProperty("Lepan")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String lepan;

	@JsonProperty("Letyp")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String letyp;

	@JsonProperty("LetypText")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String letypText;

	@JsonProperty("Attachementref")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String attachementref;

	@JsonProperty("Zzacqfromdt")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	private Date zzacqfromdt;

	@JsonProperty("Acknowledge")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String acknowledge;

	@JsonProperty("Delflg")
	private String delflg;

	@JsonProperty("PropAddr")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	private String propAddr;

	public HousingLoanDetailScreenDTO() {
		super();
	}

	public String getReqNo() {
		return reqNo;
	}

	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	public String getSeqnr() {
		return seqnr;
	}

	public void setSeqnr(String seqnr) {
		this.seqnr = seqnr;
	}

	public String getRento() {
		return rento;
	}

	public void setRento(String rento) {
		this.rento = rento;
	}

	public String getRentoTxt() {
		return rentoTxt;
	}

	public void setRentoTxt(String rentoTxt) {
		this.rentoTxt = rentoTxt;
	}

	public Double getLetvl() {
		return letvl;
	}

	public void setLetvl(Double letvl) {
		this.letvl = letvl;
	}

	public Double getInt24() {
		return int24;
	}

	public void setInt24(Double int24) {
		this.int24 = int24;
	}

	public Double getRep24() {
		return rep24;
	}

	public void setRep24(Double rep24) {
		this.rep24 = rep24;
	}

	public Double getOth24() {
		return oth24;
	}

	public void setOth24(Double oth24) {
		this.oth24 = oth24;
	}

	public String getLenam() {
		return lenam;
	}

	public void setLenam(String lenam) {
		this.lenam = lenam;
	}

	public String getLead1() {
		return lead1;
	}

	public void setLead1(String lead1) {
		this.lead1 = lead1;
	}

	public String getLead2() {
		return lead2;
	}

	public void setLead2(String lead2) {
		this.lead2 = lead2;
	}

	public String getLead3() {
		return lead3;
	}

	public void setLead3(String lead3) {
		this.lead3 = lead3;
	}

	public String getLepan() {
		return lepan;
	}

	public void setLepan(String lepan) {
		this.lepan = lepan;
	}

	public String getLetyp() {
		return letyp;
	}

	public void setLetyp(String letyp) {
		this.letyp = letyp;
	}

	public String getLetypText() {
		return letypText;
	}

	public void setLetypText(String letypText) {
		this.letypText = letypText;
	}

	public String getAttachementref() {
		return attachementref;
	}

	public void setAttachementref(String attachementref) {
		this.attachementref = attachementref;
	}

	public Date getZzacqfromdt() {
		return zzacqfromdt;
	}

	public void setZzacqfromdt(Date zzacqfromdt) {
		this.zzacqfromdt = zzacqfromdt;
	}

	public String getAcknowledge() {
		return acknowledge;
	}

	public void setAcknowledge(String acknowledge) {
		this.acknowledge = acknowledge;
	}

	public String getDelflg() {
		return delflg;
	}

	public void setDelflg(boolean delflg) {
		this.delflg = delflg ? "Y" : "";
	}

	public String getPropAddr() {
		return propAddr;
	}

	public void setPropAddr(String propAddr) {
		this.propAddr = propAddr;
	}

	@Override
	public String toString() {
		return "HousingLoanDetailScreen [reqNo=" + reqNo + ", seqnr=" + seqnr + ", rento=" + rento + ", rentoTxt="
				+ rentoTxt + ", letvl=" + letvl + ", int24=" + int24 + ", rep24=" + rep24 + ", oth24=" + oth24
				+ ", lenam=" + lenam + ", lead1=" + lead1 + ", lead2=" + lead2 + ", lead3=" + lead3 + ", lepan=" + lepan
				+ ", letyp=" + letyp + ", letypText=" + letypText + ", attachementref=" + attachementref
				+ ", zzacqfromdt=" + zzacqfromdt + ", acknowledge=" + acknowledge + ", delflg=" + delflg + ", propAddr="
				+ propAddr + "]";
	}

}