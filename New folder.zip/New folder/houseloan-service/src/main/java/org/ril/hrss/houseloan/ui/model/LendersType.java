package org.ril.hrss.houseloan.ui.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LendersType {
	private String lndKey;
	private String lndType;

	public LendersType() {
		super();
	}

	public String getLndKey() {
		return lndKey;
	}

	@JsonProperty("LndKey")
	public void setLndKey(String lndKey) {
		this.lndKey = lndKey;
	}

	public String getLndType() {
		return lndType;
	}

	@JsonProperty("LndType")
	public void setLndType(String lndType) {
		this.lndType = lndType;
	}

	@Override
	public String toString() {
		return "LendersType [LndKey=" + lndKey + ", LndType=" + lndType + "]";
	}

}