package org.ril.hrss.houseloan.ui.model;

public class HouseLoanDetails {
	private Double propAmt;
	private Double actAmt;
	private Double apprAmt;
	private String status;
	private String statusTxt;
	private String empRemarks;
	private String apprRemarks;
	private boolean createFlag;
	private boolean editFlag;
	private boolean printFlag;
	private boolean actionFlag;

	public HouseLoanDetails() {
		super();
	}

	public Double getPropAmt() {
		return propAmt;
	}

	public void setPropAmt(Double propAmt) {
		this.propAmt = propAmt;
	}

	public Double getActAmt() {
		return actAmt;
	}

	public void setActAmt(Double actAmt) {
		this.actAmt = actAmt;
	}

	public Double getApprAmt() {
		return apprAmt;
	}

	public void setApprAmt(Double apprAmt) {
		this.apprAmt = apprAmt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusTxt() {
		return statusTxt;
	}

	public void setStatusTxt(String statusTxt) {
		this.statusTxt = statusTxt;
	}

	public String getEmpRemarks() {
		return empRemarks;
	}

	public void setEmpRemarks(String empRemarks) {
		this.empRemarks = empRemarks;
	}

	public String getApprRemarks() {
		return apprRemarks;
	}

	public void setApprRemarks(String apprRemarks) {
		this.apprRemarks = apprRemarks;
	}

	public boolean getCreateFlag() {
		return createFlag;
	}

	public void setCreateFlag(boolean createFlag) {
		this.createFlag = createFlag;
	}

	public boolean getEditFlag() {
		return editFlag;
	}

	public void setEditFlag(boolean editFlag) {
		this.editFlag = editFlag;
	}

	public boolean getPrintFlag() {
		return printFlag;
	}

	public void setPrintFlag(boolean printFlag) {
		this.printFlag = printFlag;
	}

	public boolean getActionFlag() {
		return actionFlag;
	}

	public void setActionFlag(boolean actionFlag) {
		this.actionFlag = actionFlag;
	}

	@Override
	public String toString() {
		return "HouseLoanDetails [propAmt=" + propAmt + ", actAmt=" + actAmt + ", apprAmt=" + apprAmt + ", status="
				+ status + ", statusTxt=" + statusTxt + ", empRemarks=" + empRemarks + ", apprRemarks=" + apprRemarks
				+ ", createFlag=" + createFlag + ", editFlag=" + editFlag + ", printFlag=" + printFlag + ", actionFlag="
				+ actionFlag + "]";
	}
}