package org.ril.hrss.houseloan.ui.model;

import java.util.List;

public class HouseLoanScreen {

	private String actionFlag;
	private String empRemarks;
	private String apprRemarks;

	List<HousingLoanDetailScreen> housingLoanDetailScreenList;

	public HouseLoanScreen() {
		super();
	}

	public String getActionFlag() {
		return actionFlag;
	}

	public void setActionFlag(String actionFlag) {
		this.actionFlag = actionFlag;
	}

	public String getEmpRemarks() {
		return empRemarks;
	}

	public void setEmpRemarks(String empRemarks) {
		this.empRemarks = empRemarks;
	}

	public String getApprRemarks() {
		return apprRemarks;
	}

	public void setApprRemarks(String apprRemarks) {
		this.apprRemarks = apprRemarks;
	}

	public List<HousingLoanDetailScreen> getHousingLoanDetailScreenList() {
		return housingLoanDetailScreenList;
	}

	public void setHousingLoanDetailScreenList(List<HousingLoanDetailScreen> housingLoanDetailScreenList) {
		this.housingLoanDetailScreenList = housingLoanDetailScreenList;
	}

	@Override
	public String toString() {
		return "HouseLoanScreen [actionFlag=" + actionFlag + ", empRemarks=" + empRemarks + ", apprRemarks="
				+ apprRemarks + ", housingLoanDetailScreenList=" + housingLoanDetailScreenList + "]";
	}
}