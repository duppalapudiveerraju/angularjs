package org.ril.hrss.houseloan.sap.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HouseLoanScreenDTO {
	@JsonProperty("ActionFlag")
	private String actionFlag;

	@JsonProperty("EmpRemarks")
	private String empRemarks;

	@JsonProperty("ApprRemarks")
	private String apprRemarks;

	@JsonProperty("IT584SaveItemSet")
	List<HousingLoanDetailScreenDTO> housingLoanDetailScreenList;

	public HouseLoanScreenDTO() {
		super();
	}

	public String getActionFlag() {
		return actionFlag;
	}

	public void setActionFlag(String actionFlag) {
		this.actionFlag = actionFlag;
	}

	public String getEmpRemarks() {
		return empRemarks;
	}

	public void setEmpRemarks(String empRemarks) {
		this.empRemarks = empRemarks;
	}

	public String getApprRemarks() {
		return apprRemarks;
	}

	public void setApprRemarks(String apprRemarks) {
		this.apprRemarks = apprRemarks;
	}

	public List<HousingLoanDetailScreenDTO> getHousingLoanDetailScreenList() {
		return housingLoanDetailScreenList;
	}

	public void setHousingLoanDetailScreenList(List<HousingLoanDetailScreenDTO> housingLoanDetailScreenList) {
		this.housingLoanDetailScreenList = housingLoanDetailScreenList;
	}

	@Override
	public String toString() {
		return "HouseLoanScreen [actionFlag=" + actionFlag + ", empRemarks=" + empRemarks + ", apprRemarks="
				+ apprRemarks + ", housingLoanDetailScreenList=" + housingLoanDetailScreenList + "]";
	}

}