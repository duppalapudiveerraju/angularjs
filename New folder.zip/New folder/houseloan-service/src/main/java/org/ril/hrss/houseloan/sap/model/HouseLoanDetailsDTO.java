package org.ril.hrss.houseloan.sap.model;

import org.ril.hrss.msf.custom.serializer.DoubleToStrSerializer;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class HouseLoanDetailsDTO {
	private Double propAmt;
	private Double actAmt;
	private Double apprAmt;
	private String status;
	private String statusTxt;
	private String empRemarks;
	private String apprRemarks;
	private boolean createFlag;
	private boolean editFlag;
	private boolean printFlag;
	private boolean actionFlag;

	public HouseLoanDetailsDTO() {
		super();
	}

	@JsonProperty("propAmt")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	public Double getPropAmt() {
		return propAmt;
	}

	@JsonProperty("PropAmt")
	public void setPropAmt(Double propAmt) {
		this.propAmt = propAmt;
	}

	@JsonProperty("actAmt")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	public Double getActAmt() {
		return actAmt;
	}

	@JsonProperty("ActAmt")
	public void setActAmt(Double actAmt) {
		this.actAmt = actAmt;
	}

	@JsonProperty("apprAmt")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	public Double getApprAmt() {
		return apprAmt;
	}

	@JsonProperty("ApprAmt")
	public void setApprAmt(Double apprAmt) {
		this.apprAmt = apprAmt;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("Status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("statusTxt")
	public String getStatusTxt() {
		return statusTxt;
	}

	@JsonProperty("StatusTxt")
	public void setStatusTxt(String statusTxt) {
		this.statusTxt = statusTxt;
	}

	@JsonProperty("empRemarks")
	public String getEmpRemarks() {
		return empRemarks;
	}

	@JsonProperty("EmpRemarks")
	public void setEmpRemarks(String empRemarks) {
		this.empRemarks = empRemarks;
	}

	@JsonProperty("apprRemarks")
	public String getApprRemarks() {
		return apprRemarks;
	}

	@JsonProperty("ApprRemarks")
	public void setApprRemarks(String apprRemarks) {
		this.apprRemarks = apprRemarks;
	}

	@JsonProperty("createFlag")
	public boolean getCreateFlag() {
		return createFlag;
	}

	@JsonProperty("CreateFlag")
	public void setCreateFlag(String createFlag) {
		this.createFlag = createFlag.equals("Y") ? Boolean.TRUE : Boolean.FALSE;
	}

	@JsonProperty("editFlag")
	public boolean getEditFlag() {
		return editFlag;
	}

	@JsonProperty("EditFlag")
	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag.equals("Y") ? Boolean.TRUE : Boolean.FALSE;

	}

	@JsonProperty("printFlag")
	public boolean getPrintFlag() {
		return printFlag;
	}

	@JsonProperty("PrintFlag")
	public void setPrintFlag(String printFlag) {
		this.printFlag = printFlag.equals("Y") ? Boolean.TRUE : Boolean.FALSE;
	}

	@JsonProperty("actionFlag")
	public boolean getActionFlag() {
		return actionFlag;
	}

	@JsonProperty("ActionFlag")
	public void setActionFlag(String actionFlag) {
		this.actionFlag = actionFlag.equals("Y") ? Boolean.TRUE : Boolean.FALSE;
	}

	@Override
	public String toString() {
		return "HouseLoanDetails [propAmt=" + propAmt + ", actAmt=" + actAmt + ", apprAmt=" + apprAmt + ", status="
				+ status + ", statusTxt=" + statusTxt + ", empRemarks=" + empRemarks + ", apprRemarks=" + apprRemarks
				+ ", createFlag=" + createFlag + ", editFlag=" + editFlag + ", printFlag=" + printFlag + ", actionFlag="
				+ actionFlag + "]";
	}

}