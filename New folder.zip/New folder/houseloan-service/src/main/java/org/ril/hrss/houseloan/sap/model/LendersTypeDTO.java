package org.ril.hrss.houseloan.sap.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LendersTypeDTO {
	private String lndKey;
	private String lndType;

	public LendersTypeDTO() {
		super();
	}

	public String getLndKey() {
		return lndKey;
	}

	@JsonProperty("LndKey")
	public void setLndKey(String lndKey) {
		this.lndKey = lndKey;
	}

	public String getLndType() {
		return lndType;
	}

	@JsonProperty("LndType")
	public void setLndType(String lndType) {
		this.lndType = lndType;
	}

	@Override
	public String toString() {
		return "LendersType [LndKey=" + lndKey + ", LndType=" + lndType + "]";
	}

}