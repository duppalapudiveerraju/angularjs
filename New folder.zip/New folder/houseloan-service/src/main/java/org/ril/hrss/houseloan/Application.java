package org.ril.hrss.houseloan;

import org.ril.hrss.msf.exception.controller.RequestControllerAdvice;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Import;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@EnableEurekaClient
@EnableWebMvc
@SpringBootApplication
@EnableFeignClients
@EnableCircuitBreaker
@Import({ ObjectMapperUtil.class, RequestControllerAdvice.class })
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}