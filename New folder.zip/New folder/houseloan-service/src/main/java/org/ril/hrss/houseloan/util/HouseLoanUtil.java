package org.ril.hrss.houseloan.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.ril.hrss.houseloan.intercomm.SapEndpointClient;
import org.ril.hrss.houseloan.sap.model.HouseLoanDetailsDTO;
import org.ril.hrss.houseloan.sap.model.HouseLoanScreenDTO;
import org.ril.hrss.houseloan.sap.model.HousingLoanDetailScreenDTO;
import org.ril.hrss.houseloan.sap.model.LendersTypeDTO;
import org.ril.hrss.houseloan.ui.model.HouseLoanDetails;
import org.ril.hrss.houseloan.ui.model.HouseLoanScreen;
import org.ril.hrss.houseloan.ui.model.HousingLoanDetailScreen;
import org.ril.hrss.houseloan.ui.model.LendersType;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.client.ClientException;

@Component
public class HouseLoanUtil {

	protected static final Logger logger = Logger.getLogger(HouseLoanUtil.class.getName());
	@Autowired
	private SapEndpointClient sapEndpointClient;
	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public HouseLoanUtil() {
		super();
	}

	public HouseLoanDetails getInterestHouseLoanDetails(String userId) throws ClientException {
		logger.info("HouseLoanDetails.getInterestHouseLoanDetails()");
		String sapResponse = sapEndpointClient.getInterestHouseLoanDetails(userId);
		HouseLoanDetails houseLoanDetail = null;
		if (null != sapResponse) {
			houseLoanDetail = new HouseLoanDetails();
			HouseLoanDetailsDTO sapObj = getInterestHouseLoanDetailsObjectMapped(sapResponse);
			BeanUtils.copyProperties(sapObj, houseLoanDetail);
		} else {
			houseLoanDetail = new HouseLoanDetails();
		}
		return houseLoanDetail;
	}

	private HouseLoanDetailsDTO getInterestHouseLoanDetailsObjectMapped(String feed) {
		logger.info("HouseLoanUtil.getInterestHouseLoanDetailsObjectMapped()");
		HouseLoanDetailsDTO houseLoanDetail = new HouseLoanDetailsDTO();
		try {
			ObjectMapper objectMapper = objectMapperUtil.get();
			JsonNode rootNode = objectMapper.readTree(feed);
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
			objectMapper.setDateFormat(df);
			objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
			houseLoanDetail = objectMapper.readValue(rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).toString(),
					new TypeReference<HouseLoanDetailsDTO>() {
					});

		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return houseLoanDetail;
	}

	public List<HousingLoanDetailScreen> getLoanDetailScreen(String userId) throws ClientException {
		logger.info("HouseLoanUtil.getLoanDetailScreen()");
		String jsonString = sapEndpointClient.getLoanDetailScreen(userId);
		List<HousingLoanDetailScreen> uiList = new ArrayList<>();
		if (null != jsonString) {
			List<HousingLoanDetailScreenDTO> sapList = getLoanDetailScreenObjectMapped(jsonString);
			for (HousingLoanDetailScreenDTO obj : sapList) {
				HousingLoanDetailScreen target = new HousingLoanDetailScreen();
				BeanUtils.copyProperties(obj, target);
				uiList.add(target);
			}
		}
		return uiList;
	}

	private List<HousingLoanDetailScreenDTO> getLoanDetailScreenObjectMapped(String feed) {
		logger.info("HouseLoanUtil.getInterestHouseLoanDetailsObjectMapped()");
		TypeReference<List<HousingLoanDetailScreenDTO>> type = new TypeReference<List<HousingLoanDetailScreenDTO>>() {
		};
		List<HousingLoanDetailScreenDTO> response = this.getDataList(type, feed);
		if (response != null) {
			return response;
		} else {
			return new ArrayList<HousingLoanDetailScreenDTO>();
		}
	}

	public List<LendersType> getLendersType(String userId) {
		logger.info("HouseLoanUtil.getLendersType()");
		String sapResponse = sapEndpointClient.getLendersType(userId);
		List<LendersType> uiList = null;
		if (sapResponse != null) {
			uiList = new ArrayList<>();
			List<LendersTypeDTO> lendersTypeDTOList = getLenderTypeObjectMapped(sapResponse);
			for (LendersTypeDTO obj : lendersTypeDTOList) {
				LendersType targetObject = new LendersType();
				BeanUtils.copyProperties(obj, targetObject);
				uiList.add(targetObject);
			}
		} else {
			uiList = new ArrayList<>();
		}
		return uiList;
	}

	private List<LendersTypeDTO> getLenderTypeObjectMapped(String feed) {
		logger.info("HouseLoanUtil.getInterestHouseLoanDetailsObjectMapped()");
		TypeReference<List<LendersTypeDTO>> type = new TypeReference<List<LendersTypeDTO>>() {
		};
		List<LendersTypeDTO> response = this.getDataList(type, feed);
		if (response != null) {
			return response;
		} else {
			return new ArrayList<LendersTypeDTO>();
		}
	}

	public ResponseEntity<HouseLoanScreenDTO> saveLoanDetailScreen(String userId, HouseLoanScreen houseLoanScreen)
			throws ClientException {
		logger.info("HouseLoanUtil.saveLoanDetailScreen()");
		Map<String, String> response = null;
		HouseLoanScreenDTO dto = new HouseLoanScreenDTO();
		try {
			List<HousingLoanDetailScreenDTO> dtoList = new ArrayList<>();
			houseLoanScreen.getHousingLoanDetailScreenList().stream().forEach(detail -> {
				HousingLoanDetailScreenDTO detailDTO = new HousingLoanDetailScreenDTO();
				BeanUtils.copyProperties(detail, detailDTO);
				dtoList.add(detailDTO);
			});

			BeanUtils.copyProperties(houseLoanScreen, dto);
			dto.setHousingLoanDetailScreenList(dtoList);
			String jsonData = objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST).writeValueAsString(dto);
			response = sapEndpointClient.saveLoanDetailScreen(userId, jsonData);

			if (response != null) {
				if (response.get(HRSSConstantUtil.POST_RESPONSE_STATUS)
						.equals(HRSSConstantUtil.POST_RESPONSE_STATUS_SUCCESS)) {
					return new ResponseEntity<HouseLoanScreenDTO>(dto, HttpStatus.OK);
				} else {
					return new ResponseEntity<HouseLoanScreenDTO>(dto, HttpStatus.BAD_REQUEST);
				}
			} else {
				return new ResponseEntity<HouseLoanScreenDTO>(dto, HttpStatus.BAD_REQUEST);
			}

		} catch (JsonProcessingException e) {
			logger.info(e.getMessage());
		}
		return new ResponseEntity<HouseLoanScreenDTO>(dto, HttpStatus.BAD_REQUEST);
	}

	private List getDataList(TypeReference type, String feed) {
		List list = null;
		try {
			ObjectMapper objectMapper = objectMapperUtil.get();
			JsonNode rootNode = objectMapper.readTree(feed);
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
			objectMapper.setDateFormat(df);
			list = objectMapper.readValue(
					rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
					type);
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list;
	}
}