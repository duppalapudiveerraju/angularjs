package org.ril.hrss.houseloan.intercomm;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getInterestHouseLoanDetails(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public String getLoanDetailScreen(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public Map<String, String> saveLoanDetailScreen(String userId, String jsonData) {
		return new HashMap<String, String>();
	}

	@Override
	public String getLendersType(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}