package org.ril.hrss.leavehistory.service;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.ril.hrss.leavehistory.client.SapEndpointClient;
import org.ril.hrss.leavehistory.interfaces.LeaveHistoryRepo;
import org.ril.hrss.leavehistory.model.LeaveApprovalHistory;
import org.ril.hrss.leavehistory.model.LeaveHistory;
import org.ril.hrss.leavehistory.util.LeaveHistoryUtil;
import org.ril.hrss.msf.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.netflix.client.ClientException;

@Component
public class LeaveHistoryService implements LeaveHistoryRepo {

	protected static final Logger logger = Logger.getLogger(LeaveHistoryService.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private LeaveHistoryUtil leaveHistoryUtil;

	public LeaveHistoryService() {
		super();
	}

	@Override
	public Map<Pair<String, Long>, List<LeaveApprovalHistory>> getLeaveApprovalHistoryDetails(String userId,
			String month, String year) throws ClientException {
		logger.info("LeaveHistoryUtil.getLeaveApprovalHistoryDetails()");
		return leaveHistoryUtil
				.getLeaveApprovalHistorylList(sapEndpointClient.getLeaveHistoryApproval(userId, month, year), month,
						year)
				.parallelStream()
				.collect(Collectors.groupingBy(p -> Pair.of(p.getEmployeeId(), p.getActionDate().getTime())));
	}

	@SuppressWarnings("deprecation")
	@Override
	public Map<String, List<LeaveHistory>> getLeaveHistoryDetails(String userId, Integer year) throws ClientException {
		logger.info("LeaveHistoryUtil.getLeaveHistoryDetails()");
		return leaveHistoryUtil.getLeaveHistorylList(sapEndpointClient.getLeaveHistory(userId)).parallelStream()
				.filter(e -> year.equals(DateUtil.getActualYear(e.getApplyDate().getYear())))
				.collect(Collectors.groupingBy(LeaveHistory::getLeaveDesc));
	}

}