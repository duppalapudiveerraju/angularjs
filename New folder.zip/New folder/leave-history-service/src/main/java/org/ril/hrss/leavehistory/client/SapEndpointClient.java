package org.ril.hrss.leavehistory.client;

import javax.validation.constraints.NotNull;

import org.ril.hrss.leavehistory.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.GET, value = "/sap/leave/approval/history/{userId}/{month}/{year}")
	String getLeaveHistoryApproval(@PathVariable("userId") String userId, @PathVariable("month") String month,
			@PathVariable("year") String year);
	
	@RequestMapping(method = RequestMethod.GET, value = "/sap/leave/history", produces = "application/json")
	String getLeaveHistory(@NotNull @RequestHeader("userId") String userId);

}