package org.ril.hrss.leavehistory.filter;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.ril.hrss.leavehistory.model.LeaveApprovalHistory;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.enumeration.ApprovalStatus;

import com.fasterxml.jackson.databind.util.StdConverter;

public class LeaveApprovalHistoryFilter extends StdConverter<LeaveApprovalHistory, LeaveApprovalHistory> {

	@Override
	public LeaveApprovalHistory convert(LeaveApprovalHistory obj) {
		long applyDateMillis = obj.getApplyDate().getTime();
		long currentDateMiilis = obj.getLeaveStatus().equals(ApprovalStatus.PENDING) ? new Date().getTime()
				: obj.getActionDate().getTime();
		obj.setSlaBreached(Math.abs(TimeUnit.DAYS.convert(currentDateMiilis - applyDateMillis, TimeUnit.DAYS)
				/ 86400000) > HRSSConstantUtil.REGULARIZE_PENDING_SLA);
		return obj;
	}

}