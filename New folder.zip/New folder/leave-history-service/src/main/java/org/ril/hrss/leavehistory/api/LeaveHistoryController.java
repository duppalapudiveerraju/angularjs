package org.ril.hrss.leavehistory.api;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.tuple.Pair;
import org.ril.hrss.leavehistory.interfaces.LeaveHistoryRepo;
import org.ril.hrss.leavehistory.model.LeaveApprovalHistory;
import org.ril.hrss.leavehistory.model.LeaveHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Leave Approval History Details", description = "Operations pertaining to find leave approval history")
public class LeaveHistoryController {

	protected static final Logger logger = Logger.getLogger(LeaveHistoryController.class.getName());
	
	@Autowired
	private LeaveHistoryRepo leaveHistoryRepo;

	public LeaveHistoryController() {
		super();
	}

	@RequestMapping(value = "/approval/{userId}/{month}/{year}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of leave approval history details", response = Map.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public Map<Pair<String, Long>, List<LeaveApprovalHistory>> getLeaveApprovalHistoryDetails(
			@PathVariable("userId") String userId, @PathVariable("month") String month,
			@PathVariable("year") String year) throws ClientException {
		logger.info("leave.getLeaveApprovalHistoryDetails()");
		return leaveHistoryRepo.getLeaveApprovalHistoryDetails(userId, month, year);
	}

	@RequestMapping(value = "/details/{year}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of leave approval history details", response = Map.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public Map<String, List<LeaveHistory>> getLeaveHistoryDetails(@NotNull @RequestHeader("userId") String userId,
			@PathVariable("year") Integer year) throws ClientException {
		logger.info("leave.getLeaveHistoryDetails()");
		return leaveHistoryRepo.getLeaveHistoryDetails(userId, year);
	}

}