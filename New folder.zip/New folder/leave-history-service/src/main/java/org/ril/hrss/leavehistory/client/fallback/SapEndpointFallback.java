package org.ril.hrss.leavehistory.client.fallback;

import org.ril.hrss.leavehistory.client.SapEndpointClient;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getLeaveHistoryApproval(String userId, String month, String year) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public String getLeaveHistory(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}