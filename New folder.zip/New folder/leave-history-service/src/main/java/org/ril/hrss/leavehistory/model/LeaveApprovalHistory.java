package org.ril.hrss.leavehistory.model;

import java.util.Date;

import org.ril.hrss.leavehistory.filter.LeaveApprovalHistoryFilter;
import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;
import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.enumeration.ApprovalStatus;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(converter = LeaveApprovalHistoryFilter.class)
public class LeaveApprovalHistory {

	private String attachDocId;
	private Date applyDate;
	private Date actionDate;
	private String leaveRequestId;
	private boolean slaBreached;
	private String employeeId;
	private String employeeName;
	private Date leaveFromDate;
	private Date leaveToDate;
	private Double leaveNoOfDays;
	private ApprovalStatus leaveStatus;
	private String leaveDesc;
	private String leaveRemark;

	public LeaveApprovalHistory() {
		super();
	}

	public LeaveApprovalHistory(String attachDocId, Date applyDate, Date actionDate, String leaveRequestId, boolean slaBreached,
			String employeeId, String employeeName, Date leaveFromDate, Date leaveToDate, Double leaveNoOfDays,
			ApprovalStatus leaveStatus, String leaveDesc, String leaveRemark) {
		this();
		this.attachDocId = attachDocId;
		this.applyDate = applyDate;
		this.actionDate = actionDate;
		this.leaveRequestId = leaveRequestId;
		this.slaBreached = slaBreached;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.leaveFromDate = leaveFromDate;
		this.leaveToDate = leaveToDate;
		this.leaveNoOfDays = leaveNoOfDays;
		this.leaveStatus = leaveStatus;
		this.leaveDesc = leaveDesc;
		this.leaveRemark = leaveRemark;
	}

	@JsonProperty("actionDate")
	public Date getActionDate() {
		return actionDate;
	}

	@JsonProperty("Apdat")
	public void setActionDate(String actionDate) {
		this.actionDate = actionDate != null
				? new Date(Long.parseLong(
						actionDate.replaceAll(HRSSConstantUtil.REGEX_ONLY_NUM, HRSSConstantUtil.EMPTY_STRING)))
				: DateUtil.DEFAULT_DATE_TS;
	}

	@JsonProperty("attachDocId")
	public String getAttachDocId() {
		return attachDocId;
	}

	@JsonProperty("ArcDocId")
	public void setAttachDocId(String attachDocId) {
		this.attachDocId = attachDocId;
	}

	@JsonProperty("applyDate")
	public Date getApplyDate() {
		return applyDate;
	}

	@JsonProperty("Initdate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	@JsonProperty("leaveRequestId")
	public String getLeaveRequestId() {
		return leaveRequestId;
	}

	@JsonProperty("RequestId")
	public void setLeaveRequestId(String leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	@JsonProperty("slaBreached")
	public boolean isSlaBreached() {
		return slaBreached;
	}

	public void setSlaBreached(boolean slaBreached) {
		this.slaBreached = slaBreached;
	}

	@JsonProperty("employeeId")
	public String getEmployeeId() {
		return employeeId;
	}

	@JsonProperty("Pernr")
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@JsonProperty("employeeName")
	public String getEmployeeName() {
		return employeeName;
	}

	@JsonProperty("Ename")
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	@JsonProperty("leaveFromDate")
	public Date getLeaveFromDate() {
		return leaveFromDate;
	}

	@JsonProperty("Begda")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setLeaveFromDate(Date leaveFromDate) {
		this.leaveFromDate = leaveFromDate;
	}

	@JsonProperty("leaveToDate")
	public Date getLeaveToDate() {
		return leaveToDate;
	}

	@JsonProperty("Endda")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setLeaveToDate(Date leaveToDate) {
		this.leaveToDate = leaveToDate;
	}

	@JsonProperty("leaveStatus")
	public ApprovalStatus getLeaveStatus() {
		return leaveStatus;
	}

	@JsonProperty("Status")
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = ApprovalStatus.fromString(leaveStatus);
	}

	@JsonProperty("leaveNoOfDays")
	public Double getLeaveNoOfDays() {
		return leaveNoOfDays;
	}

	@JsonProperty("Abwtg")
	public void setLeaveNoOfDays(Double leaveNoOfDays) {
		this.leaveNoOfDays = leaveNoOfDays;
	}

	@JsonProperty("leaveDesc")
	public String getLeaveDesc() {
		return leaveDesc;
	}

	@JsonProperty("Absdes")
	public void setLeaveDesc(String leaveDesc) {
		this.leaveDesc = leaveDesc;
	}

	@JsonProperty("leaveRemark")
	public String getLeaveRemark() {
		return leaveRemark;
	}

	@JsonProperty("Reason")
	public void setLeaveRemark(String leaveRemark) {
		this.leaveRemark = leaveRemark;
	}

	@Override
	public String toString() {
		return "LeaveHistory [attachDocId=" + attachDocId + ", applyDate=" + applyDate + ", actionDate=" + actionDate
				+ ", leaveRequestId=" + leaveRequestId + ", slaBreached=" + slaBreached + ", employeeId=" + employeeId
				+ ", employeeName=" + employeeName + ", leaveFromDate=" + leaveFromDate + ", leaveToDate=" + leaveToDate
				+ ", leaveNoOfDays=" + leaveNoOfDays + ", leaveStatus=" + leaveStatus + ", leaveDesc=" + leaveDesc
				+ ", leaveRemark=" + leaveRemark + "]";
	}

}