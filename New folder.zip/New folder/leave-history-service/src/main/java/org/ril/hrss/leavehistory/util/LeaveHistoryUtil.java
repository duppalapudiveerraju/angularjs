package org.ril.hrss.leavehistory.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.leavehistory.model.LeaveApprovalHistory;
import org.ril.hrss.leavehistory.model.LeaveHistory;
import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.ril.hrss.msf.util.enumeration.ApprovalStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class LeaveHistoryUtil {
	
	protected static final Logger logger = Logger.getLogger(LeaveHistoryUtil.class.getName());

	@Autowired
	private ObjectMapperUtil objectMapperUtil;
	
	public LeaveHistoryUtil() {
		super();
	}

	public List<LeaveHistory> getLeaveHistorylList(String feed) {
		logger.info("LeaveHistoryUtil.getLeaveHistorylList()");
		List<LeaveHistory> list = new ArrayList<>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapper.readTree(feed);
				list = objectMapper.readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<LeaveHistory>>() {
						});
			}
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list;
	}

	public List<LeaveApprovalHistory> getLeaveApprovalHistorylList(String feed, String month, String year) {
		logger.info("LeaveHistoryUtil.getLeaveApprovalHistorylList()");
		List<LeaveApprovalHistory> list = new ArrayList<LeaveApprovalHistory>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapper.readTree(feed);
				list = objectMapper.readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<LeaveApprovalHistory>>() {
						});
				list = filterOnApprovalDate(list, Integer.parseInt(month), Integer.parseInt(year));
			}
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list;
	}

	@SuppressWarnings("deprecation")
	private List<LeaveApprovalHistory> filterOnApprovalDate(List<LeaveApprovalHistory> list, int month, int year) {
		logger.info("LeaveHistoryUtil.filterOnApprovalDate()");
		return list.parallelStream()
				.filter(e -> e.getActionDate() != null && !e.getActionDate().equals(DateUtil.DEFAULT_DATE_TS)
						&& DateUtil.getActualMonth(e.getActionDate().getMonth()) == month
						&& DateUtil.getActualYear(e.getActionDate().getYear()) == year
						&& !e.getLeaveStatus().equals(ApprovalStatus.PENDING))
				.collect(Collectors.toList());
	}

}