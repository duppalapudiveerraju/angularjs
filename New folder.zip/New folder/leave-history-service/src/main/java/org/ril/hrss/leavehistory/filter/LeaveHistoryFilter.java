package org.ril.hrss.leavehistory.filter;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.ril.hrss.leavehistory.model.LeaveHistory;
import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class LeaveHistoryFilter extends StdConverter<LeaveHistory, LeaveHistory> {

	@Override
	public LeaveHistory convert(LeaveHistory obj) {
		long applyDateMillis = obj.getApplyDate().getTime();
		long currentDateMiilis = obj.getActionDate() != null ? obj.getActionDate().getTime() : new Date().getTime();
		obj.setSlaBreached(Math.abs(TimeUnit.DAYS.convert(currentDateMiilis - applyDateMillis, TimeUnit.DAYS)
				/ 86400000) > HRSSConstantUtil.REGULARIZE_PENDING_SLA);
		return obj;
	}

}