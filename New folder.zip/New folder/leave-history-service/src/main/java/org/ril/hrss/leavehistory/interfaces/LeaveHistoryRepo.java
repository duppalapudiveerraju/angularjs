package org.ril.hrss.leavehistory.interfaces;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.tuple.Pair;
import org.ril.hrss.leavehistory.model.LeaveApprovalHistory;
import org.ril.hrss.leavehistory.model.LeaveHistory;

import com.netflix.client.ClientException;

public interface LeaveHistoryRepo {
	
	public Map<Pair<String, Long>, List<LeaveApprovalHistory>> getLeaveApprovalHistoryDetails(String userId,
			String month, String year) throws ClientException;
	
	public Map<String, List<LeaveHistory>> getLeaveHistoryDetails(String userId, Integer year) throws ClientException;

}