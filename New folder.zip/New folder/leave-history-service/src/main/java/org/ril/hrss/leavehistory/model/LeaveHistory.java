package org.ril.hrss.leavehistory.model;

import java.util.Date;

import org.ril.hrss.leavehistory.filter.LeaveHistoryFilter;
import org.ril.hrss.msf.custom.serializer.SAPBooleanSerializer;
import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;
import org.ril.hrss.msf.util.enumeration.ApprovalStatus;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(converter = LeaveHistoryFilter.class)
public class LeaveHistory {

	private String attachDocId;
	private String leaveRequestId;
	private Date leaveFromDate;
	private Date leaveToDate;
	private Date applyDate;
	private Date actionDate;
	private String leaveCode;
	private String leaveDesc;
	private String leaveRemark;
	private Double leaveNoOfDays;
	private ApprovalStatus leaveStatus;
	private boolean slaBreached;
	private boolean cancelFlag;

	public LeaveHistory() {
		super();
	}

	public LeaveHistory(String attachDocId, String leaveRequestId, Date leaveFromDate, Date leaveToDate, Date applyDate,
			Date actionDate, String leaveCode, String leaveDesc, String leaveRemark, Double leaveNoOfDays,
			ApprovalStatus leaveStatus, boolean slaBreached, boolean cancelFlag) {
		this();
		this.attachDocId = attachDocId;
		this.leaveRequestId = leaveRequestId;
		this.leaveFromDate = leaveFromDate;
		this.leaveToDate = leaveToDate;
		this.applyDate = applyDate;
		this.actionDate = actionDate;
		this.leaveCode = leaveCode;
		this.leaveDesc = leaveDesc;
		this.leaveRemark = leaveRemark;
		this.leaveNoOfDays = leaveNoOfDays;
		this.leaveStatus = leaveStatus;
		this.slaBreached = slaBreached;
		this.cancelFlag = cancelFlag;
	}

	@JsonProperty("attachDocId")
	public String getAttachDocId() {
		return attachDocId;
	}

	@JsonProperty("ArcDocId")
	public void setAttachDocId(String attachDocId) {
		this.attachDocId = attachDocId;
	}

	@JsonProperty("leaveRequestId")
	public String getLeaveRequestId() {
		return leaveRequestId;
	}

	@JsonProperty("RequestId")
	public void setLeaveRequestId(String leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	@JsonProperty("leaveFromDate")
	public Date getLeaveFromDate() {
		return leaveFromDate;
	}

	@JsonProperty("StartDate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setLeaveFromDate(Date leaveFromDate) {
		this.leaveFromDate = leaveFromDate;
	}

	@JsonProperty("leaveToDate")
	public Date getLeaveToDate() {
		return leaveToDate;
	}

	@JsonProperty("EndDate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setLeaveToDate(Date leaveToDate) {
		this.leaveToDate = leaveToDate;
	}

	@JsonProperty("applyDate")
	public Date getApplyDate() {
		return applyDate;
	}

	@JsonProperty("InitDate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	@JsonProperty("actionDate")
	public Date getActionDate() {
		return actionDate;
	}

	@JsonProperty("ApDat")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setActionDate(Date actionDate) {
		this.actionDate = actionDate;
	}

	@JsonProperty("leaveCode")
	public String getLeaveCode() {
		return leaveCode;
	}

	@JsonProperty("LeaveCode")
	public void setLeaveCode(String leaveCode) {
		this.leaveCode = leaveCode;
	}

	@JsonProperty("leaveDesc")
	public String getLeaveDesc() {
		return leaveDesc;
	}

	@JsonProperty("LeaveText")
	public void setLeaveDesc(String leaveDesc) {
		this.leaveDesc = leaveDesc;
	}

	@JsonProperty("leaveRemark")
	public String getLeaveRemark() {
		return leaveRemark;
	}

	@JsonProperty("Reason")
	public void setLeaveRemark(String leaveRemark) {
		this.leaveRemark = leaveRemark;
	}

	@JsonProperty("leaveNoOfDays")
	public Double getLeaveNoOfDays() {
		return leaveNoOfDays;
	}

	@JsonProperty("NoOfDays")
	public void setLeaveNoOfDays(Double leaveNoOfDays) {
		this.leaveNoOfDays = leaveNoOfDays;
	}

	@JsonProperty("leaveStatus")
	public ApprovalStatus getLeaveStatus() {
		return leaveStatus;
	}

	@JsonProperty("Status")
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = ApprovalStatus.fromString(leaveStatus);
	}

	public boolean isSlaBreached() {
		return slaBreached;
	}

	public void setSlaBreached(boolean slaBreached) {
		this.slaBreached = slaBreached;
	}

	@JsonProperty("cancelFlag")
	public boolean isCancelFlag() {
		return cancelFlag;
	}

	@JsonProperty("Canflg")
	@JsonDeserialize(converter = SAPBooleanSerializer.class)
	public void setCancelFlag(boolean cancelFlag) {
		this.cancelFlag = cancelFlag;
	}

	@Override
	public String toString() {
		return "LeaveHistory [attachDocId=" + attachDocId + ", leaveRequestId=" + leaveRequestId + ", leaveFromDate="
				+ leaveFromDate + ", leaveToDate=" + leaveToDate + ", applyDate=" + applyDate + ", actionDate="
				+ actionDate + ", leaveCode=" + leaveCode + ", leaveDesc=" + leaveDesc + ", leaveRemark=" + leaveRemark
				+ ", leaveNoOfDays=" + leaveNoOfDays + ", leaveStatus=" + leaveStatus + ", slaBreached=" + slaBreached
				+ ", cancelFlag=" + cancelFlag + "]";
	}

}