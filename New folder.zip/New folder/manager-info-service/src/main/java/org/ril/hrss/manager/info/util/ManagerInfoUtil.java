package org.ril.hrss.manager.info.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.manager.info.intercomm.SapEndpointClient;
import org.ril.hrss.manager.info.model.ManagerInfoDetail;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.client.ClientException;

@Component
public class ManagerInfoUtil {

	protected static final Logger logger = Logger.getLogger(ManagerInfoUtil.class.getName());

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	@Autowired
	private SapEndpointClient sapEndpointClient;

	public ManagerInfoUtil() {
		super();
	}

	private List<ManagerInfoDetail> getManagerInfoDetail(String feed) {
		logger.info("managerInfoUtil.getManagerInfoDetail()");
		List<ManagerInfoDetail> list = new ArrayList<ManagerInfoDetail>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapper.readTree(feed);
				list = objectMapper.readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<ManagerInfoDetail>>() {
						});
			}
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list.parallelStream()
				.filter(e -> e.getDesignation().trim().toUpperCase().equals(HRSSConstantUtil.DESIGNATION_MANAGER))
				.collect(Collectors.toList());
	}

	public List<String> getManagerInfo(String userId) throws ClientException {
		logger.info("managerInfoUtil.getManagerInfo()");
		return getManagerInfoDetail(sapEndpointClient.getManagerInfoDetails(userId)).parallelStream()
				.map(ManagerInfoDetail::getUserId).collect(Collectors.toList());
	}

}