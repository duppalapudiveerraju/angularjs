package org.ril.hrss.manager.info.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ManagerInfoDetail {

	private String userId;
	private String designation;

	public ManagerInfoDetail(String userId, String designation) {
		super();
		this.userId = userId;
		this.designation = designation;
	}

	public ManagerInfoDetail() {
		super();
	}

	public String getUserId() {
		return userId;
	}

	@JsonProperty("Pernr")
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDesignation() {
		return designation;
	}

	@JsonProperty("Agent")
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "ManagerInfoDetail [userId=" + userId + ", designation=" + designation + "]";
	}

}