package org.ril.hrss.manager.info.intercomm;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getManagerInfoDetails(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}