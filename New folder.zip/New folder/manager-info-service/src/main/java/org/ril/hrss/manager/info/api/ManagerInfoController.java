package org.ril.hrss.manager.info.api;

import java.util.List;
import java.util.logging.Logger;
import org.ril.hrss.manager.info.util.ManagerInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/info")
@Api(value = "manager Info Details", description = "Operations pertaining to get User Info details")
public class ManagerInfoController {

	@Autowired
	private ManagerInfoUtil managerInfoUtil;

	protected static final Logger logger = Logger.getLogger(ManagerInfoController.class.getName());

	public ManagerInfoController() {
		super();
	}

	@RequestMapping(value = "/{userId}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get Manager Info details", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<String> getManagerInfoDetails(@PathVariable("userId") String userId) throws ClientException {
		logger.info("managerInfoController.getManagerInfoDetails()");
		return managerInfoUtil.getManagerInfo(userId);
	}

}