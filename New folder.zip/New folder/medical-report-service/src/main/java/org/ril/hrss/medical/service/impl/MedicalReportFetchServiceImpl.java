package org.ril.hrss.medical.service.impl;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.medical.client.MedicalReportFetchClient;
import org.ril.hrss.medical.jaxb.GetEmployeePMEDate;
import org.ril.hrss.medical.jaxb.GetEmployeePMEDateResponse;
import org.ril.hrss.medical.jaxb.GetEmployeePMEReportHTML;
import org.ril.hrss.medical.jaxb.GetEmployeePMEReportHTMLResponse;
import org.ril.hrss.medical.jaxb.PMEExamDate;
import org.ril.hrss.medical.service.MedicalReportFetchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class MedicalReportFetchServiceImpl implements MedicalReportFetchService {

	protected static final Logger logger = Logger.getLogger(MedicalReportFetchServiceImpl.class.getName());

	@Autowired
	@Qualifier("medicalReportFetchClientImpl")
	private MedicalReportFetchClient medicalReportFetchClient;

	@Override
	public List<PMEExamDate> getEmployeePMEDate(String userId) {
		logger.info("MedicalReportFetchServiceImpl.getEmployeePMEDate()..");
		GetEmployeePMEDate request = new GetEmployeePMEDate();
		request.setStrEmpNo(userId.substring(1));
		GetEmployeePMEDateResponse getEmployeePMEDateResponse = medicalReportFetchClient.getEmployeePMEDate(request);
		return getEmployeePMEDateResponse.getGetEmployeePMEDateResult().getPMEExamDate();
	}

	@Override
	public String getEmployeePMEReportHtml(String regnNo) {
		logger.info("MedicalReportFetchServiceImpl.getEmployeePMEReportHtml()..");
		GetEmployeePMEReportHTML request = new GetEmployeePMEReportHTML();
		request.setStrRegnNo(regnNo);
		GetEmployeePMEReportHTMLResponse getEmployeePMEReportHTMLResponse = medicalReportFetchClient
				.getEmployeePMEReportHtml(request);
		return getEmployeePMEReportHTMLResponse.getGetEmployeePMEReportHTMLResult();
	}

}