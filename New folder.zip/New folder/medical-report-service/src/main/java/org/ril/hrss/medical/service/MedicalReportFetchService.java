package org.ril.hrss.medical.service;

import java.util.List;

import org.ril.hrss.medical.jaxb.PMEExamDate;

public interface MedicalReportFetchService {

	public List<PMEExamDate> getEmployeePMEDate(String userId);

	public String getEmployeePMEReportHtml(String regNo);
}
