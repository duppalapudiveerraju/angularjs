package org.ril.hrss.medical.client;

import org.ril.hrss.medical.jaxb.GetEmployeePMEDate;
import org.ril.hrss.medical.jaxb.GetEmployeePMEDateResponse;
import org.ril.hrss.medical.jaxb.GetEmployeePMEReportHTML;
import org.ril.hrss.medical.jaxb.GetEmployeePMEReportHTMLResponse;

public interface MedicalReportFetchClient {

	public GetEmployeePMEDateResponse getEmployeePMEDate(GetEmployeePMEDate request);

	public GetEmployeePMEReportHTMLResponse getEmployeePMEReportHtml(GetEmployeePMEReportHTML request);
	
}