package org.ril.hrss.medical.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.medical.jaxb.PMEExamDate;
import org.ril.hrss.medical.service.MedicalReportFetchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationController {

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	@Autowired
	@Qualifier("medicalReportFetchServiceImpl")
	private MedicalReportFetchService medicalReportFetchService;

	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Fetch Medical Report Date List request", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully fetch"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<List<PMEExamDate>> getEmployeePMEDateList(@NotNull @RequestHeader("userId") String userId) {
		logger.info("MedicalReportFetchService.getEmployeePMEDateList()");
		List<PMEExamDate> response = medicalReportFetchService.getEmployeePMEDate(userId);
		return (response != null) ? new ResponseEntity<>(response, HttpStatus.OK)
				: new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@RequestMapping(value = "/details", method = RequestMethod.GET, produces = "text/html")
	@ApiOperation(value = "Fetch Medical Report request", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully fetch"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<String> getEmployeePMEReport(@NotNull @RequestHeader("regnNo") String regnNo) {
		logger.info("MedicalReportFetchService.getEmployeePMEReport()");
		String response = medicalReportFetchService.getEmployeePMEReportHtml(regnNo);
		return (response != null) ? new ResponseEntity<>(response, HttpStatus.OK)
				: new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}