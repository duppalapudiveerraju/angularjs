package org.ril.hrss.medical.client.impl;

import org.ril.hrss.medical.client.MedicalReportFetchClient;
import org.ril.hrss.medical.jaxb.GetEmployeePMEDate;
import org.ril.hrss.medical.jaxb.GetEmployeePMEDateResponse;
import org.ril.hrss.medical.jaxb.GetEmployeePMEReportHTML;
import org.ril.hrss.medical.jaxb.GetEmployeePMEReportHTMLResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

@Component
public class MedicalReportFetchClientImpl extends WebServiceGatewaySupport implements MedicalReportFetchClient {

	@Autowired
	private WebServiceTemplate webServiceTemplate;

	@Value("${medical.report.config.url.wsdl:http://risptest.ril.com/HMS/EP_Medical_Service.asmx}")
	private String pmeScheduleUrl;

	@Value("${medical.report.action.employeePmeDate:http://medical.ril.com/Get_Employee_PME_Date}")
	private String employeePmeDate;

	@Value("${medical.report.action.employeeReportHtml:http://medical.ril.com/Get_Employee_PME_Report_HTML}")
	private String employeeReportHtml;

	@Value("${medical.report.config.loginInfo:HMS}")
	private String loginInfo;

	@Override
	public GetEmployeePMEDateResponse getEmployeePMEDate(GetEmployeePMEDate request) {
		logger.info("MedicalReportFetchClientImpl.getEmployeePMEDate()..");
		request.setStrLoginInto(loginInfo);
		GetEmployeePMEDateResponse response = (GetEmployeePMEDateResponse) webServiceTemplate
				.marshalSendAndReceive(pmeScheduleUrl, request, new SoapActionCallback(employeePmeDate));
		return response;
	}

	@Override
	public GetEmployeePMEReportHTMLResponse getEmployeePMEReportHtml(GetEmployeePMEReportHTML request) {
		logger.info("MedicalReportFetchClientImpl.getEmployeePMEReportHtml()..");
		request.setStrLoginInto(loginInfo);
		GetEmployeePMEReportHTMLResponse response = (GetEmployeePMEReportHTMLResponse) webServiceTemplate
				.marshalSendAndReceive(pmeScheduleUrl, request, new SoapActionCallback(employeeReportHtml));
		return response;
	}
}
