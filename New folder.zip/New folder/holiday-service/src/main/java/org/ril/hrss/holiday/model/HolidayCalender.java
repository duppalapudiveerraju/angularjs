package org.ril.hrss.holiday.model;

import java.util.Date;

import org.ril.hrss.msf.util.DateUtil;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HolidayCalender {

	private Date holidayStartDate;
	private Date holidayEndDate;
	private String holidayDesc;

	public HolidayCalender() {
		super();
	}

	public HolidayCalender(Date holidayStartDate, Date holidayEndDate, String holidayDesc) {
		this();
		this.holidayStartDate = holidayStartDate;
		this.holidayEndDate = holidayEndDate;
		this.holidayDesc = holidayDesc;
	}

	@JsonProperty("holidayStartDate")
	public Date getHolidayStartDate() {
		return holidayStartDate;
	}

	@JsonProperty("HolDate")
	public void setHolidayStartDate(Date holidayStartDate) {
		this.holidayStartDate = holidayStartDate;
	}

	public Date getHolidayEndDate() {
		return DateUtil.getEndOfTheDay(holidayStartDate);
	}

	public void setHolidayEndDate(Date holidayEndDate) {
		this.holidayEndDate = holidayEndDate;
	}

	@JsonProperty("holidayDesc")
	public String getHolidayDesc() {
		return holidayDesc;
	}

	@JsonProperty("HolDesc")
	public void setHolidayDesc(String holidayDesc) {
		this.holidayDesc = holidayDesc;
	}

	@Override
	public String toString() {
		return "HolidayCalender [holidayStartDate=" + holidayStartDate + ", holidayEndDate=" + holidayEndDate
				+ ", holidayDesc=" + holidayDesc + "]";
	}

}