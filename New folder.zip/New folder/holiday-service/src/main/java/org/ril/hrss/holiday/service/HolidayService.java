package org.ril.hrss.holiday.service;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.holiday.client.SapEndpointClient;
import org.ril.hrss.holiday.interfaces.HolidayServiceRepo;
import org.ril.hrss.holiday.model.HolidayCalender;
import org.ril.hrss.holiday.util.HolidayUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netflix.client.ClientException;

@Service
public class HolidayService implements HolidayServiceRepo {
	
	protected static final Logger logger = Logger.getLogger(HolidayService.class.getName());
	
	@Autowired
	private SapEndpointClient sapEndpointClient;
	
	@Autowired
	private HolidayUtil holidayUtil;
	
	public HolidayService() {
		super();
	}
	
	@Override
	public List<HolidayCalender> getHolidayList(String userId, String year) throws ClientException {
		logger.info("HolidayService.getHolidayList()");
		return holidayUtil.getHolidayCalenderList(sapEndpointClient.getHolidayList(userId, year));
	}

}