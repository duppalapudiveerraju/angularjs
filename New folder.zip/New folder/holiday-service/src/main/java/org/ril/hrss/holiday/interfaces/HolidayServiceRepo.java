package org.ril.hrss.holiday.interfaces;

import java.util.List;

import org.ril.hrss.holiday.model.HolidayCalender;

import com.netflix.client.ClientException;

public interface HolidayServiceRepo {
	
	public List<HolidayCalender> getHolidayList(String userId, String year) throws ClientException;

}