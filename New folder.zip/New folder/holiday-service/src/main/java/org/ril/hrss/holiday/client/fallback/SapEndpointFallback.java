package org.ril.hrss.holiday.client.fallback;

import org.ril.hrss.holiday.client.SapEndpointClient;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getHolidayList(String userId, String year) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}
