package org.ril.hrss.holiday.client;

import org.ril.hrss.holiday.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.GET, value = "/sap/holiday/userId/{userId}/{year}")
	String getHolidayList(@PathVariable("userId") String userId, @PathVariable("year") String year);

}