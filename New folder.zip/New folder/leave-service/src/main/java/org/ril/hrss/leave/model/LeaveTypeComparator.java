package org.ril.hrss.leave.model;

import java.util.Comparator;
import java.util.List;

public class LeaveTypeComparator implements Comparator<LeaveDetail> {

	private List<String> leavePriorityObj;

	public LeaveTypeComparator() {
		super();
	}

	public LeaveTypeComparator(List<String> leavePriorityObj) {
		super();
		this.leavePriorityObj = leavePriorityObj;
	}

	@Override
	public int compare(LeaveDetail ldObj1, LeaveDetail ldObj2) {
		Integer priority1 = leavePriorityObj.indexOf(ldObj1.getLeaveCode()) == -1 ? Integer.MAX_VALUE
				: leavePriorityObj.indexOf(ldObj1.getLeaveCode());
		Integer priority2 = leavePriorityObj.indexOf(ldObj2.getLeaveCode()) == -1 ? Integer.MAX_VALUE
				: leavePriorityObj.indexOf(ldObj2.getLeaveCode());
		return priority1.compareTo(priority2);
	}

}