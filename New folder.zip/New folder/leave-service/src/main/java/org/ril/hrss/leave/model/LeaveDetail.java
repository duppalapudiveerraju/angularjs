package org.ril.hrss.leave.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(converter = LeaveDetailFilter.class)
public class LeaveDetail {

	private String leaveCode;
	private String leaveDesc;
	private boolean halfDayFlag;
	private boolean attachFlag;
	private Float balance;
	private boolean singleDayFlag;

	public LeaveDetail() {
		super();
	}

	public LeaveDetail(String leaveCode, String leaveDesc, boolean halfDayFlag, boolean attachFlag, Float balance,
			boolean singleDayFlag) {
		super();
		this.leaveCode = leaveCode;
		this.leaveDesc = leaveDesc;
		this.halfDayFlag = halfDayFlag;
		this.attachFlag = attachFlag;
		this.balance = balance;
		this.singleDayFlag = singleDayFlag;
	}

	@JsonProperty("leaveCode")
	public String getLeaveCode() {
		return leaveCode;
	}

	@JsonProperty("LeaveCode")
	public void setLeaveCode(String leaveCode) {
		this.leaveCode = leaveCode;
	}

	@JsonProperty("leaveDesc")
	public String getLeaveDesc() {
		return leaveDesc;
	}

	@JsonProperty("LeaveText")
	public void setLeaveDesc(String leaveDesc) {
		this.leaveDesc = leaveDesc;
	}

	@JsonProperty("halfDayFlag")
	public boolean isHalfDayFlag() {
		return halfDayFlag;
	}

	@JsonProperty("HalfDayFlag")
	public void setHalfDayFlag(String halfDayFlag) {
		this.halfDayFlag = halfDayFlag.isEmpty() ? Boolean.FALSE : Boolean.TRUE;
	}

	@JsonProperty("attachFlag")
	public boolean isAttachFlag() {
		return attachFlag;
	}

	@JsonProperty("AttachFlag")
	public void setAttachFlag(String attachFlag) {
		this.attachFlag = attachFlag.isEmpty() ? Boolean.FALSE : Boolean.TRUE;
	}

	@JsonProperty("balance")
	public Float getBalance() {
		return balance;
	}

	@JsonProperty("Balance")
	public void setBalance(Float balance) {
		this.balance = balance;
	}

	@JsonProperty("singleDayFlag")
	public boolean isSingleDayFlag() {
		return singleDayFlag;
	}

	@JsonProperty("OnlySingleDay")
	public void setSingleDayFlag(String singleDayFlag) {
		this.singleDayFlag = singleDayFlag.isEmpty() ? Boolean.FALSE : Boolean.TRUE;
	}

}