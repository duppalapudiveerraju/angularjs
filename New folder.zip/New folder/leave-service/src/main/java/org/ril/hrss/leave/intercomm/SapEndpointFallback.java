package org.ril.hrss.leave.intercomm;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getLeaveDetails(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}
