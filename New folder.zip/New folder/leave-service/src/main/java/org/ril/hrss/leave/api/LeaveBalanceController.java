package org.ril.hrss.leave.api;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.leave.model.LeaveDetail;
import org.ril.hrss.leave.util.LeaveUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/leave")
@Api(value = "Leave Details", description = "Operations pertaining to find leave history")
public class LeaveBalanceController {

	@Autowired
	private LeaveUtil leaveUtil;

	protected static final Logger logger = Logger.getLogger(LeaveUtil.class.getName());

	public LeaveBalanceController() {
		super();
	}

	@RequestMapping(value = "/details/userId/{userId}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of leave details with balance", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<LeaveDetail> getLeaveBalanceDetails(@PathVariable("userId") String userId) throws ClientException {
		logger.info("leave.getLeaveBalanceDetails()");
		return leaveUtil.getLeaveBalanceDetails(userId);
	}

}