package org.ril.hrss.leave.model;

import java.util.ArrayList;
import java.util.List;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class LeaveDetailFilter extends StdConverter<LeaveDetail, LeaveDetail> {

	private List<String> leaveConstant;

	public LeaveDetailFilter() {
		super();
		leaveConstant = new ArrayList<>();
		leaveConstant.add("0150");
		leaveConstant.add("0450");
	}

	@Override
	public LeaveDetail convert(LeaveDetail obj) {
		if (leaveConstant.contains(obj.getLeaveCode())) {
			obj.setBalance(HRSSConstantUtil.DUMMY_BALANCE);
		} else if (obj.getLeaveCode().equals(HRSSConstantUtil.APL_LEAVE_CODE)) {
			obj.setBalance(HRSSConstantUtil.APL_DUMMY_BALANCE + obj.getBalance());
		}
		return obj;
	}

}