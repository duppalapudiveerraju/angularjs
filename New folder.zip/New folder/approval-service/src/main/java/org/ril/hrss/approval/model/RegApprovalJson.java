package org.ril.hrss.approval.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class RegApprovalJson {

	private Date applyDate;
	private String employeeId;
	private boolean slaBreached;
	private String employeeName;
	private Date regDate;
	private String shiftType;
	private Date actualIn;
	private Date actualOut;
	private Date regIn;
	private Date regOut;
	private Double regHrs;
	private String regStatus;
	private String regReason;
	private String regRemark;
	private String regCounter;
	private boolean approvalAction;
	private String requestStatus;
	private String requestErrMsg;
	private String systemErrMsg;

	public RegApprovalJson() {
		super();
	}

	public RegApprovalJson(Date applyDate, String employeeId, boolean slaBreached, String employeeName, Date regDate,
			String shiftType, Date actualIn, Date actualOut, Date regIn, Date regOut, Double regHrs, String regStatus,
			String regReason, String regRemark, String regCounter, boolean approvalAction, String requestStatus,
			String requestErrMsg, String systemErrMsg) {
		super();
		this.applyDate = applyDate;
		this.employeeId = employeeId;
		this.slaBreached = slaBreached;
		this.employeeName = employeeName;
		this.regDate = regDate;
		this.shiftType = shiftType;
		this.actualIn = actualIn;
		this.actualOut = actualOut;
		this.regIn = regIn;
		this.regOut = regOut;
		this.regHrs = regHrs;
		this.regStatus = regStatus;
		this.regReason = regReason;
		this.regRemark = regRemark;
		this.regCounter = regCounter;
		this.approvalAction = approvalAction;
		this.requestStatus = requestStatus;
		this.requestErrMsg = requestErrMsg;
		this.setSystemErrMsg(systemErrMsg);
	}

	public Date getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public boolean isSlaBreached() {
		return slaBreached;
	}

	public void setSlaBreached(boolean slaBreached) {
		this.slaBreached = slaBreached;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getShiftType() {
		return shiftType;
	}

	public void setShiftType(String shiftType) {
		this.shiftType = shiftType;
	}

	public Date getActualIn() {
		return actualIn;
	}

	public Date getActualOut() {
		return actualOut;
	}

	public Date getRegIn() {
		return regIn;
	}

	public Date getRegOut() {
		return regOut;
	}

	public void setActualIn(Date actualIn) {
		this.actualIn = actualIn;
	}

	public void setActualOut(Date actualOut) {
		this.actualOut = actualOut;
	}

	public void setRegIn(Date regIn) {
		this.regIn = regIn;
	}

	public void setRegOut(Date regOut) {
		this.regOut = regOut;
	}

	public Double getRegHrs() {
		return regHrs;
	}

	public void setRegHrs(Double regHrs) {
		this.regHrs = regHrs;
	}

	public String getRegStatus() {
		return regStatus;
	}

	public void setRegStatus(String regStatus) {
		this.regStatus = regStatus;
	}

	public String getRegReason() {
		return regReason;
	}

	public void setRegReason(String regReason) {
		this.regReason = regReason;
	}

	public String getRegRemark() {
		return regRemark;
	}

	public void setRegRemark(String regRemark) {
		this.regRemark = regRemark;
	}

	public String getRegCounter() {
		return regCounter;
	}

	public void setRegCounter(String regCounter) {
		this.regCounter = regCounter;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}

	public boolean getApprovalAction() {
		return approvalAction;
	}

	public void setApprovalAction(boolean approvalAction) {
		this.approvalAction = approvalAction;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public String getSystemErrMsg() {
		return systemErrMsg;
	}

	public void setSystemErrMsg(String systemErrMsg) {
		this.systemErrMsg = systemErrMsg;
	}

	@Override
	public String toString() {
		return "RegApprovalJson [applyDate=" + applyDate + ", employeeId=" + employeeId + ", slaBreached=" + slaBreached
				+ ", employeeName=" + employeeName + ", regDate=" + regDate + ", shiftType=" + shiftType + ", actualIn="
				+ actualIn + ", actualOut=" + actualOut + ", regIn=" + regIn + ", regOut=" + regOut + ", regHrs="
				+ regHrs + ", regStatus=" + regStatus + ", regReason=" + regReason + ", regRemark=" + regRemark
				+ ", regCounter=" + regCounter + ", approvalAction=" + approvalAction + ", requestStatus="
				+ requestStatus + ", requestErrMsg=" + requestErrMsg + ", systemErrMsg=" + systemErrMsg + "]";
	}

}