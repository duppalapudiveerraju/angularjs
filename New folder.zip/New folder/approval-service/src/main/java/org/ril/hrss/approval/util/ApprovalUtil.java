package org.ril.hrss.approval.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.approval.client.NotificationClient;
import org.ril.hrss.approval.model.LeaveApproval;
import org.ril.hrss.approval.model.LeaveApprovalJson;
import org.ril.hrss.approval.model.LeaveApprovalRequest;
import org.ril.hrss.approval.model.RegApproval;
import org.ril.hrss.approval.model.RegApprovalJson;
import org.ril.hrss.approval.model.RegApprovalRequest;
import org.ril.hrss.msf.model.LeavePendingApprovalDetail;
import org.ril.hrss.msf.model.Notification;
import org.ril.hrss.msf.model.RegualrizePendingApprovalDetail;
import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.FindDateRange;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.MessagePlaceHolder;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.ril.hrss.msf.util.enumeration.NotificationDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ApprovalUtil {

	protected static final Logger logger = Logger.getLogger(ApprovalUtil.class.getName());

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public ApprovalUtil() {
		super();
	}

	public Notification getNotificationContentLeaveApproval(String userId, List<LeaveApprovalJson> list,
			List<LeaveApproval> inputList) {
		logger.info("ApprovalUtil.getNotificationContentLeaveApproval()");
		List<String> fromToDateList = new ArrayList<>();
		List<Date> leaveDateList = new ArrayList<>();

		ObjectMapper objectMapper = objectMapperUtil.get();
		if (inputList != null) {
			inputList.stream().forEach(obj -> {
				try {
					LeavePendingApprovalDetail leaveObj = objectMapper.readValue(objectMapper.writeValueAsString(obj),
							new TypeReference<LeavePendingApprovalDetail>() {
							});
					if (leaveObj != null && leaveObj.getLeaveFromDate().equals(leaveObj.getLeaveToDate())) {
						leaveDateList.add(leaveObj.getLeaveFromDate());
					} else {
						leaveDateList.addAll(DateUtil.getListOfDaysBetweenTwoDates(leaveObj.getLeaveFromDate(),
								leaveObj.getLeaveToDate()));
					}
				} catch (IOException e1) {
					logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
				}
			});
		}

		fromToDateList = FindDateRange.findRange(leaveDateList);

		List<LeaveApprovalJson> successList = list.parallelStream()
				.filter(e -> e.getRequestStatus().equals(HRSSConstantUtil.POST_RESPONSE_STATUS_SUCCESS))
				.collect(Collectors.toList());
		if (list.size() == successList.size()) {
			return setNotificationRequest(userId,
					MessagePlaceHolder.formater(HRSSConstantUtil.APPROVALS_LEAVE_MSG,
							list.get(HRSSConstantUtil.ZERO.intValue()).getEmployeeName(),
							String.join(HRSSConstantUtil.SPACE_COMMA, fromToDateList)),
					NotificationDetails.MANAGER_APPROVALS.getNotificationTitle());
		} else {
			return setNotificationRequest(userId,
					MessagePlaceHolder.formater(HRSSConstantUtil.APPROVALS_REJECT_LEAVE_MSG,
							list.get(HRSSConstantUtil.ZERO.intValue()).getEmployeeName(),
							String.join(HRSSConstantUtil.SPACE_COMMA, fromToDateList)),
					NotificationDetails.MANAGER_APPROVALS.getNotificationTitle());
		}
	}

	public LeaveApprovalRequest setLeaveApprovalRequest(LeaveApproval obj) {
		logger.info("ApprovalUtil.setLeaveApprovalRequest()");
		LeaveApprovalRequest requestObj = new LeaveApprovalRequest();
		List<LeaveApproval> list = new ArrayList<LeaveApproval>();
		list.add(obj);
		requestObj.setApprovalAction(
				obj.isApprovalAction() ? HRSSConstantUtil.APPROVAL_REQUEST : HRSSConstantUtil.REJECTION_REQUEST);
		requestObj.setApprovalErrorSet(Collections.emptyList());
		requestObj.setApprovalRequest(list);
		return requestObj;
	}

	public Notification getNotificationContentRegApproval(String userId, List<RegApprovalJson> list,
			List<RegApproval> inputList) {
		logger.info("ApprovalUtil.getNotificationContentRegApproval()");

		List<Date> regDateList = new ArrayList<>();
		List<String> regDateListString = new ArrayList<>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		if (inputList != null) {
			inputList.stream().forEach(obj -> {
				try {
					RegualrizePendingApprovalDetail regObj = objectMapper.readValue(
							objectMapper.writeValueAsString(obj), new TypeReference<RegualrizePendingApprovalDetail>() {
							});
					if (regObj != null) {
						regDateList.add(regObj.getRegDate());
					}
				} catch (IOException e1) {
					logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
				}
			});
		}
		regDateListString = FindDateRange.findRange(regDateList);

		List<RegApprovalJson> successList = list.parallelStream()
				.filter(e -> e.getRequestStatus().equals(HRSSConstantUtil.POST_RESPONSE_STATUS_SUCCESS))
				.collect(Collectors.toList());
		if (list.size() == successList.size()) {
			return setNotificationRequest(userId,
					MessagePlaceHolder.formater(HRSSConstantUtil.APPROVALS_REG_MSG,
							list.get(HRSSConstantUtil.ZERO.intValue()).getEmployeeName(),
							String.join(HRSSConstantUtil.SPACE_COMMA, regDateListString)),
					NotificationDetails.MANAGER_APPROVALS.getNotificationTitle());
		} else {
			return setNotificationRequest(userId,
					MessagePlaceHolder.formater(HRSSConstantUtil.APPROVALS_REJECT_REG_MSG,
							list.get(HRSSConstantUtil.ZERO.intValue()).getEmployeeName(),
							String.join(HRSSConstantUtil.SPACE_COMMA, regDateListString)),
					NotificationDetails.MANAGER_APPROVALS.getNotificationTitle());
		}
	}

	private Notification setNotificationRequest(String userId, String message, String title) {
		logger.info("ApprovalUtil.setNotificationRequest()");
		return new Notification(message, title, new String[] { userId });
	}

	public RegApprovalRequest setRegApprovalRequest(RegApproval obj) {
		logger.info("ApprovalUtil.setRegApprovalRequest()");
		RegApprovalRequest requestObj = new RegApprovalRequest();
		List<RegApproval> list = new ArrayList<RegApproval>();
		list.add(obj);
		requestObj.setApprovalAction(
				obj.isApprovalAction() ? HRSSConstantUtil.APPROVAL_REQUEST : HRSSConstantUtil.REJECTION_REQUEST);
		requestObj.setApprovalErrorSet(Collections.emptyList());
		requestObj.setApprovalRequest(list);
		return requestObj;
	}

	public void sendLeaveNotificationRequest(List<LeaveApproval> inputList, List<LeaveApprovalJson> result,
			NotificationClient notificationClient) {
		logger.info("ApprovalUtil.sendLeaveNotificationRequest()");
		new Thread(() -> {
			notificationClient
					.saveNotificationRequest(getNotificationContentLeaveApproval(
							HRSSConstantUtil.SAP_PERSON_PREFIX
									+ inputList.get(HRSSConstantUtil.ZERO.intValue()).getEmployeeId(),
							result, inputList));
		}).start();
	}

	public void sendRegNotificationRequest(List<RegApproval> inputList, List<RegApprovalJson> result,
			NotificationClient notificationClient) {
		logger.info("ApprovalUtil.sendRegNotificationRequest()");

		new Thread(() -> {
			notificationClient
					.saveNotificationRequest(getNotificationContentRegApproval(
							HRSSConstantUtil.SAP_PERSON_PREFIX
									+ inputList.get(HRSSConstantUtil.ZERO.intValue()).getEmployeeId(),
							result, inputList));
		}).start();
	}

}