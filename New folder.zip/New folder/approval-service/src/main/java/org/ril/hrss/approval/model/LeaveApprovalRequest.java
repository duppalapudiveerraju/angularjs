package org.ril.hrss.approval.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LeaveApprovalRequest {

	private String approvalAction;
	private List<Object> approvalErrorSet;
	private List<LeaveApproval> approvalRequest;

	public LeaveApprovalRequest() {
		super();
	}

	public LeaveApprovalRequest(String approvalAction, List<Object> approvalErrorSet,
			List<LeaveApproval> approvalRequest) {
		super();
		this.approvalAction = approvalAction;
		this.approvalErrorSet = approvalErrorSet;
		this.approvalRequest = approvalRequest;
	}

	@JsonProperty("ImAction")
	public String getApprovalAction() {
		return approvalAction;
	}

	public void setApprovalAction(String approvalAction) {
		this.approvalAction = approvalAction;
	}

	@JsonProperty("AppTmOTErrSet")
	public List<Object> getApprovalErrorSet() {
		return approvalErrorSet;
	}

	public void setApprovalErrorSet(List<Object> approvalErrorSet) {
		this.approvalErrorSet = approvalErrorSet;
	}

	@JsonProperty("AppTmLevSet")
	public List<LeaveApproval> getApprovalRequest() {
		return approvalRequest;
	}

	public void setApprovalRequest(List<LeaveApproval> approvalRequest) {
		this.approvalRequest = approvalRequest;
	}

}
