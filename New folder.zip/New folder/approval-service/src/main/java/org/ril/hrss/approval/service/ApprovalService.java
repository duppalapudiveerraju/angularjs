package org.ril.hrss.approval.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.ril.hrss.approval.client.NotificationClient;
import org.ril.hrss.approval.client.SapEndpointClient;
import org.ril.hrss.approval.interfaces.ApprovalServiceRepo;
import org.ril.hrss.approval.model.LeaveApproval;
import org.ril.hrss.approval.model.LeaveApprovalJson;
import org.ril.hrss.approval.model.LeaveApprovalRequest;
import org.ril.hrss.approval.model.RegApproval;
import org.ril.hrss.approval.model.RegApprovalJson;
import org.ril.hrss.approval.model.RegApprovalRequest;
import org.ril.hrss.approval.util.ApprovalUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.ril.hrss.msf.util.SAPErrorHandlerUtil;
import org.ril.hrss.msf.util.enumeration.SAPGenericError;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.netflix.client.ClientException;

@Service
public class ApprovalService implements ApprovalServiceRepo {

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private SAPErrorHandlerUtil sapErrorHandlerUtil;

	@Autowired
	private NotificationClient notificationClient;

	@Autowired
	private ApprovalUtil approvalUtil;

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	protected static final Logger logger = Logger.getLogger(ApprovalService.class.getName());

	public ApprovalService() {
		super();
	}

	@Override
	public List<LeaveApprovalJson> processLeavePostResponse(String userId, List<LeaveApproval> inputList)
			throws ClientException {
		logger.info("ApprovalService.processLeavePostResponse()");
		List<LeaveApprovalJson> result = new ArrayList<LeaveApprovalJson>();
		for (LeaveApproval obj : inputList) {
			try {
				LeaveApprovalRequest requestObj = approvalUtil.setLeaveApprovalRequest(obj);
				Map<String, String> map = sapEndpointClient.applyLeaveApprovalRequest(userId,
						objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST).writeValueAsString(requestObj));
				obj.setRequestStatus(map.get(HRSSConstantUtil.POST_RESPONSE_STATUS));
				obj.setSystemErrMsg(map.get(HRSSConstantUtil.POST_RESPONSE_SYSTEM_ERR_MSG));
				obj.setRequestErrMsg(sapErrorHandlerUtil.setCustomErrMsg(map, SAPGenericError.APPROVE_LEAVE));
				LeaveApprovalJson resultObj = new LeaveApprovalJson();
				BeanUtils.copyProperties(obj, resultObj);
				result.add(resultObj);
			} catch (JsonProcessingException e) {
				logger.info(HRSSConstantUtil.JSON_PROCESSING_FALIED_MSG);
			}
		}
		approvalUtil.sendLeaveNotificationRequest(inputList, result, notificationClient);
		return result;
	}

	@Override
	public List<RegApprovalJson> processRegPostResponse(String userId, List<RegApproval> inputList)
			throws ClientException {
		logger.info("ApprovalService.processRegPostResponse()");
		List<RegApprovalJson> result = new ArrayList<RegApprovalJson>();
		for (RegApproval obj : inputList) {
			try {
				RegApprovalRequest requestObj = approvalUtil.setRegApprovalRequest(obj);
				Map<String, String> map = sapEndpointClient.applyRegApprovalRequest(userId,
						objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST).writeValueAsString(requestObj));
				obj.setRequestStatus(map.get(HRSSConstantUtil.POST_RESPONSE_STATUS));
				obj.setSystemErrMsg(map.get(HRSSConstantUtil.POST_RESPONSE_SYSTEM_ERR_MSG));
				obj.setRequestErrMsg(sapErrorHandlerUtil.setCustomErrMsg(map, SAPGenericError.APPROVE_REGULARIZE));
				RegApprovalJson resultObj = new RegApprovalJson();
				BeanUtils.copyProperties(obj, resultObj);
				result.add(resultObj);
			} catch (JsonProcessingException e) {
				logger.info(HRSSConstantUtil.JSON_PROCESSING_FALIED_MSG);
			}
		}
		approvalUtil.sendRegNotificationRequest(inputList, result, notificationClient);
		return result;
	}

}