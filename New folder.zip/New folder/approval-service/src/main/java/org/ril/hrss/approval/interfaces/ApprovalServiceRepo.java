package org.ril.hrss.approval.interfaces;

import java.util.List;

import org.ril.hrss.approval.model.LeaveApproval;
import org.ril.hrss.approval.model.LeaveApprovalJson;
import org.ril.hrss.approval.model.RegApproval;
import org.ril.hrss.approval.model.RegApprovalJson;

import com.netflix.client.ClientException;

public interface ApprovalServiceRepo {
	
	public List<LeaveApprovalJson> processLeavePostResponse(String userId, List<LeaveApproval> inputList) throws ClientException;
	
	public List<RegApprovalJson> processRegPostResponse(String userId, List<RegApproval> inputList) throws ClientException;

}