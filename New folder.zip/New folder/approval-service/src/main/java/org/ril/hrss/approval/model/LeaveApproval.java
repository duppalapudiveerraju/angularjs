package org.ril.hrss.approval.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.DoubleToStrSerializer;
import org.ril.hrss.msf.custom.serializer.EmptyStringSerializer;
import org.ril.hrss.msf.custom.serializer.SAPDateFormatSerializer;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class LeaveApproval {

	private String attachDocId;
	private Date applyDate;
	private String leaveRequestId;
	private boolean slaBreached;
	private String employeeId;
	private String employeeName;
	private Date leaveFromDate;
	private Date leaveToDate;
	private String leaveDesc;
	private Double leaveNoOfDays;
	private String leaveRemark;
	private boolean approvalAction;
	private String requestStatus;
	private String requestErrMsg;
	private String systemErrMsg;

	public LeaveApproval() {
		super();
	}

	public LeaveApproval(String attachDocId, Date applyDate, String leaveRequestId, boolean slaBreached,
			String employeeId, String employeeName, Date leaveFromDate, Date leaveToDate, String leaveDesc,
			Double leaveNoOfDays, String leaveRemark, boolean approvalAction, String requestStatus,
			String requestErrMsg, String systemErrMsg) {
		super();
		this.attachDocId = attachDocId;
		this.applyDate = applyDate;
		this.leaveRequestId = leaveRequestId;
		this.slaBreached = slaBreached;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.leaveFromDate = leaveFromDate;
		this.leaveToDate = leaveToDate;
		this.leaveDesc = leaveDesc;
		this.leaveNoOfDays = leaveNoOfDays;
		this.leaveRemark = leaveRemark;
		this.approvalAction = approvalAction;
		this.requestStatus = requestStatus;
		this.requestErrMsg = requestErrMsg;
		this.systemErrMsg = systemErrMsg;
	}

	@JsonProperty("ArcDocId")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getAttachDocId() {
		return attachDocId;
	}

	@JsonProperty("attachDocId")
	public void setAttachDocId(String attachDocId) {
		this.attachDocId = attachDocId;
	}

	@JsonProperty("Ersda")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getApplyDate() {
		return applyDate;
	}

	@JsonProperty("applyDate")
	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	@JsonProperty("RequestId")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getLeaveRequestId() {
		return leaveRequestId;
	}

	@JsonProperty("leaveRequestId")
	public void setLeaveRequestId(String leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	@JsonIgnore
	public boolean isSlaBreached() {
		return slaBreached;
	}

	@JsonProperty("slaBreached")
	public void setSlaBreached(boolean slaBreached) {
		this.slaBreached = slaBreached;
	}

	@JsonProperty("EmpNo")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getEmployeeId() {
		return employeeId;
	}

	@JsonProperty("employeeId")
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@JsonProperty("EmpName")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getEmployeeName() {
		return employeeName;
	}

	@JsonProperty("employeeName")
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	@JsonProperty("FromDate")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getLeaveFromDate() {
		return leaveFromDate;
	}

	@JsonProperty("leaveFromDate")
	public void setLeaveFromDate(Date leaveFromDate) {
		this.leaveFromDate = leaveFromDate;
	}

	@JsonProperty("ToDate")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getLeaveToDate() {
		return leaveToDate;
	}

	@JsonProperty("leaveToDate")
	public void setLeaveToDate(Date leaveToDate) {
		this.leaveToDate = leaveToDate;
	}

	@JsonProperty("LeaveDesc")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getLeaveDesc() {
		return leaveDesc;
	}

	@JsonProperty("leaveDesc")
	public void setLeaveDesc(String leaveDesc) {
		this.leaveDesc = leaveDesc;
	}

	@JsonProperty("NoOfDays")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	public Double getLeaveNoOfDays() {
		return leaveNoOfDays;
	}

	@JsonProperty("leaveNoOfDays")
	public void setLeaveNoOfDays(Double leaveNoOfDays) {
		this.leaveNoOfDays = leaveNoOfDays;
	}

	@JsonProperty("Remarks")
	@JsonSerialize(converter = EmptyStringSerializer.class)
	public String getLeaveRemark() {
		return leaveRemark;
	}

	@JsonProperty("leaveRemark")
	public void setLeaveRemark(String leaveRemark) {
		this.leaveRemark = leaveRemark;
	}

	@JsonIgnore
	public boolean isApprovalAction() {
		return approvalAction;
	}

	@JsonProperty("approvalAction")
	public void setApprovalAction(boolean approvalAction) {
		this.approvalAction = approvalAction;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public String getSystemErrMsg() {
		return systemErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public void setSystemErrMsg(String systemErrMsg) {
		this.systemErrMsg = systemErrMsg;
	}

	@Override
	public String toString() {
		return "LeaveApproval [attachDocId=" + attachDocId + ", applyDate=" + applyDate + ", leaveRequestId="
				+ leaveRequestId + ", slaBreached=" + slaBreached + ", employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", leaveFromDate=" + leaveFromDate + ", leaveToDate=" + leaveToDate + ", leaveDesc="
				+ leaveDesc + ", leaveNoOfDays=" + leaveNoOfDays + ", leaveRemark=" + leaveRemark + ", approvalAction="
				+ approvalAction + ", requestStatus=" + requestStatus + ", requestErrMsg=" + requestErrMsg
				+ ", systemErrMsg=" + systemErrMsg + "]";
	}

}