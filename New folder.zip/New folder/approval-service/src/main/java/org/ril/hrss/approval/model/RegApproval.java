package org.ril.hrss.approval.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.DoubleToStrSerializer;
import org.ril.hrss.msf.custom.serializer.SAPClockFormatSerializer;
import org.ril.hrss.msf.custom.serializer.SAPDateFormatSerializer;
import org.ril.hrss.msf.custom.serializer.SAPTimeFormatSerailizer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class RegApproval {

	private Date applyDate;
	private String employeeId;
	private boolean slaBreached;
	private String employeeName;
	private Date regDate;
	private String shiftType;
	private Date actualIn;
	private Date actualOut;
	private Date regIn;
	private Date regOut;
	private Double regHrs;
	private String regStatus;
	private String regReason;
	private String regRemark;
	private String regCounter;
	private boolean approvalAction;
	private String requestStatus;
	private String requestErrMsg;
	private String systemErrMsg;

	public RegApproval() {
		super();
	}

	public RegApproval(Date applyDate, String employeeId, boolean slaBreached, String employeeName, Date regDate,
			String shiftType, Date actualIn, Date actualOut, Date regIn, Date regOut, Double regHrs, String regStatus,
			String regReason, String regRemark, String regCounter, boolean approvalAction, String requestStatus,
			String requestErrMsg, String systemErrMsg) {
		super();
		this.applyDate = applyDate;
		this.employeeId = employeeId;
		this.slaBreached = slaBreached;
		this.employeeName = employeeName;
		this.regDate = regDate;
		this.shiftType = shiftType;
		this.actualIn = actualIn;
		this.actualOut = actualOut;
		this.regIn = regIn;
		this.regOut = regOut;
		this.regHrs = regHrs;
		this.regStatus = regStatus;
		this.regReason = regReason;
		this.regRemark = regRemark;
		this.regCounter = regCounter;
		this.approvalAction = approvalAction;
		this.requestStatus = requestStatus;
		this.requestErrMsg = requestErrMsg;
		this.systemErrMsg = systemErrMsg;
	}

	@JsonProperty("Ersda")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getApplyDate() {
		return applyDate;
	}

	@JsonProperty("applyDate")
	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	@JsonProperty("EmpNo")
	public String getEmployeeId() {
		return employeeId;
	}

	@JsonProperty("employeeId")
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@JsonIgnore
	public boolean isSlaBreached() {
		return slaBreached;
	}

	@JsonProperty("slaBreached")
	public void setSlaBreached(boolean slaBreached) {
		this.slaBreached = slaBreached;
	}

	@JsonProperty("EmpName")
	public String getEmployeeName() {
		return employeeName;
	}

	@JsonProperty("employeeName")
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	@JsonProperty("Date")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getRegDate() {
		return regDate;
	}

	@JsonProperty("regDate")
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	@JsonProperty("Shift")
	public String getShiftType() {
		return shiftType;
	}

	@JsonProperty("shiftType")
	public void setShiftType(String shiftType) {
		this.shiftType = shiftType;
	}

	@JsonProperty("ActIn")
	@JsonSerialize(converter = SAPClockFormatSerializer.class)
	public Date getActualIn() {
		return actualIn;
	}

	@JsonProperty("actualIn")
	public void setActualIn(Date actualIn) {
		this.actualIn = actualIn;
	}

	@JsonProperty("ActOut")
	@JsonSerialize(converter = SAPClockFormatSerializer.class)
	public Date getActualOut() {
		return actualOut;
	}

	@JsonProperty("actualOut")
	public void setActualOut(Date actualOut) {
		this.actualOut = actualOut;
	}

	@JsonProperty("RegIn")
	@JsonSerialize(converter = SAPTimeFormatSerailizer.class)
	public Date getRegIn() {
		return regIn;
	}

	@JsonProperty("regIn")
	public void setRegIn(Date regIn) {
		this.regIn = regIn;
	}

	@JsonProperty("RegOut")
	@JsonSerialize(converter = SAPTimeFormatSerailizer.class)
	public Date getRegOut() {
		return regOut;
	}

	@JsonProperty("regOut")
	public void setRegOut(Date regOut) {
		this.regOut = regOut;
	}

	@JsonProperty("Hrs")
	@JsonSerialize(converter = DoubleToStrSerializer.class)
	public Double getRegHrs() {
		return regHrs;
	}

	@JsonProperty("regHrs")
	public void setRegHrs(Double regHrs) {
		this.regHrs = regHrs;
	}

	@JsonProperty("Status")
	public String getRegStatus() {
		return regStatus;
	}

	@JsonProperty("regStatus")
	public void setRegStatus(String regStatus) {
		this.regStatus = regStatus;
	}

	@JsonProperty("Reason")
	public String getRegReason() {
		return regReason;
	}

	@JsonProperty("regReason")
	public void setRegReason(String regReason) {
		this.regReason = regReason;
	}

	@JsonProperty("Remarks")
	public String getRegRemark() {
		return regRemark;
	}

	@JsonProperty("regRemark")
	public void setRegRemark(String regRemark) {
		this.regRemark = regRemark;
	}

	@JsonProperty("Counter")
	public String getRegCounter() {
		return regCounter;
	}

	@JsonProperty("regCounter")
	public void setRegCounter(String regCounter) {
		this.regCounter = regCounter;
	}

	@JsonIgnore
	public boolean isApprovalAction() {
		return approvalAction;
	}

	@JsonProperty("approvalAction")
	public void setApprovalAction(boolean approvalAction) {
		this.approvalAction = approvalAction;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}
	
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public String getSystemErrMsg() {
		return systemErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public void setSystemErrMsg(String systemErrMsg) {
		this.systemErrMsg = systemErrMsg;
	}

	@Override
	public String toString() {
		return "RegApproval [applyDate=" + applyDate + ", employeeId=" + employeeId + ", slaBreached=" + slaBreached
				+ ", employeeName=" + employeeName + ", regDate=" + regDate + ", shiftType=" + shiftType + ", actualIn="
				+ actualIn + ", actualOut=" + actualOut + ", regIn=" + regIn + ", regOut=" + regOut + ", regHrs="
				+ regHrs + ", regStatus=" + regStatus + ", regReason=" + regReason + ", regRemark=" + regRemark
				+ ", regCounter=" + regCounter + ", approvalAction=" + approvalAction + ", requestStatus="
				+ requestStatus + ", requestErrMsg=" + requestErrMsg + ", systemErrMsg=" + systemErrMsg + "]";
	}

}