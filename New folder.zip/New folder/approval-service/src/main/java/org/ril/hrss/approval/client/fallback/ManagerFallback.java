package org.ril.hrss.approval.client.fallback;

import java.util.ArrayList;
import java.util.List;

import org.ril.hrss.approval.client.ManagerClient;
import org.springframework.stereotype.Component;

@Component
public class ManagerFallback implements ManagerClient {

	@Override
	public List<String> getManagerInfoDetails(String userId) {
		return new ArrayList<>();
	}

}
