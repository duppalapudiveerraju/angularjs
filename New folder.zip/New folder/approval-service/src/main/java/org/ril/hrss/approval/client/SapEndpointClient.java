package org.ril.hrss.approval.client;

import java.util.Map;

import org.ril.hrss.approval.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.POST, value = "/sap/approval/apply/leave/{userId}", produces = "application/json", consumes = "application/json")
	Map<String, String> applyLeaveApprovalRequest(@PathVariable("userId") String userId,
			@RequestBody String approvalJSONString);

	@RequestMapping(method = RequestMethod.POST, value = "/sap/approval/apply/regularize/{userId}", produces = "application/json", consumes = "application/json")
	Map<String, String> applyRegApprovalRequest(@PathVariable("userId") String userId,
			@RequestBody String approvalJSONString);

}
