package org.ril.hrss.approval.client.fallback;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.approval.client.SapEndpointClient;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public Map<String, String> applyLeaveApprovalRequest(String userId, String approvalJSONString) {
		return new HashMap<String, String>();
	}

	@Override
	public Map<String, String> applyRegApprovalRequest(String userId, String approvalJSONString) {
		return new HashMap<String, String>();
	}

}
