package org.ril.hrss.approval.client.fallback;

import org.ril.hrss.approval.client.NotificationClient;
import org.ril.hrss.msf.model.Notification;
import org.ril.hrss.msf.model.NotificationResponse;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class NotificationFallback implements NotificationClient {

	@Override
	public ResponseEntity<NotificationResponse> saveNotificationRequest(Notification input) {
		return new ResponseEntity<NotificationResponse>(new NotificationResponse(HRSSConstantUtil.EMPTY_STRING,
				HttpStatus.OK, HRSSConstantUtil.EMPTY_STRING), HttpStatus.OK);
	}

}