package org.ril.hrss.approval.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RegApprovalRequest {

	private String approvalAction;
	private List<Object> approvalErrorSet;
	private List<RegApproval> approvalRequest;

	public RegApprovalRequest() {
		super();
	}

	public RegApprovalRequest(String approvalAction, List<Object> approvalErrorSet, List<RegApproval> approvalRequest) {
		super();
		this.approvalAction = approvalAction;
		this.approvalErrorSet = approvalErrorSet;
		this.approvalRequest = approvalRequest;
	}

	@JsonProperty("ImAction")
	public String getApprovalAction() {
		return approvalAction;
	}

	public void setApprovalAction(String approvalAction) {
		this.approvalAction = approvalAction;
	}

	@JsonProperty("AppTmAttnRegErrSet")
	public List<Object> getApprovalErrorSet() {
		return approvalErrorSet;
	}

	public void setApprovalErrorSet(List<Object> approvalErrorSet) {
		this.approvalErrorSet = approvalErrorSet;
	}

	@JsonProperty("AppTmAttnRegItmSet")
	public List<RegApproval> getApprovalRequest() {
		return approvalRequest;
	}

	public void setApprovalRequest(List<RegApproval> approvalRequest) {
		this.approvalRequest = approvalRequest;
	}

}