package org.ril.hrss.approval.client;

import org.ril.hrss.approval.client.fallback.NotificationFallback;
import org.ril.hrss.msf.model.Notification;
import org.ril.hrss.msf.model.NotificationResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "notification-queue-service", fallback = NotificationFallback.class)
public interface NotificationClient {

	@RequestMapping(method = RequestMethod.POST, value = "/queue/push", produces = "application/json", consumes = "application/json")
	ResponseEntity<NotificationResponse> saveNotificationRequest(@RequestBody Notification input);

}