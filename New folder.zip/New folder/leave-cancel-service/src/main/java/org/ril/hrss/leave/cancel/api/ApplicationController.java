package org.ril.hrss.leave.cancel.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.leave.cancel.interfaces.LeaveCancelRepo;
import org.ril.hrss.leave.cancel.model.CancelLeave;
import org.ril.hrss.leave.cancel.model.CancelLeaveJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Leave Cancel details", description = "Operations pertaining to Leave cancel details")
public class ApplicationController {

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	@Autowired
	private LeaveCancelRepo leaveCancelRepo;

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "cancel a list of leave request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully cancel list of leave request"),
			@ApiResponse(code = 201, message = "Successfully cancel list of regularize request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<CancelLeaveJson> cancelLeaveRequest(@NotNull @RequestHeader("userId") String userId,
			@RequestBody List<CancelLeave> inputList) throws ClientException {
		logger.info("ApplicationController.cancelLeaveRequest()");
		return leaveCancelRepo.processPostResponse(userId, inputList);
	}
	
	@RequestMapping(value = "/test", method = RequestMethod.DELETE, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "cancel a list of leave request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully cancel list of leave request"),
			@ApiResponse(code = 201, message = "Successfully cancel list of regularize request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<CancelLeaveJson> cancelTestLeaveRequest(@NotNull @RequestHeader("userId") String userId,
			@RequestBody List<CancelLeave> inputList) throws ClientException {
		logger.info("ApplicationController.cancelTestLeaveRequest()");
		return leaveCancelRepo.processPostResponse(userId, inputList);
	}

}