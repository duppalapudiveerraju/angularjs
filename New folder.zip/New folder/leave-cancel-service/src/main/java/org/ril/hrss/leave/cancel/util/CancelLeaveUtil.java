package org.ril.hrss.leave.cancel.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.ril.hrss.leave.cancel.client.SapEndpointClient;
import org.ril.hrss.leave.cancel.model.CancelLeave;
import org.ril.hrss.leave.cancel.model.CancelLeaveJson;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.ril.hrss.msf.util.SAPErrorHandlerUtil;
import org.ril.hrss.msf.util.enumeration.SAPGenericError;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.client.ClientException;

@Component
public class CancelLeaveUtil {

	protected static final Logger logger = Logger.getLogger(CancelLeaveUtil.class.getName());

	@Autowired
	private SAPErrorHandlerUtil sapErrorHandlerUtil;

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public CancelLeaveUtil() {
		super();
	}

	public List<CancelLeaveJson> processPostResponse(String userId, List<CancelLeave> inputList,
			SapEndpointClient sapEndpointClient) throws ClientException {
		logger.info("CancelLeaveUtil.processPostResponse()");
		List<CancelLeaveJson> result = new ArrayList<CancelLeaveJson>();
		for (CancelLeave obj : inputList) {
			try {
				Map<String, String> map = sapEndpointClient.cancelLeaveRequest(userId, obj.getRequestId(),
						obj.getLeaveMode(),
						getObjectMapper().writeValueAsString(obj.getLeaveStartDate())
								.replaceAll(HRSSConstantUtil.REGEX_REMOVE_QUOTES, HRSSConstantUtil.EMPTY_STRING),
						getObjectMapper().writeValueAsString(obj.getLeaveEndDate())
								.replaceAll(HRSSConstantUtil.REGEX_REMOVE_QUOTES, HRSSConstantUtil.EMPTY_STRING));
				obj.setRequestStatus(map.get(HRSSConstantUtil.POST_RESPONSE_STATUS));
				obj.setRequestErrMsg(sapErrorHandlerUtil.setCustomErrMsg(map, SAPGenericError.APPLY_LEAVE));
				obj.setSystemErrMsg(map.get(HRSSConstantUtil.POST_RESPONSE_SYSTEM_ERR_MSG));
				CancelLeaveJson resultObj = new CancelLeaveJson();
				BeanUtils.copyProperties(obj, resultObj);
				result.add(resultObj);
			} catch (JsonProcessingException e) {
				logger.info(e.getMessage());
			}
		}
		return result;
	}

	private ObjectMapper getObjectMapper() {
		logger.info("CancelLeaveUtil.getObjectMapper()");
		ObjectMapper objectMapper = objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		objectMapper.setDateFormat(df);
		return objectMapper;
	}

}