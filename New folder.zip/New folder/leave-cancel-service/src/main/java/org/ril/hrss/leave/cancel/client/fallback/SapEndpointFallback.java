package org.ril.hrss.leave.cancel.client.fallback;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.leave.cancel.client.SapEndpointClient;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public Map<String, String> cancelLeaveRequest(String userId, String requestId, String mode, String startDate,
			String endDate) {
		return new HashMap<String, String>();
	}

}