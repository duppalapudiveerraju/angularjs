package org.ril.hrss.leave.cancel.service;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.leave.cancel.client.SapEndpointClient;
import org.ril.hrss.leave.cancel.interfaces.LeaveCancelRepo;
import org.ril.hrss.leave.cancel.model.CancelLeave;
import org.ril.hrss.leave.cancel.model.CancelLeaveJson;
import org.ril.hrss.leave.cancel.util.CancelLeaveUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.netflix.client.ClientException;

@Component
public class LeaveCancelService implements LeaveCancelRepo {
	
	protected static final Logger logger = Logger.getLogger(LeaveCancelService.class.getName());
	
	@Autowired
	private SapEndpointClient sapEndpointClient;
	
	@Autowired
	private CancelLeaveUtil cancelLeaveUtil;
	
	public LeaveCancelService() {
		super();
	}

	@Override
	public List<CancelLeaveJson> processPostResponse(String userId, List<CancelLeave> inputList)
			throws ClientException {
		logger.info("LeaveCancelService.processPostResponse()");
		return cancelLeaveUtil.processPostResponse(userId, inputList, sapEndpointClient);
	}

}