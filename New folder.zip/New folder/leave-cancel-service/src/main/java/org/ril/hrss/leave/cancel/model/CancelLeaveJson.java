package org.ril.hrss.leave.cancel.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CancelLeaveJson {

	private String requestId;
	private String leaveMode;
	private Date leaveStartDate;
	private Date leaveEndDate;
	private String requestStatus;
	private String requestErrMsg;
	private String systemErrMsg;

	public CancelLeaveJson() {
		super();
	}

	public CancelLeaveJson(String requestId, String leaveMode, Date leaveStartDate, Date leaveEndDate,
			String requestStatus, String requestErrMsg, String systemErrMsg) {
		this();
		this.requestId = requestId;
		this.leaveMode = leaveMode;
		this.leaveStartDate = leaveStartDate;
		this.leaveEndDate = leaveEndDate;
		this.requestStatus = requestStatus;
		this.requestErrMsg = requestErrMsg;
		this.setSystemErrMsg(systemErrMsg);
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getLeaveMode() {
		return leaveMode;
	}

	public void setLeaveMode(String leaveMode) {
		this.leaveMode = leaveMode;
	}

	public Date getLeaveStartDate() {
		return leaveStartDate;
	}

	public void setLeaveStartDate(Date leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}

	public Date getLeaveEndDate() {
		return leaveEndDate;
	}

	public void setLeaveEndDate(Date leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public String getSystemErrMsg() {
		return systemErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public void setSystemErrMsg(String systemErrMsg) {
		this.systemErrMsg = systemErrMsg;
	}

	@Override
	public String toString() {
		return "CancelLeaveJson [requestId=" + requestId + ", leaveMode=" + leaveMode + ", leaveStartDate="
				+ leaveStartDate + ", leaveEndDate=" + leaveEndDate + ", requestStatus=" + requestStatus
				+ ", requestErrMsg=" + requestErrMsg + ", systemErrMsg=" + systemErrMsg + "]";
	}

}