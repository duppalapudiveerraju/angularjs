package org.ril.hrss.leave.cancel.client;

import java.util.Map;

import javax.validation.constraints.NotNull;

import org.ril.hrss.leave.cancel.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.DELETE, value = "/sap/leave/cancel", produces = "application/json", consumes = "application/json")
	Map<String, String> cancelLeaveRequest(@NotNull @RequestHeader("userId") String userId,
			@NotNull @RequestHeader("requestId") String requestId,
			@NotNull @RequestHeader("mode") String mode,
			@NotNull @RequestHeader("startDate") String startDate,
			@NotNull @RequestHeader("endDate") String endDate);

}