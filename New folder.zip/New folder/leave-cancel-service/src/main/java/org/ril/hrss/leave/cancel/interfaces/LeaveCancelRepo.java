package org.ril.hrss.leave.cancel.interfaces;

import java.util.List;

import org.ril.hrss.leave.cancel.model.CancelLeave;
import org.ril.hrss.leave.cancel.model.CancelLeaveJson;

import com.netflix.client.ClientException;

public interface LeaveCancelRepo {

	public List<CancelLeaveJson> processPostResponse(String userId, List<CancelLeave> inputList) throws ClientException;

}