package org.ril.hrss.app.history.repository;

import org.ril.hrss.app.history.model.ApplicationInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface ApplicationInfoRepository extends CrudRepository<ApplicationInfo, Long> {

	@Query("SELECT a FROM ApplicationInfo a WHERE a.appName=:appName")
	ApplicationInfo getApplicationInfoByAppName(@Param("appName") String appName);
	
}