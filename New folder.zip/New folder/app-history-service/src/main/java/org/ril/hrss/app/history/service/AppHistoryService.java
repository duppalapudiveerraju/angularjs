package org.ril.hrss.app.history.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.app.history.client.AppClient;
import org.ril.hrss.app.history.interfaces.AppHistoryServiceRepo;
import org.ril.hrss.app.history.model.App;
import org.ril.hrss.app.history.model.AppHistory;
import org.ril.hrss.app.history.model.ApplicationData;
import org.ril.hrss.app.history.model.ApplicationInfo;
import org.ril.hrss.app.history.repository.AppHistoryRepository;
import org.ril.hrss.app.history.repository.ApplicationInfoRepository;
import org.ril.hrss.app.history.util.AppHistoryUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AppHistoryService implements AppHistoryServiceRepo {

	protected static final Logger logger = Logger.getLogger(AppHistoryService.class.getName());

	@Autowired
	private AppHistoryRepository appHistoryRepo;

	@Autowired
	private ApplicationInfoRepository applicationInfoRepo;

	@Autowired
	private AppHistoryUtil appHistoryUtil;
	
	@Autowired
	private AppClient appClient;

	public AppHistoryService() {
		super();
	}

	@Override
	public ResponseEntity<List<ApplicationData>> getAppHistoryUserInfo(String userId, Integer size) {
		logger.info("AppHistoryService.getAppHistoryUserInfo()");
		List<ApplicationData> appObj = appHistoryUtil
				.getAppInfoList(userId, appHistoryRepo.fetchAppHistoryByUserId(userId, size), appClient);
		if (appObj != null) {
			return new ResponseEntity<List<ApplicationData>>(appObj, HttpStatus.OK);
		} else {
			return new ResponseEntity<List<ApplicationData>>(new ArrayList<>(), HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	@Transactional
	public ResponseEntity<App> saveAppHistoryUserInfo(App input, String userId) {
		logger.info("AppHistoryService.saveAppHistoryUserInfo()");
		AppHistory saveObj = new AppHistory();
		BeanUtils.copyProperties(input, saveObj);
		saveObj.setUserId(userId);
		ApplicationInfo appInfo = applicationInfoRepo.getApplicationInfoByAppName(input.getAppName());
		if (appInfo != null) {
			saveObj.setAppId(appInfo.getId());
			saveObj.setAppName(appInfo.getAppName());
			appHistoryRepo.save(saveObj);
			return new ResponseEntity<>(input, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(input, HttpStatus.BAD_REQUEST);
		}
	}

}