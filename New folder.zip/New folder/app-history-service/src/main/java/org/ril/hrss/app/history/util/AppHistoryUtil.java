package org.ril.hrss.app.history.util;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.app.history.client.AppClient;
import org.ril.hrss.app.history.model.AppHistory;
import org.ril.hrss.app.history.model.ApplicationData;
import org.springframework.stereotype.Component;

@Component
public class AppHistoryUtil {

	protected static final Logger logger = Logger.getLogger(AppHistoryUtil.class.getName());

	public AppHistoryUtil() {
		super();
	}

	public List<ApplicationData> getAppInfoList(String userId, List<AppHistory> appHistoryList, AppClient appClient) {
		logger.info("AppHistoryUtil.getAppInfoList()");
		List<ApplicationData> appDataList = new ArrayList<>();
		appHistoryList.stream().forEach(e -> {
			appDataList.add(appClient.getAppDetailsByAppName(userId, e.getAppName()).getBody());
		});
		return appDataList;
	}

}