package org.ril.hrss.app.history.model;

public class ApplicationData {

	private String appName;
	private boolean forManager;
	private boolean isBookmark;
	private Double appRating;
	private Double appNoOfVotes;

	public ApplicationData() {
		super();
	}

	public ApplicationData(String appName, boolean forManager, boolean isBookmark, Double appRating,
			Double appNoOfVotes) {
		super();
		this.appName = appName;
		this.forManager = forManager;
		this.isBookmark = isBookmark;
		this.appRating = appRating;
		this.appNoOfVotes = appNoOfVotes;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public boolean isForManager() {
		return forManager;
	}

	public void setForManager(boolean forManager) {
		this.forManager = forManager;
	}

	public boolean isBookmark() {
		return isBookmark;
	}

	public void setBookmark(boolean isBookmark) {
		this.isBookmark = isBookmark;
	}

	public Double getAppRating() {
		return appRating;
	}

	public void setAppRating(Double appRating) {
		this.appRating = appRating;
	}

	public Double getAppNoOfVotes() {
		return appNoOfVotes;
	}

	public void setAppNoOfVotes(Double appNoOfVotes) {
		this.appNoOfVotes = appNoOfVotes;
	}

	@Override
	public String toString() {
		return "ApplicationData [appName=" + appName + ", forManager=" + forManager + ", isBookmark=" + isBookmark
				+ ", appRating=" + appRating + ", appNoOfVotes=" + appNoOfVotes + "]";
	}

}