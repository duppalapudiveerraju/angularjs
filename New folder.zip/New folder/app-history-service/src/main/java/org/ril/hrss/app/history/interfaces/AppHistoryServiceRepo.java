package org.ril.hrss.app.history.interfaces;

import java.util.List;

import org.ril.hrss.app.history.model.App;
import org.ril.hrss.app.history.model.ApplicationData;
import org.springframework.http.ResponseEntity;

public interface AppHistoryServiceRepo {

	public ResponseEntity<List<ApplicationData>> getAppHistoryUserInfo(String userId, Integer limit);

	public ResponseEntity<App> saveAppHistoryUserInfo(App input, String userId);

}