package org.ril.hrss.app.history.client;

import javax.validation.constraints.NotNull;

import org.ril.hrss.app.history.model.ApplicationData;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "app-service", fallback = AppClient.class)
public interface AppClient {
	
	@RequestMapping(value = "/details/{appName}", method = RequestMethod.GET, produces = "application/json")
	ResponseEntity<ApplicationData> getAppDetailsByAppName(@NotNull @RequestHeader("userId") String userId,
			@NotNull @PathVariable("appName") String appName);

}