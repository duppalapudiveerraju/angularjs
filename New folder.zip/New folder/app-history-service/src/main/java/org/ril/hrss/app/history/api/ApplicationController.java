package org.ril.hrss.app.history.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.app.history.interfaces.AppHistoryServiceRepo;
import org.ril.hrss.app.history.model.App;
import org.ril.hrss.app.history.model.ApplicationData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "App History details", description = "Operations pertaining to app history details")
public class ApplicationController {

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	@Autowired
	private AppHistoryServiceRepo appHistoryServiceRepo;

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/details/{limit}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get app history request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Get App History Detail"),
			@ApiResponse(code = 201, message = "Successfully saved"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<List<ApplicationData>> getAppHistoryInfo(@NotNull @RequestHeader("userId") String userId,
			@NotNull @PathVariable("limit") Integer limit) {
		logger.info("app-history-service.getAppHistoryInfo()");
		return appHistoryServiceRepo.getAppHistoryUserInfo(userId, limit);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save app history request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully saved"),
			@ApiResponse(code = 201, message = "Successfully saved"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<App> saveAppHistoryRequest(@NotNull @RequestHeader("userId") String userId,
			@Validated @RequestBody App input) {
		logger.info("app-history-service.saveAppHistoryRequest()");
		return appHistoryServiceRepo.saveAppHistoryUserInfo(input, userId);
	}
}