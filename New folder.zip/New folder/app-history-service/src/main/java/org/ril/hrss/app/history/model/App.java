package org.ril.hrss.app.history.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class App {

	@NotNull(message = "The AppName is a required field")
	@Size(min = 3, max = 50, message = "The AppName should be between 3 and 50 characters")
	private String appName;

	public App() {
		super();
	}

	public App(String appName) {
		this();
		this.appName = appName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Override
	public String toString() {
		return "App [appName=" + appName + "]";
	}

}