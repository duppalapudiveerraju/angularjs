package org.ril.hrss.app.history.repository;

import java.util.List;

import org.ril.hrss.app.history.model.AppHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface AppHistoryRepository extends CrudRepository<AppHistory, Long> {

	@Query(value = "SELECT a.* FROM  hrss_app_db.app_history a INNER JOIN ( SELECT Distinct(Max(created_on)) created_on, app_name FROM hrss_app_db.app_history where user_id = :userId GROUP BY app_name) AS b ON a.app_name = b.app_name AND a.created_on = b.created_on ORDER BY a.created_on DESC limit :size", nativeQuery = true)
	List<AppHistory> fetchAppHistoryByUserId(@Param("userId") String userId, @Param("size") Integer size);

}