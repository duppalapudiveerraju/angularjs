package org.ril.hrss.app.history.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "app_history")
public class AppHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer id;

	private Integer appId;

	private String appName;

	private String userId;

	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;

	public AppHistory() {
		super();
	}

	public AppHistory(Integer id, Integer appId, String appName, String userId, Date createdOn) {
		this();
		this.id = id;
		this.appId = appId;
		this.appName = appName;
		this.userId = userId;
		this.createdOn = createdOn;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Override
	public String toString() {
		return "AppHistory [id=" + id + ", appId=" + appId + ", appName=" + appName + ", userId=" + userId
				+ ", createdOn=" + createdOn + "]";
	}

}
