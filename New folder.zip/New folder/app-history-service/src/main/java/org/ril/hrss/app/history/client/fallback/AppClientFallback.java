package org.ril.hrss.app.history.client.fallback;

import org.ril.hrss.app.history.client.AppClient;
import org.ril.hrss.app.history.model.ApplicationData;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AppClientFallback implements AppClient {

	@Override
	public ResponseEntity<ApplicationData> getAppDetailsByAppName(String userId, String appName) {
		return new ResponseEntity<ApplicationData>(new ApplicationData(), HttpStatus.OK);
	}

}