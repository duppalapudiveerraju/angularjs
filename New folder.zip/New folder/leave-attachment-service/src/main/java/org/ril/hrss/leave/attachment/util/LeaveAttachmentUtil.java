package org.ril.hrss.leave.attachment.util;

import java.util.logging.Logger;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class LeaveAttachmentUtil {

	protected static final Logger logger = Logger.getLogger(LeaveAttachmentUtil.class.getName());

	public LeaveAttachmentUtil() {
		super();
	}

	public ResponseEntity<ByteArrayResource> getDocFromResourceStream(ByteArrayResource resource) {
		logger.info("LeaveAttachmentUtil.getDocFromResourceStream()");
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION,
						HRSSConstantUtil.HTTP_HEADER_FILE_ATTACHMENT + HRSSConstantUtil.SEMI_COLON
								+ HRSSConstantUtil.HTTP_HEADER_FILE_NAME + HRSSConstantUtil.STRING_EQUAL
								+ resource.getFilename())
				.contentType(MediaType.APPLICATION_PDF).contentLength(resource.contentLength()).body(resource);
	}

}