package org.ril.hrss.leave.attachment.client;

import javax.validation.constraints.NotNull;

import org.ril.hrss.leave.attachment.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.POST, value = "/sap/leave/attachment/fetch/{attachDocId}", produces = "application/json")
	ResponseEntity<ByteArrayResource> fetchLeaveAttachmentRequest(@NotNull @RequestHeader("userId") String userId,
			@NotNull @PathVariable("attachDocId") String attachDocId);

}