package org.ril.hrss.leave.attachment.client.fallback;

import org.ril.hrss.leave.attachment.client.SapEndpointClient;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public ResponseEntity<ByteArrayResource> fetchLeaveAttachmentRequest(String userId, String attachDocId) {
		return new ResponseEntity<ByteArrayResource>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

}