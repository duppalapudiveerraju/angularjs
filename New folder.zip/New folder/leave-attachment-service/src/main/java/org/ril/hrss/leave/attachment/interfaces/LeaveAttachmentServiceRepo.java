package org.ril.hrss.leave.attachment.interfaces;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

public interface LeaveAttachmentServiceRepo {

	public ResponseEntity<ByteArrayResource> fetchLeaveAttachment(String userId, String attachDocId);

}