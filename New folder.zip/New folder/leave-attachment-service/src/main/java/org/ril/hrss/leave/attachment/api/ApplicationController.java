package org.ril.hrss.leave.attachment.api;

import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.leave.attachment.interfaces.LeaveAttachmentServiceRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Fetch Leave Attachment", description = "Operations pertaining to fetch leave attachment")
public class ApplicationController {

	@Autowired
	private LeaveAttachmentServiceRepo leaveAttachmentServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/fetch/{attachDocId}", method = RequestMethod.GET)
	@ApiOperation(value = "Fetch leave attachment", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully fetch leave attachment"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<ByteArrayResource> fetchLeaveAttachment(@NotNull @RequestHeader("userId") String userId,
			@NotNull @PathVariable("attachDocId") String attachDocId) throws ClientException {
		logger.info("ApplicationController.fetchLeaveAttachment()");
		return leaveAttachmentServiceRepo.fetchLeaveAttachment(userId, attachDocId);
	}

}