package org.ril.hrss.leave.attachment.service;

import java.util.logging.Logger;

import org.ril.hrss.leave.attachment.client.SapEndpointClient;
import org.ril.hrss.leave.attachment.interfaces.LeaveAttachmentServiceRepo;
import org.ril.hrss.leave.attachment.util.LeaveAttachmentUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class LeaveAttachmentService implements LeaveAttachmentServiceRepo {

	protected static final Logger logger = Logger.getLogger(LeaveAttachmentService.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private LeaveAttachmentUtil leaveAttachmentUtil;

	public LeaveAttachmentService() {
		super();
	}

	@Override
	public ResponseEntity<ByteArrayResource> fetchLeaveAttachment(String userId, String attachDocId) {
		logger.info("LeaveAttachmentService.fetchLeaveAttachment()");
		return leaveAttachmentUtil
				.getDocFromResourceStream(sapEndpointClient.fetchLeaveAttachmentRequest(userId, attachDocId).getBody());
	}

}