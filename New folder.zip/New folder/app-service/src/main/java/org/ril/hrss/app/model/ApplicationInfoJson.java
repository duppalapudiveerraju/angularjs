package org.ril.hrss.app.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class ApplicationInfoJson {

	@NotNull
	@Size(min = 3, max = 50, message = "The AppName should be between 3 and 50 characters")
	private String appName;
	
	private String appDesc;
	
	@NotNull
	private boolean forManager;

	public ApplicationInfoJson() {
		super();
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppDesc() {
		return appDesc;
	}

	public void setAppDesc(String appDesc) {
		this.appDesc = appDesc;
	}

	public boolean isForManager() {
		return forManager;
	}

	public void setForManager(boolean forManager) {
		this.forManager = forManager;
	}

	@Override
	public String toString() {
		return "ApplicationInfoJson [appName=" + appName + ", appDesc=" + appDesc + ", forManager=" + forManager + "]";
	}

}