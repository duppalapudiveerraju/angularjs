package org.ril.hrss.app.client.fallback;

import java.util.ArrayList;
import java.util.List;

import org.ril.hrss.app.client.BookmarkClient;
import org.ril.hrss.app.model.BookmarkApp;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class BookmarkClientFallback implements BookmarkClient {

	@Override
	public ResponseEntity<List<BookmarkApp>> getBookmarkInfo(String userId) {
		return new ResponseEntity<List<BookmarkApp>>(new ArrayList<>(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<BookmarkApp> getBookmarkInfoByAppName(String appName, String userId) {
		return new ResponseEntity<BookmarkApp>(new BookmarkApp(), HttpStatus.OK);
	}

}