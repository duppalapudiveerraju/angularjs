package org.ril.hrss.app.client.fallback;

import org.ril.hrss.app.client.UserInfoClient;

public class UserInfoFallback implements UserInfoClient {

	@Override
	public Boolean getIsManager(String userId) {
		return Boolean.TRUE;
	}

}