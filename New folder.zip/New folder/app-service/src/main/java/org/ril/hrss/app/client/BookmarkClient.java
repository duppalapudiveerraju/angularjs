package org.ril.hrss.app.client;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.ril.hrss.app.client.fallback.BookmarkClientFallback;
import org.ril.hrss.app.model.BookmarkApp;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "bookmark-service", fallback = BookmarkClientFallback.class)
public interface BookmarkClient {
	
	@RequestMapping(value = "/details/{userId}", method = RequestMethod.GET, produces = "application/json")
	ResponseEntity<List<BookmarkApp>> getBookmarkInfo(@PathVariable("userId") String userId);
	
	@RequestMapping(value = "/details/info/{appName}", method = RequestMethod.GET, produces = "application/json")
	ResponseEntity<BookmarkApp> getBookmarkInfoByAppName(@PathVariable("appName") String appName,
			@NotNull @RequestHeader("userId") String userId);

}