package org.ril.hrss.app.client;

import javax.validation.constraints.NotNull;

import org.ril.hrss.app.client.fallback.UserInfoFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "user-info-service", fallback = UserInfoFallback.class)
public interface UserInfoClient {
	
	@RequestMapping(value = "/isManager", method = RequestMethod.GET, produces = "application/json")
	Boolean getIsManager(@NotNull @RequestHeader("userId") String userId);

}