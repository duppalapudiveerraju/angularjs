package org.ril.hrss.app.model;

public class BookmarkApp {

	private String appName;

	public BookmarkApp() {
		super();
	}

	public BookmarkApp(String appName) {
		super();
		this.setAppName(appName);
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Override
	public String toString() {
		return "BookmarkApp [appName=" + appName + "]";
	}
	
}