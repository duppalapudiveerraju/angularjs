package org.ril.hrss.app.client;

import java.util.List;

import org.ril.hrss.app.client.fallback.FeedbackClientFallback;
import org.ril.hrss.app.model.Feedback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "feedback-service", fallback = FeedbackClientFallback.class)
public interface FeedbackClient {

	@RequestMapping(value = "/feedback/details/appName/{appName}/userId/{userId}", method = RequestMethod.GET, produces = "application/json")
	ResponseEntity<Feedback> getFeedbackInfo(@PathVariable("userId") String userId,
			@PathVariable("appName") String appName);

	@RequestMapping(value = "/feedback/findAll", method = RequestMethod.GET, produces = "application/json")
	ResponseEntity<List<Feedback>> getAllFeedbackInfo();

}