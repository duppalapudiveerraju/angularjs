package org.ril.hrss.app.client.fallback;

import java.util.ArrayList;
import java.util.List;

import org.ril.hrss.app.client.FeedbackClient;
import org.ril.hrss.app.model.Feedback;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class FeedbackClientFallback implements FeedbackClient {

	@Override
	public ResponseEntity<List<Feedback>> getAllFeedbackInfo() {
		return new ResponseEntity<List<Feedback>>(new ArrayList<>(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Feedback> getFeedbackInfo(String userId, String appName) {
		return new ResponseEntity<Feedback>(new Feedback(), HttpStatus.OK);
	}

}