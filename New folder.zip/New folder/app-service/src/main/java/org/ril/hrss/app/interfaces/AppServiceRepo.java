package org.ril.hrss.app.interfaces;

import java.util.List;

import org.ril.hrss.app.model.ApplicationData;
import org.ril.hrss.app.model.ApplicationInfoJson;
import org.springframework.http.ResponseEntity;

import com.netflix.client.ClientException;

import feign.FeignException;

public interface AppServiceRepo {
	
	public ResponseEntity<List<ApplicationData>> getAppDetails(String userId) throws ClientException, FeignException;
	
	public ResponseEntity<ApplicationInfoJson> saveOrUpdateAppInfo(ApplicationInfoJson appInfo);

	public ResponseEntity<ApplicationData> getAppDetailsByAppName(String userId, String appName);

}