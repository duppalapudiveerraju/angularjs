package org.ril.hrss.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "app_master")
public class ApplicationInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotNull(message = "The AppName is a required field")
	@Size(min = 3, max = 50, message = "The AppName should be between 3 and 50 characters")
	@Column(unique = true)
	private String appName;

	private String appDesc;

	@NotNull
	private boolean forManager;

	public ApplicationInfo() {
		super();
	}

	public ApplicationInfo(Integer id, String appName, String appDesc, boolean forManager) {
		super();
		this.id = id;
		this.appName = appName;
		this.setAppDesc(appDesc);
		this.forManager = forManager;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppDesc() {
		return appDesc;
	}

	public void setAppDesc(String appDesc) {
		this.appDesc = appDesc;
	}

	public boolean isForManager() {
		return forManager;
	}

	public void setForManager(boolean forManager) {
		this.forManager = forManager;
	}

	@Override
	public String toString() {
		return "ApplicationInfo [id=" + id + ", appName=" + appName + ", appDesc=" + appDesc + ", forManager="
				+ forManager + "]";
	}

}