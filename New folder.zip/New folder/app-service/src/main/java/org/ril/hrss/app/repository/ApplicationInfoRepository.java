package org.ril.hrss.app.repository;

import java.util.List;

import org.ril.hrss.app.model.ApplicationInfo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface ApplicationInfoRepository extends CrudRepository<ApplicationInfo, Long> {
	
	@Query("SELECT a FROM ApplicationInfo a")
	List<ApplicationInfo> getApplicationInfo();

	@Query("SELECT a FROM ApplicationInfo a WHERE a.appName=:appName")
	ApplicationInfo getApplicationInfoByAppName(@Param("appName") String appName);

}