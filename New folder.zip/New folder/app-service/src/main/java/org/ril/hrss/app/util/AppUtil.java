package org.ril.hrss.app.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.app.model.ApplicationData;
import org.ril.hrss.app.model.ApplicationInfo;
import org.ril.hrss.app.model.BookmarkApp;
import org.ril.hrss.app.model.Feedback;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

@Component
public class AppUtil {

	protected static final Logger logger = Logger.getLogger(AppUtil.class.getName());

	public AppUtil() {
		super();
	}

	public List<ApplicationData> getApplicationData(String userId, List<ApplicationInfo> applicationInfo,
			List<Feedback> feedbackList, List<String> bookmarkList, boolean isManager) {
		logger.info("AppUtil.getApplicationData()");
		List<ApplicationData> appDataList = new ArrayList<>();
		applicationInfo.stream().forEach(e -> {
			ApplicationData appData = new ApplicationData();
			BeanUtils.copyProperties(e, appData);
			BeanUtils.copyProperties(findFeedbackObjInList(e.getAppName(), feedbackList), appData);
			appData.setBookmark(bookmarkList.contains(e.getAppName()) ? Boolean.TRUE : Boolean.FALSE);
			appDataList.add(appData);
		});
		return filterManagerApp(isManager, appDataList);
	}

	private List<ApplicationData> filterManagerApp(boolean isManager, List<ApplicationData> appDataList) {
		logger.info("AppUtil.filterManagerApp()");
		if (!isManager) {
			return appDataList.parallelStream().filter(e -> !e.isForManager()).collect(Collectors.toList());
		}
		return appDataList;
	}

	private Feedback findFeedbackObjInList(String appName, List<Feedback> feedbackList) {
		logger.info("AppUtil.findFeedbackObjInList()");
		Optional<Feedback> feedbackOpt = feedbackList.parallelStream().filter(e -> e.getAppName().equals(appName))
				.findFirst();
		return feedbackOpt.isPresent() ? feedbackOpt.get()
				: new Feedback(appName, HRSSConstantUtil.ZERO, HRSSConstantUtil.ZERO);
	}

	public ApplicationData getAppInfoByAppName(String userId, ApplicationInfo applicationInfo, Feedback feedbackInfo,
			BookmarkApp bookmarkInfo) {
		logger.info("AppUtil.getAppInfoByAppName()");
		ApplicationData appData = new ApplicationData();
		BeanUtils.copyProperties(applicationInfo, appData);
		BeanUtils.copyProperties(feedbackInfo, appData);
		appData.setBookmark(bookmarkInfo != null ? Boolean.TRUE : Boolean.FALSE);
		return appData;
	}

}