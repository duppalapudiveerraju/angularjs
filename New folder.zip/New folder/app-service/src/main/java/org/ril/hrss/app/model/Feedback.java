package org.ril.hrss.app.model;

public class Feedback {

	private String appName;
	private Double appNoOfVotes;
	private Double appRating;

	public Feedback() {
		super();
	}

	public Feedback(String appName, Double appNoOfVotes, Double appRating) {
		super();
		this.appName = appName;
		this.appNoOfVotes = appNoOfVotes;
		this.appRating = appRating;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public Double getAppRating() {
		return appRating;
	}

	public void setAppRating(Double appRating) {
		this.appRating = appRating;
	}

	public Double getAppNoOfVotes() {
		return appNoOfVotes;
	}

	public void setAppNoOfVotes(Double appNoOfVotes) {
		this.appNoOfVotes = appNoOfVotes;
	}

	@Override
	public String toString() {
		return "Feedback [appName=" + appName + ", appNoOfVotes=" + appNoOfVotes + ", appRating=" + appRating + "]";
	}

}