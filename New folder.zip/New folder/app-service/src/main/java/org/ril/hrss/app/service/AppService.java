package org.ril.hrss.app.service;

import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.ril.hrss.app.client.BookmarkClient;
import org.ril.hrss.app.client.FeedbackClient;
import org.ril.hrss.app.client.UserInfoClient;
import org.ril.hrss.app.interfaces.AppServiceRepo;
import org.ril.hrss.app.model.ApplicationData;
import org.ril.hrss.app.model.ApplicationInfo;
import org.ril.hrss.app.model.ApplicationInfoJson;
import org.ril.hrss.app.model.BookmarkApp;
import org.ril.hrss.app.repository.ApplicationInfoRepository;
import org.ril.hrss.app.util.AppUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.netflix.client.ClientException;

import feign.FeignException;

@Service
public class AppService implements AppServiceRepo {

	protected static final Logger logger = Logger.getLogger(AppService.class.getName());

	@Autowired
	private ApplicationInfoRepository applicationInfoRepo;

	@Autowired
	private AppUtil appUtil;

	@Autowired
	private FeedbackClient feedbackClient;

	@Autowired
	private BookmarkClient bookmarkClient;

	@Autowired
	private UserInfoClient userInfoClient;

	public AppService() {
		super();
	}

	@Override
	public ResponseEntity<List<ApplicationData>> getAppDetails(String userId) throws ClientException, FeignException {
		logger.info("AppService.getAppDetails()");
		return new ResponseEntity<List<ApplicationData>>(
				appUtil.getApplicationData(userId, applicationInfoRepo.getApplicationInfo(),
						feedbackClient.getAllFeedbackInfo().getBody(),
						bookmarkClient.getBookmarkInfo(userId).getBody().parallelStream().map(BookmarkApp::getAppName)
								.collect(Collectors.toList()),
						userInfoClient.getIsManager(userId)),
				HttpStatus.OK);
	}

	@Override
	@Transactional
	public ResponseEntity<ApplicationInfoJson> saveOrUpdateAppInfo(ApplicationInfoJson appInfoJson) {
		logger.info("AppService.saveOrUpdateAppInfo()");
		ApplicationInfo appInfo = applicationInfoRepo.getApplicationInfoByAppName(appInfoJson.getAppName());
		if (appInfo == null) {
			appInfo = new ApplicationInfo();
		}
		BeanUtils.copyProperties(appInfoJson, appInfo);
		applicationInfoRepo.save(appInfo);
		return new ResponseEntity<ApplicationInfoJson>(appInfoJson, HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<ApplicationData> getAppDetailsByAppName(String userId, String appName) {
		logger.info("AppService.getAppDetailsByAppName()");
		return new ResponseEntity<ApplicationData>(
				appUtil.getAppInfoByAppName(userId, applicationInfoRepo.getApplicationInfoByAppName(appName),
						feedbackClient.getFeedbackInfo(userId, appName).getBody(),
						bookmarkClient.getBookmarkInfoByAppName(appName, userId).getBody()),
				HttpStatus.OK);
	}

}