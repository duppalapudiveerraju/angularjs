package org.ril.hrss.app.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.app.interfaces.AppServiceRepo;
import org.ril.hrss.app.model.ApplicationData;
import org.ril.hrss.app.model.ApplicationInfoJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import feign.FeignException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "App details", description = "Operations pertaining to App details")
public class ApplicationController {

	@Autowired
	private AppServiceRepo appServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/details", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get App Info details", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved a App Info details"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<List<ApplicationData>> getAppDetails(@NotNull @RequestHeader("userId") String userId)
			throws FeignException, ClientException {
		logger.info("ApplicationController.getAppDetails()");
		return appServiceRepo.getAppDetails(userId);
	}

	@RequestMapping(value = "/details/{appName}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get App Info details", response = ApplicationData.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved a App Info details"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<ApplicationData> getAppDetailsByAppName(@NotNull @RequestHeader("userId") String userId,
			@NotNull @PathVariable("appName") String appName) throws FeignException, ClientException {
		logger.info("ApplicationController.getAppDetailsByAppName()");
		return appServiceRepo.getAppDetailsByAppName(userId, appName);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save App Info request", response = ApplicationInfoJson.class)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Successfully saved a App Info request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<ApplicationInfoJson> saveAppInfo(@RequestBody ApplicationInfoJson input) {
		logger.info("ApplicationController.saveAppInfo()");
		return appServiceRepo.saveOrUpdateAppInfo(input);
	}

}