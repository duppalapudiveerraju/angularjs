package org.ril.hrss.house.rent.declaration.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.SAPDateFormatSerializer;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class RentDeclarationMappinig {

	private String cityCategory;
	private Date fromDate;
	private Date toDate;
	private String actualRent;
	private String landloardname;
	private String landlordpan;
	private String landlordaddr;
	private String employeermk;
	private String reqNo;
	private String decLandLord;
	private String status;
	private String docNum;

	public RentDeclarationMappinig() {
		super();
	}

	@JsonProperty("CityCatKey")
	public String getCityCategory() {
		return cityCategory;
	}

	public void setCityCategory(String cityCategory) {
		this.cityCategory = cityCategory;
	}

	@JsonProperty("FromDate")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getFromDate() {
		return fromDate;
	}

	@JsonProperty("fromDate")
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	@JsonProperty("ToDate")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getToDate() {
		return toDate;
	}

	@JsonProperty("toDate")
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	@JsonProperty("ActRentAmt")
	public String getActualRent() {
		return actualRent;
	}

	@JsonProperty("actualRent")
	public void setActualRent(String actualRent) {
		this.actualRent = actualRent;
	}

	@JsonProperty("LandLordName")
	public String getLandloardname() {
		return landloardname;
	}

	@JsonProperty("landloardname")
	public void setLandloardname(String landloardname) {
		this.landloardname = landloardname;
	}

	@JsonProperty("PanLandLord")
	public String getLandlordpan() {
		return landlordpan;
	}

	@JsonProperty("landlordpan")
	public void setLandlordpan(String landlordpan) {
		this.landlordpan = landlordpan;
	}

	@JsonProperty("LandLordAddr")
	public String getLandlordaddr() {
		return landlordaddr;
	}

	@JsonProperty("landlordaddr")
	public void setLandlordaddr(String landlordaddr) {
		this.landlordaddr = landlordaddr;
	}

	@JsonProperty("EmpComments")
	public String getEmployeermk() {
		return employeermk;
	}

	@JsonProperty("employeermk")
	public void setEmployeermk(String employeermk) {
		this.employeermk = employeermk;
	}

	@JsonProperty("Reqno")
	public String getReqNo() {
		return reqNo;
	}

	@JsonProperty("reqNo")
	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	@JsonProperty("DecLandLord")
	public String getDecLandLord() {
		return decLandLord;
	}

	@JsonProperty("decLandLord")
	public void setDecLandLord(String decLandLord) {
		this.decLandLord = decLandLord;
	}

	@JsonProperty("ReqStatusKey")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("DocNum")
	public String getDocNum() {
		return docNum;
	}

	@JsonProperty("docNum")
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	@Override
	public String toString() {
		return "RentDeclarationMappinig [cityCategory=" + cityCategory + ", fromDate=" + fromDate + ", toDate=" + toDate
				+ ", actualRent=" + actualRent + ", landloardname=" + landloardname + ", landlordpan=" + landlordpan
				+ ", landlordaddr=" + landlordaddr + ", employeermk=" + employeermk + ", reqNo=" + reqNo
				+ ", decLandLord=" + decLandLord + ", status=" + status + ", docNum=" + docNum + "]";
	}

}