package org.ril.hrss.house.rent.declaration.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.house.rent.declaration.model.CityCategory;
import org.ril.hrss.house.rent.declaration.model.HouseRentDeclaration;
import org.ril.hrss.house.rent.declaration.model.RentDeclaration;
import org.ril.hrss.house.rent.declaration.model.RentDeclarationJson;
import org.ril.hrss.house.rent.declaration.model.RentDeclarationMappinig;
import org.ril.hrss.house.rent.declaration.util.HouseRentDecUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "HouseRentDeclaration Request", description = "Operations pertaining to HouseRentDeclaration Request")
public class ApplicationController {

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	@Autowired
	private HouseRentDecUtil houseRentDecUtil;

	@RequestMapping(value = "/declaration", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "HouseRentDeclaration", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<HouseRentDeclaration> getHouseRentDec(@NotNull @RequestHeader("userID") String userId)
			throws ClientException {
		logger.info("house-rent-declaration-service.getHouseRentDec()");
		return houseRentDecUtil.getHouseRentDecReq(userId);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save a list of House Rent Declaration request", response = ResponseEntity.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully saved list of House Rent Declaration request"),
			@ApiResponse(code = 201, message = "Successfully saved list of House Rent Declaration request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<RentDeclaration> saveHouseRentDec(@NotNull @RequestHeader("userID") String userId,
			@RequestBody RentDeclarationMappinig input) throws ClientException {
		logger.info("house-rent-declaration-service.saveHouseRentDec()");
		return houseRentDecUtil.rentDeclarationResponse(userId, input);
	}

	@RequestMapping(value = "/cityCategories", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get the list of City Categories for House Rent Declaration", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully list of House Rent Declaration request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<CityCategory> getCityCategories(@NotNull @RequestHeader("userID") String userId)
			throws ClientException {
		logger.info("house-rent-declaration-service.getCityCategories()");
		return houseRentDecUtil.getCityCategories(userId);
	}

	@RequestMapping(value = "/update/{reqNumber}", method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "update a list of House Rent Declaration request", response = ResponseEntity.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully update list of House Rent Declaration request"),
			@ApiResponse(code = 201, message = "Successfully update list of House Rent Declaration request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<RentDeclaration> updateHouseRentDec(@NotNull @RequestHeader("userID") String userId,
			@PathVariable("reqNumber") String reqNumber, @RequestBody RentDeclarationMappinig input)
			throws ClientException {
		logger.info("house-rent-declaration-service.updateHouseRentDec()");
		return houseRentDecUtil.updateRentDeclarationResponse(userId, input, reqNumber);
	}

	@RequestMapping(value = "/delete/{reqNumber}", method = RequestMethod.DELETE, produces = "application/json")
	@ApiOperation(value = "Delete a list of House Rent Declaration request", response = List.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully deleted list of  House Rent Declaration  request"),
			@ApiResponse(code = 201, message = "Successfully deleted list of House Rent Declaration  regularize request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<RentDeclarationJson> deleteHouseRentDec(@NotNull @RequestHeader("userID") String userId,
			@PathVariable("reqNumber") String reqNumber) throws ClientException {
		logger.info("house-rent-declaration-service.deleteHouseRentDec()");
		return houseRentDecUtil.deleteRentDelcarationRequest(userId, reqNumber);
	}

}