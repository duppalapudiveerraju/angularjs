package org.ril.hrss.house.rent.declaration.intercomm;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getRentDeclarationRequest(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public Map<String, String> saveRentDeclarationRequest(String userId, String rentDeclarationJSONString) {
		return new HashMap<String, String>();
	}

	@Override
	public String getCityCategories(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public Map<String, String> updateRentDeclarationRequest(String userId, String reqNumber,
			String rentDeclarationJSONString) {
		return new HashMap<String, String>();
	}

	@Override
	public Map<String, String> deleteRentDeclarationRequest(String userId, String reqNumber) {
		return new HashMap<String, String>();
	}

}