package org.ril.hrss.house.rent.declaration.model;

import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class HouseRentDeclaration {

	private String reqNo;
	private String fromDate;
	private String toDate;
	private String cityCatKey;
	private String actRentAmt;
	private String decLandLord;
	private String panLandLord;
	private String apprAmt;
	private String reqStatusKey;
	private String landLordAddr;
	private String empComments;
	private String apprComments;
	private String cityCatText;
	private String reqStatText;
	private String action;
	private String sMsg;
	private String newCreate;
	private String docNum;
	private String landLordName;

	public HouseRentDeclaration() {
		super();
	}

	@JsonProperty("Reqno")
	public String getReqNo() {
		return reqNo;
	}

	@JsonProperty("Reqno")
	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	@JsonProperty("FromDate")
	@JsonSerialize(converter = SAPStringToDateSerializer.class)
	public String getFromDate() {
		return fromDate;
	}

	@JsonProperty("FromDate")
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	@JsonProperty("ToDate")
	@JsonSerialize(converter = SAPStringToDateSerializer.class)
	public String getToDate() {
		return toDate;
	}

	@JsonProperty("ToDate")
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	@JsonProperty("CityCatKey")
	public String getCityCatKey() {
		return cityCatKey;
	}

	@JsonProperty("CityCatKey")
	public void setCityCatKey(String cityCatKey) {
		this.cityCatKey = cityCatKey;
	}

	@JsonProperty("ActRentAmt")
	public String getActRentAmt() {
		return actRentAmt;
	}

	@JsonProperty("ActRentAmt")
	public void setActRentAmt(String actRentAmt) {
		this.actRentAmt = actRentAmt;
	}

	@JsonProperty("DecLandLord")
	public String getDecLandLord() {
		return decLandLord;
	}

	@JsonProperty("DecLandLord")
	public void setDecLandLord(String decLandLord) {
		this.decLandLord = decLandLord;
	}

	public String getPanLandLord() {
		return panLandLord;
	}

	@JsonProperty("PanLandLord")
	public void setPanLandLord(String panLandLord) {
		this.panLandLord = panLandLord;
	}

	@JsonProperty("ApprAmt")
	public String getApprAmt() {
		return apprAmt;
	}

	@JsonProperty("ApprAmt")
	public void setApprAmt(String apprAmt) {
		this.apprAmt = apprAmt;
	}

	public String getReqStatusKey() {
		return reqStatusKey;
	}

	@JsonProperty("ReqStatusKey")
	public void setReqStatusKey(String reqStatusKey) {
		this.reqStatusKey = reqStatusKey;
	}

	@JsonProperty("LandLordAddr")
	public String getLandLordAddr() {
		return landLordAddr;
	}

	@JsonProperty("LandLordAddr")
	public void setLandLordAddr(String landLordAddr) {
		this.landLordAddr = landLordAddr;
	}

	public String getEmpComments() {
		return empComments;
	}

	@JsonProperty("EmpComments")
	public void setEmpComments(String empComments) {
		this.empComments = empComments;
	}

	@JsonProperty("ApprComments")
	public String getApprComments() {
		return apprComments;
	}

	@JsonProperty("ApprComments")
	public void setApprComments(String apprComments) {
		this.apprComments = apprComments;
	}

	@JsonProperty("CityCatText")
	public String getCityCatText() {
		return cityCatText;
	}

	@JsonProperty("CityCatText")
	public void setCityCatText(String cityCatText) {
		this.cityCatText = cityCatText;
	}

	@JsonProperty("ReqStatText")
	public String getReqStatText() {
		return reqStatText;
	}

	@JsonProperty("ReqStatText")
	public void setReqStatText(String reqStatText) {
		this.reqStatText = reqStatText;
	}

	@JsonProperty("Action")
	public String getAction() {
		return action;
	}

	@JsonProperty("Action")
	public void setAction(String action) {
		this.action = action;
	}

	@JsonProperty("SMsg")
	public String getsMsg() {
		return sMsg;
	}

	@JsonProperty("SMsg")
	public void setsMsg(String sMsg) {
		this.sMsg = sMsg;
	}

	@JsonProperty("NewCreate")
	public String getNewCreate() {
		return newCreate;
	}

	@JsonProperty("NewCreate")
	public void setNewCreate(String newCreate) {
		this.newCreate = newCreate;
	}

	@JsonProperty("DocNum")
	public String getDocNum() {
		return docNum;
	}

	@JsonProperty("DocNum")
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	@JsonProperty("LandLordName")
	public String getLandLordName() {
		return landLordName;
	}

	@JsonProperty("LandLordName")
	public void setLandLordName(String landLordName) {
		this.landLordName = landLordName;
	}

	@Override
	public String toString() {
		return "HouseRentDeclaration [reqNo=" + reqNo + ", fromDate=" + fromDate + ", toDate=" + toDate
				+ ", cityCatKey=" + cityCatKey + ", actRentAmt=" + actRentAmt + ", decLandLord=" + decLandLord
				+ ", panLandLord=" + panLandLord + ", apprAmt=" + apprAmt + ", reqStatusKey=" + reqStatusKey
				+ ", landLordAddr=" + landLordAddr + ", empComments=" + empComments + ", apprComments=" + apprComments
				+ ", cityCatText=" + cityCatText + ", reqStatText=" + reqStatText + ", action=" + action + ", sMsg="
				+ sMsg + ", newCreate=" + newCreate + ", docNum=" + docNum + ", landLordName=" + landLordName
				+ ", getReqNo()=" + getReqNo() + ", getFromDate()=" + getFromDate() + ", getToDate()=" + getToDate()
				+ ", getCityCatKey()=" + getCityCatKey() + ", getActRentAmt()=" + getActRentAmt()
				+ ", getDecLandLord()=" + getDecLandLord() + ", getPanLandLord()=" + getPanLandLord()
				+ ", getApprAmt()=" + getApprAmt() + ", getReqStatusKey()=" + getReqStatusKey() + ", getLandLordAddr()="
				+ getLandLordAddr() + ", getEmpComments()=" + getEmpComments() + ", getApprComments()="
				+ getApprComments() + ", getCityCatText()=" + getCityCatText() + ", getReqStatText()="
				+ getReqStatText() + ", getAction()=" + getAction() + ", getsMsg()=" + getsMsg() + ", getNewCreate()="
				+ getNewCreate() + ", getDocNum()=" + getDocNum() + ", getLandLordName()=" + getLandLordName()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

}
