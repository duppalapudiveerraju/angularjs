package org.ril.hrss.house.rent.declaration.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CityCategory {

	private String cityKey;
	private String cityText;

	public CityCategory() {
		super();
	}

	public String getCityKey() {
		return cityKey;
	}

	@JsonProperty("CityKey")
	public void setCityKey(String cityKey) {
		this.cityKey = cityKey;
	}

	public String getCityText() {
		return cityText;
	}

	@JsonProperty("CityText")
	public void setCityText(String cityText) {
		this.cityText = cityText;
	}

	@Override
	public String toString() {
		return "CityCategory [cityKey=" + cityKey + ", cityText=" + cityText + ", getCityKey()=" + getCityKey()
				+ ", getCityText()=" + getCityText() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

}
