package org.ril.hrss.house.rent.declaration.intercomm;

import java.util.Map;

import javax.validation.constraints.NotNull;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(value = "/sap/houseRentDecList", method = RequestMethod.GET, produces = "application/json")
	String getRentDeclarationRequest(@NotNull @RequestHeader("userID") String userId);

	@RequestMapping(method = RequestMethod.POST, value = "/sap/rentDeclaration/save", produces = "application/json", consumes = "application/json")
	Map<String, String> saveRentDeclarationRequest(@NotNull @RequestHeader("userID") String userId,
			@RequestBody String rentDeclarationJSONString);

	@RequestMapping(value = "/sap/city/categories", method = RequestMethod.GET, produces = "application/json")
	String getCityCategories(@NotNull @RequestHeader("userID") String userId);

	@RequestMapping(value = "/sap/rentDeclaration/update/{reqNumber}", method = RequestMethod.PUT, produces = "application/json", consumes = "application/json")
	Map<String, String> updateRentDeclarationRequest(@NotNull @RequestHeader("userID") String userId,
			@PathVariable("reqNumber") String reqNumber, @RequestBody String rentDeclarationJSONString);

	@RequestMapping(value = "/sap/rentDeclaration/delete/{reqNumber}", method = RequestMethod.DELETE, produces = "application/json")
	Map<String, String> deleteRentDeclarationRequest(@NotNull @RequestHeader("userID") String userId,
			@PathVariable("reqNumber") String reqNumber);

}