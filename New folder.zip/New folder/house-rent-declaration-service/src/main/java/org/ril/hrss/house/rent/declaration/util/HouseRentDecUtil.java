package org.ril.hrss.house.rent.declaration.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.ril.hrss.house.rent.declaration.intercomm.SapEndpointClient;
import org.ril.hrss.house.rent.declaration.model.CityCategory;
import org.ril.hrss.house.rent.declaration.model.HouseRentDeclaration;
import org.ril.hrss.house.rent.declaration.model.RentDeclaration;
import org.ril.hrss.house.rent.declaration.model.RentDeclarationJson;
import org.ril.hrss.house.rent.declaration.model.RentDeclarationMappinig;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.client.ClientException;

@Component
public class HouseRentDecUtil {

	protected static final Logger logger = Logger.getLogger(HouseRentDecUtil.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public List<HouseRentDeclaration> getHouseRentDecReq(String userId) throws ClientException {
		logger.info("HouseRentDecUtil.getHouseRentDecReq()");
		String response = sapEndpointClient.getRentDeclarationRequest(userId);
		List<HouseRentDeclaration> rentDeclarationsResponse = null;
		if (response == null) {
			rentDeclarationsResponse = new ArrayList<>();
		} else {
			rentDeclarationsResponse = getHouseRentDecObjectMapped(response);
		}
		return rentDeclarationsResponse;
	}

	private List<HouseRentDeclaration> getHouseRentDecObjectMapped(String feed) {
		logger.info("HouseRentDecUtil.getHouseRentDecObjectMapped()");
		TypeReference<List<HouseRentDeclaration>> type = new TypeReference<List<HouseRentDeclaration>>() {
		};
		return getDataList(type, feed);
	}

	public List<CityCategory> getCityCategories(String userId) throws ClientException {
		logger.info("HouseRentDecUtil.getCityCategories()");
		String response = sapEndpointClient.getCityCategories(userId);
		List<CityCategory> cityCategoriesReposnse = null;
		if (response == null) {
			cityCategoriesReposnse = new ArrayList<>();
		} else {
			cityCategoriesReposnse = getCityCategoriesObjectMapped(response);
		}
		return cityCategoriesReposnse;
	}

	private List<CityCategory> getCityCategoriesObjectMapped(String feed) {
		logger.info("HouseRentDecUtil.getCityCategoriesObjectMapped()");
		TypeReference<List<CityCategory>> type = new TypeReference<List<CityCategory>>() {
		};
		return getDataList(type, feed);
	}

	public ResponseEntity<RentDeclaration> rentDeclarationResponse(String userId,
			RentDeclarationMappinig rentDeclarationMappinig) throws ClientException {
		if (rentDeclarationMappinig.getReqNo() == null) {
			rentDeclarationMappinig.setReqNo(HRSSConstantUtil.EMPTY_STRING);
		}
		logger.info("HouseRentDecUtil.rentDeclarationResponse()");
		RentDeclaration obj = new RentDeclaration();
		BeanUtils.copyProperties(rentDeclarationMappinig, obj);
		String jsonData = null;
		try {
			jsonData = objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST).writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			logger.info(e.getMessage());
		}
		Map<String, String> map = sapEndpointClient.saveRentDeclarationRequest(userId, jsonData);
		return parseSAPResponse(obj, map);
	}

	public ResponseEntity<RentDeclaration> updateRentDeclarationResponse(String userId,
			RentDeclarationMappinig rentDeclarationMappinig, String reqNumber) throws ClientException {
		logger.info("HouseRentDecUtil.updateRentDeclarationResponse()");
		RentDeclaration obj = new RentDeclaration();
		BeanUtils.copyProperties(rentDeclarationMappinig, obj);
		String jsonData = null;
		try {
			jsonData = objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST).writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			logger.info(e.getMessage());
		}
		Map<String, String> map = sapEndpointClient.updateRentDeclarationRequest(userId, reqNumber, jsonData);
		return parseSAPResponse(obj, map);
	}

	private ResponseEntity<RentDeclaration> parseSAPResponse(RentDeclaration obj, Map<String, String> map) {
		if (map.get(HRSSConstantUtil.POST_RESPONSE_STATUS).equals(HRSSConstantUtil.POST_RESPONSE_STATUS_SUCCESS))
			return new ResponseEntity<RentDeclaration>(obj, HttpStatus.OK);
		else
			return new ResponseEntity<RentDeclaration>(obj, HttpStatus.BAD_REQUEST);
	}

	private List getDataList(TypeReference type, String feed) {
		List list = null;
		try {
			ObjectMapper objectMapper = objectMapperUtil.get();
			JsonNode rootNode = objectMapper.readTree(feed);
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
			objectMapper.setDateFormat(df);
			list = objectMapper.readValue(
					rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
					type);
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list;
	}

	public List<RentDeclarationJson> deleteRentDelcarationRequest(String userId, String reqNumber) {
		logger.info("HouseRentDecUtil.deleteRentDelcarationRequest()");
		try {
			Map<String, String> map = sapEndpointClient.deleteRentDeclarationRequest(userId, reqNumber);
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return null;
	}
}