package org.ril.hrss.house.rent.declaration.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.SAPDateFormatSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class RentDeclaration {

	private String reqNo;
	private Date fromDate;
	private Date toDate;
	private String cityCategory;
	private String actualRent;
	private String decLandLord;
	private String landlordpan;
	private String status;
	private String landlordaddr;
	private String landloardname;
	private String employeermk;
	private String docNum;
	private String requestStatus;
	private String requestErrMsg;
	private String systemErrMsg;

	public RentDeclaration() {
		super();
	}

	@JsonProperty("Reqno")
	public String getReqNo() {
		return reqNo;
	}

	@JsonProperty("reqNo")
	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	@JsonProperty("FromDate")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getFromDate() {
		return fromDate;
	}

	@JsonProperty("fromDate")
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	@JsonProperty("ToDate")
	@JsonSerialize(converter = SAPDateFormatSerializer.class)
	public Date getToDate() {
		return toDate;
	}

	@JsonProperty("toDate")
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	@JsonProperty("CityCatKey")
	public String getCityCategory() {
		return cityCategory;
	}

	@JsonProperty("cityCategory")
	public void setCityCategory(String cityCategory) {
		this.cityCategory = cityCategory;
	}

	@JsonProperty("ActRentAmt")
	public String getActualRent() {
		return actualRent;
	}

	@JsonProperty("actualRent")
	public void setActualRent(String actualRent) {
		this.actualRent = actualRent;
	}

	@JsonProperty("DecLandLord")
	public String getDecLandLord() {
		return decLandLord;
	}

	@JsonProperty("decLandLord")
	public void setDecLandLord(String decLandLord) {
		this.decLandLord = decLandLord;
	}

	@JsonProperty("PanLandLord")
	public String getLandlordpan() {
		return landlordpan;
	}

	@JsonProperty("landlordpan")
	public void setLandlordpan(String landlordpan) {
		this.landlordpan = landlordpan;
	}

	@JsonProperty("ReqStatusKey")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("LandLordAddr")
	public String getLandlordaddr() {
		return landlordaddr;
	}

	@JsonProperty("landlordaddr")
	public void setLandlordaddr(String landlordaddr) {
		this.landlordaddr = landlordaddr;
	}

	@JsonProperty("LandLordName")
	public String getLandloardname() {
		return landloardname;
	}

	@JsonProperty("landloardname")
	public void setLandloardname(String landloardname) {
		this.landloardname = landloardname;
	}

	@JsonProperty("EmpComments")
	public String getEmployeermk() {
		return employeermk;
	}

	@JsonProperty("employeermk")
	public void setEmployeermk(String employeermk) {
		this.employeermk = employeermk;
	}

	@JsonProperty("DocNum")
	public String getDocNum() {
		return docNum;
	}

	@JsonProperty("docNum")
	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public String getSystemErrMsg() {
		return systemErrMsg;
	}

	public void setSystemErrMsg(String systemErrMsg) {
		this.systemErrMsg = systemErrMsg;
	}

	@Override
	public String toString() {
		return "RentDeclaration [reqNo=" + reqNo + ", fromDate=" + fromDate + ", toDate=" + toDate + ", cityCategory="
				+ cityCategory + ", actualRent=" + actualRent + ", decLandLord=" + decLandLord + ", landlordpan="
				+ landlordpan + ", status=" + status + ", landlordaddr=" + landlordaddr + ", landloardname="
				+ landloardname + ", employeermk=" + employeermk + ", docNum=" + docNum + ", requestStatus="
				+ requestStatus + ", requestErrMsg=" + requestErrMsg + ", systemErrMsg=" + systemErrMsg + "]";
	}

}