package org.ril.hrss.book.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.ril.hrss.book.client.SapEndpointClient;
import org.ril.hrss.book.interfaces.BookMedicalServiceRepo;
import org.ril.hrss.book.model.AppointmentDetail;
import org.ril.hrss.book.model.AppointmentDetailJson;
import org.ril.hrss.book.util.BookMedicalUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.netflix.client.ClientException;

import feign.FeignException;

@Service
public class BookMedicalService implements BookMedicalServiceRepo {

	protected static final Logger logger = Logger.getLogger(BookMedicalService.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private BookMedicalUtil bookMedicalUtil;

	@Override
	public List<AppointmentDetailJson> bookAppointmentList(String userId, List<AppointmentDetail> saveList)
			throws ClientException, FeignException {
		logger.info("BookMedicalService.bookAppointmentList()");
		List<AppointmentDetailJson> result = new ArrayList<AppointmentDetailJson>();
		for (AppointmentDetail obj : saveList) {
			try {
				Map<String, String> map = sapEndpointClient.bookAppointment(userId,
						bookMedicalUtil.getObjectMapper().writeValueAsString(obj));
				obj.setRequestStatus(map.get(HRSSConstantUtil.POST_RESPONSE_STATUS));
				obj.setRequestErrMsg(map.get(HRSSConstantUtil.POST_RESPONSE_ERR_MSG));
				AppointmentDetailJson resultObj = new AppointmentDetailJson();
				BeanUtils.copyProperties(obj, resultObj);
				result.add(resultObj);
			} catch (JsonProcessingException e) {
				logger.info(HRSSConstantUtil.JSON_PROCESSING_FALIED_MSG);
			}
		}
		return result;
	}

}