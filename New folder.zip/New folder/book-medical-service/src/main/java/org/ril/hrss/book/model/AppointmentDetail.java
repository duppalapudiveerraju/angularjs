package org.ril.hrss.book.model;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.enumeration.PMEUser;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AppointmentDetail {

	@NotNull(message = "Appointment date can't be null")
	private Date apptDate;

	@NotNull(message = "Appointment time slot can't be null")
	private Date apptTimeSlot;

	@NotNull(message = "PME relation can't be null")
	private PMEUser pmeRelation;

	private String requestStatus;
	private String requestErrMsg;

	public AppointmentDetail() {
		super();
	}

	public AppointmentDetail(Date apptDate, Date apptTimeSlot, PMEUser pmeRelation, String requestStatus,
			String requestErrMsg) {
		super();
		this.apptDate = apptDate;
		this.apptTimeSlot = apptTimeSlot;
		this.pmeRelation = pmeRelation;
		this.requestStatus = requestStatus;
		this.requestErrMsg = requestErrMsg;
	}

	@JsonProperty("ImApptdate")
	public Date getApptDate() {
		return apptDate;
	}

	@JsonProperty("apptDate")
	public void setApptDate(Date apptDate) {
		this.apptDate = apptDate;
	}

	@JsonProperty("ImApptime")
	public String getApptTimeSlotStr() {
		String str = DateUtil.getFormattedStrFromDate(apptTimeSlot);
		return str != null ? str : HRSSConstantUtil.DEFAULT_SAP_TIME_FORMAT;
	}
	
	@JsonIgnore
	public Date getApptTimeSlot() {
		return apptTimeSlot;
	}

	@JsonProperty("apptTimeSlot")
	public void setApptTimeSlot(Date apptTimeSlot) {
		this.apptTimeSlot = apptTimeSlot;
	}

	@JsonProperty("ImRelation")
	public String getPmeRelationStr() {
		return pmeRelation.getShortTxt();
	}
	
	@JsonIgnore
	public PMEUser getPmeRelation() {
		return pmeRelation;
	}

	@JsonProperty("pmeRelation")
	public void setPmeRelation(PMEUser pmeRelation) {
		this.pmeRelation = pmeRelation;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}

	@Override
	public String toString() {
		return "AppointmentDetail [apptDate=" + apptDate + ", apptTimeSlot=" + apptTimeSlot + ", pmeRelation="
				+ pmeRelation + ", requestStatus=" + requestStatus + ", requestErrMsg=" + requestErrMsg + "]";
	}

}