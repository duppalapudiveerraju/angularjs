package org.ril.hrss.book.client.fallback;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.book.client.SapEndpointClient;

public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public Map<String, String> bookAppointment(String userId, String apptStr) {
		return new HashMap<>();
	}

}