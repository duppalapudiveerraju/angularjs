package org.ril.hrss.book.client;

import java.util.Map;

import javax.validation.constraints.NotNull;

import org.ril.hrss.book.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(value = "/sap/medical/book", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	Map<String, String> bookAppointment(@NotNull @RequestHeader("userId") String userId,
			@NotNull @RequestBody String apptStr);
}
