package org.ril.hrss.book.model;

import java.util.Date;

import org.ril.hrss.msf.util.enumeration.PMEUser;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AppointmentDetailJson {

	private Date apptDate;
	private Date apptTimeSlot;
	private PMEUser pmeRelation;
	private String requestErrMsg;
	private String requestStatus;

	public AppointmentDetailJson() {
		super();
	}

	public AppointmentDetailJson(Date apptDate, Date apptTimeSlot, PMEUser pmeRelation, String requestErrMsg,
			String requestStatus) {
		super();
		this.apptDate = apptDate;
		this.apptTimeSlot = apptTimeSlot;
		this.pmeRelation = pmeRelation;
		this.requestErrMsg = requestErrMsg;
		this.requestStatus = requestStatus;
	}

	public Date getApptDate() {
		return apptDate;
	}

	public void setApptDate(Date apptDate) {
		this.apptDate = apptDate;
	}

	public Date getApptTimeSlot() {
		return apptTimeSlot;
	}

	public void setApptTimeSlot(Date apptTimeSlot) {
		this.apptTimeSlot = apptTimeSlot;
	}

	public PMEUser getPmeRelation() {
		return pmeRelation;
	}

	public void setPmeRelation(PMEUser pmeRelation) {
		this.pmeRelation = pmeRelation;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}

	@Override
	public String toString() {
		return "AppointmentDetailJson [apptDate=" + apptDate + ", apptTimeSlot=" + apptTimeSlot + ", pmeRelation="
				+ pmeRelation + ", requestErrMsg=" + requestErrMsg + ", requestStatus=" + requestStatus + "]";
	}

}