package org.ril.hrss.book.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Logger;

import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class BookMedicalUtil {

	protected static final Logger logger = Logger.getLogger(BookMedicalUtil.class.getName());

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public BookMedicalUtil() {
		super();
	}
	
	public ObjectMapper getObjectMapper() {
		logger.info("BookMedicalUtil.getObjectMapper()");
		ObjectMapper objectMapper = objectMapperUtil.get();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		objectMapper.setDateFormat(df);
		return objectMapper;
	}

}