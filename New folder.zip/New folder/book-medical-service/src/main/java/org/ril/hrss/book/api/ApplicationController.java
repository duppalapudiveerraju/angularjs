package org.ril.hrss.book.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.ril.hrss.book.interfaces.BookMedicalServiceRepo;
import org.ril.hrss.book.model.AppointmentDetail;
import org.ril.hrss.book.model.AppointmentDetailJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import feign.FeignException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Book Medical Service", description = "Operations pertaining to Book Medical Service")
public class ApplicationController {

	@Autowired
	private BookMedicalServiceRepo bookMedicalServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save a list of Appointment details", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Successfully save a list of Appointment details"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<AppointmentDetailJson> bookAppointmentList(@NotNull @RequestHeader("userId") String userId,
			@Valid @RequestBody List<AppointmentDetail> saveList) throws ClientException, FeignException {
		logger.info("ApplicationController.bookAppointmentList()");
		return bookMedicalServiceRepo.bookAppointmentList(userId, saveList);
	}

}