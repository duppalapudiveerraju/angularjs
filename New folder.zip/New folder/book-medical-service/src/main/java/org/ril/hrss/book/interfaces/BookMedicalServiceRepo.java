package org.ril.hrss.book.interfaces;

import java.util.List;

import org.ril.hrss.book.model.AppointmentDetail;
import org.ril.hrss.book.model.AppointmentDetailJson;

import com.netflix.client.ClientException;

import feign.FeignException;

public interface BookMedicalServiceRepo {
	
	public List<AppointmentDetailJson> bookAppointmentList(String userId, List<AppointmentDetail> saveList) throws ClientException, FeignException;

}