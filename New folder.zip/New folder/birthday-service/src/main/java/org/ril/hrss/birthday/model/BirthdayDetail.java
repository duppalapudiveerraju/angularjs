package org.ril.hrss.birthday.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BirthdayDetail {

	private String username;
	private String empUserId;
	private String empName;
	private boolean empSelfBirthday;

	public BirthdayDetail() {
		super();
	}

	public BirthdayDetail(String username, String empUserId, String empName, boolean empSelfBirthday) {
		super();
		this.username = username;
		this.empUserId = empUserId;
		this.empName = empName;
		this.empSelfBirthday = empSelfBirthday;
	}

	@JsonProperty("username")
	public String getUsername() {
		return username;
	}

	@JsonProperty("Username")
	public void setUsername(String username) {
		this.username = username;
	}

	@JsonProperty("empUserId")
	public String getEmpUserId() {
		return empUserId;
	}

	@JsonProperty("Pernr")
	public void setEmpUserId(String empUserId) {
		this.empUserId = empUserId;
	}

	@JsonProperty("empName")
	public String getEmpName() {
		return empName;
	}

	@JsonProperty("Name")
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@JsonProperty("empBirthday")
	public boolean isEmpSelfBirthday() {
		return empSelfBirthday;
	}

	@JsonProperty("Self")
	public void setEmpSelfBirthday(String empSelfBirthdayStr) {
		this.empSelfBirthday = empSelfBirthdayStr.isEmpty() ? Boolean.FALSE : Boolean.TRUE;
	}

	@Override
	public String toString() {
		return "BirthdayDetail [username=" + username + ", empUserId=" + empUserId + ", empName=" + empName
				+ ", empSelfBirthday=" + empSelfBirthday + "]";
	}

}
