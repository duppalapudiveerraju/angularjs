package org.ril.hrss.birthday.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.birthday.model.BirthdayDetail;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class BirthdayUtil {

	protected static final Logger logger = Logger.getLogger(BirthdayUtil.class.getName());

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public BirthdayUtil() {
		super();
	}

	public List<BirthdayDetail> getBirthdayDetailObjectMapped(String feed) {
		logger.info("BirthdayUtil.getHolidayCalenderList()");
		List<BirthdayDetail> list = new ArrayList<BirthdayDetail>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
		objectMapper.setDateFormat(df);
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapper.readTree(feed);
				list = objectMapper.readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<BirthdayDetail>>() {
						});
			}
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list;
	}

}