package org.ril.hrss.birthday.interfaces;

import java.util.List;

import org.ril.hrss.birthday.model.BirthdayDetail;

import com.netflix.client.ClientException;

public interface BirthdayServiceRepo {
	
	public List<BirthdayDetail> getBirthdayDetailList(String userId) throws ClientException;

}