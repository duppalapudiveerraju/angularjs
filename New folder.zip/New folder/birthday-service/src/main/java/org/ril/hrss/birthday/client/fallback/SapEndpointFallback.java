package org.ril.hrss.birthday.client.fallback;

import org.ril.hrss.birthday.client.SapEndpointClient;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getBirthdayDetails(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}