package org.ril.hrss.birthday.api;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.birthday.interfaces.BirthdayServiceRepo;
import org.ril.hrss.birthday.model.BirthdayDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/birthday")
@Api(value = "Birthday details", description = "Operations pertaining to find birthday details")
public class ApplicationController {

	@Autowired
	private BirthdayServiceRepo birthdayServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/list/userId/{userId}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of birthday details", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<BirthdayDetail> getBirthdayDetailList(@PathVariable("userId") String userId) throws ClientException {
		logger.info("birthday-service-controller.getBirthdayDetailList()");
		return birthdayServiceRepo.getBirthdayDetailList(userId);
	}

}