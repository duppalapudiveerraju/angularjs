package org.ril.hrss.feedback.interfaces;

import java.util.List;

import org.ril.hrss.feedback.model.Feedback;
import org.springframework.http.ResponseEntity;

public interface FeedbackServiceRepo {
	
	public ResponseEntity<Feedback> getFeedbackAppInfo(String appName);
	
	public ResponseEntity<List<Feedback>> getAllFeedbackAppInfo();
	
	public void saveFeedbackAppInfo(Feedback input, String userId);

}