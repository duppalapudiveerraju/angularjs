package org.ril.hrss.feedback.api;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.feedback.interfaces.FeedbackServiceRepo;
import org.ril.hrss.feedback.model.Feedback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/feedback")
@Api(value = "Feedback details", description = "Operations pertaining to feedback details")
public class ApplicationController {

	@Autowired
	private FeedbackServiceRepo feedbackServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/details/appName/{appName}/userId/{userId}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get Feedback Object", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved a feedback object"),
			@ApiResponse(code = 201, message = "Successfully saved list of regularize request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Feedback> getFeedbackInfo(@PathVariable("userId") String userId,
			@PathVariable("appName") String appName) {
		logger.info("feedback-service.getFeedbackInfo()");
		return feedbackServiceRepo.getFeedbackAppInfo(appName);
	}
	
	@RequestMapping(value = "/findAll", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get Feedback Object List", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved a list of feedback object"),
			@ApiResponse(code = 201, message = "Successfully saved list of regularize request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<List<Feedback>> getAllFeedbackInfo() {
		logger.info("feedback-service.getAllFeedbackInfo()");
		return feedbackServiceRepo.getAllFeedbackAppInfo();
	}

	@RequestMapping(value = "/save/userId/{userId}", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save feedback request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully saved list of leave request"),
			@ApiResponse(code = 201, message = "Successfully saved list of regularize request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Feedback> saveFeedbackRequest(@PathVariable("userId") String userId,
			@RequestBody Feedback input) {
		logger.info("feedback-service.saveFeedbackRequest()");
		feedbackServiceRepo.saveFeedbackAppInfo(input, userId);
		return new ResponseEntity<Feedback>(input, HttpStatus.OK);
	}

}