package org.ril.hrss.feedback.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.feedback.interfaces.FeedbackServiceRepo;
import org.ril.hrss.feedback.model.ApplicationInfo;
import org.ril.hrss.feedback.model.Feedback;
import org.ril.hrss.feedback.model.FeedbackApp;
import org.ril.hrss.feedback.model.FeedbackHistory;
import org.ril.hrss.feedback.repository.ApplicationInfoRepository;
import org.ril.hrss.feedback.repository.FeedbackAppRepository;
import org.ril.hrss.feedback.repository.FeedbackHistoryRepository;
import org.ril.hrss.feedback.util.FeedbackUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FeedbackService implements FeedbackServiceRepo {

	@Autowired
	private FeedbackHistoryRepository feedbackHistoryRepo;

	@Autowired
	private FeedbackAppRepository feedbackAppRepo;

	@Autowired
	private ApplicationInfoRepository applicationInfoRepo;

	@Autowired
	private FeedbackUtil feedbackUtil;

	protected static final Logger logger = Logger.getLogger(FeedbackService.class.getName());

	public FeedbackService() {
		super();
	}

	@Override
	public ResponseEntity<Feedback> getFeedbackAppInfo(String appName) {
		logger.info("feedbackService.getFeedbackAppInfo()");
		FeedbackApp appObj = feedbackAppRepo.getFeedbackAppByAppName(appName);
		Feedback resObj = new Feedback();
		resObj.setAppName(appName);
		if (appObj != null) {
			resObj.setAppRating(appObj.getAppAvgRating());
			resObj.setAppNoOfVotes((double) feedbackHistoryRepo.fetchFeedbackHistoryByAppName(appName).size());
			return new ResponseEntity<Feedback>(resObj, HttpStatus.OK);
		} else {
			resObj.setAppRating(HRSSConstantUtil.ZERO);
			return new ResponseEntity<Feedback>(resObj, HttpStatus.OK);
		}
	}

	@Override
	@Transactional
	public void saveFeedbackAppInfo(Feedback input, String userId) {
		logger.info("feedbackService.saveFeedbackAppInfo()");
		FeedbackHistory saveObj = new FeedbackHistory();
		BeanUtils.copyProperties(input, saveObj);
		saveObj.setAppUserId(userId);
		ApplicationInfo appInfo = applicationInfoRepo.getApplicationInfoByAppName(input.getAppName());
		if (appInfo != null) {
			saveObj.setAppId(appInfo.getId());
		} else {
			appInfo = feedbackUtil.setApplicationInfoObj(appInfo, input, applicationInfoRepo);
		}
		FeedbackApp fetchedAppObj = feedbackAppRepo.getFeedbackAppByAppName(input.getAppName());
		if (fetchedAppObj == null) {
			feedbackUtil.saveFeedbackAppObj(fetchedAppObj, appInfo, feedbackAppRepo);
		}
		feedbackUtil.setFeedbackHistoryObj(saveObj, input, feedbackAppRepo, feedbackHistoryRepo);
	}

	@Override
	public ResponseEntity<List<Feedback>> getAllFeedbackAppInfo() {
		logger.info("feedbackService.getAllFeedbackAppInfo()");
		List<Feedback> result = new ArrayList<>();
		feedbackAppRepo.findAll().forEach(e -> result
				.add(getFeedbackAppInfo(applicationInfoRepo.getApplicationNameByAppId(e.getAppId())).getBody()));
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

}