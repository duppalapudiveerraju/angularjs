package org.ril.hrss.feedback.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "feedback_history")
public class FeedbackHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer id;

	@NotNull(message = "The AppId is a required field")
	private Integer appId;

	private String appRemark;

	@NotNull(message = "The AppRating is a required field")
	@Min(value = 0, message = "The AppRating should be between 0 and 5")
	@Max(value = 5, message = "The AppRating should be between 0 and 5")
	private Double appRating;

	@NotNull(message = "The UserId is a required field")
	private String appUserId;

	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDate;

	public FeedbackHistory() {
		super();
	}

	public FeedbackHistory(Integer id, Integer appId, String appRemark, Double appRating, String appUserId,
			Date createDate) {
		super();
		this.id = id;
		this.appId = appId;
		this.appRemark = appRemark;
		this.appRating = appRating;
		this.appUserId = appUserId;
		this.createDate = createDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAppRemark() {
		return appRemark;
	}

	public void setAppRemark(String appRemark) {
		this.appRemark = appRemark;
	}

	public Double getAppRating() {
		return appRating;
	}

	public void setAppRating(Double appRating) {
		this.appRating = appRating;
	}

	public String getAppUserId() {
		return appUserId;
	}

	public void setAppUserId(String appUserId) {
		this.appUserId = appUserId;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	@Override
	public String toString() {
		return "FeedbackHistory [id=" + id + ", appId=" + appId + ", appRemark=" + appRemark + ", appRating="
				+ appRating + ", appUserId=" + appUserId + ", createDate=" + createDate + "]";
	}

}