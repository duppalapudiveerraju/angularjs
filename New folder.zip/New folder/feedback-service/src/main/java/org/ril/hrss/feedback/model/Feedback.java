package org.ril.hrss.feedback.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

public class Feedback {

	@NotNull(message = "The AppName is a required field")
	@Size(min = 3, max = 50, message = "The AppName should be between 3 and 50 characters")
	private String appName;
	
	private String appRemark;
	
	@NotNull(message = "The AppNoOfVotes is a required field")
	private Double appNoOfVotes;
	
	@NotNull(message = "The AppRating is a required field")
	@Min(value = 0, message = "The AppRating should be between 0 and 5")
	@Max(value = 5, message = "The AppRating should be between 0 and 5")
	private Double appRating;

	public Feedback() {
		super();
	}

	public Feedback(String appName, String appRemark, Double appNoOfVotes, Double appRating) {
		super();
		this.appName = appName;
		this.appRemark = appRemark;
		this.appNoOfVotes = appNoOfVotes;
		this.appRating = appRating;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	public String getAppRemark() {
		return appRemark;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	public void setAppRemark(String appRemark) {
		this.appRemark = appRemark;
	}

	public Double getAppRating() {
		return appRating;
	}

	public void setAppRating(Double appRating) {
		this.appRating = appRating;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	public Double getAppNoOfVotes() {
		return appNoOfVotes;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	public void setAppNoOfVotes(Double appNoOfVotes) {
		this.appNoOfVotes = appNoOfVotes;
	}

	@Override
	public String toString() {
		return "Feedback [appName=" + appName + ", appRemark=" + appRemark + ", appNoOfVotes=" + appNoOfVotes
				+ ", appRating=" + appRating + "]";
	}

}