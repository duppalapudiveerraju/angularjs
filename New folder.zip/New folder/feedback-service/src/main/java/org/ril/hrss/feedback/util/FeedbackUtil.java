package org.ril.hrss.feedback.util;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.feedback.model.ApplicationInfo;
import org.ril.hrss.feedback.model.Feedback;
import org.ril.hrss.feedback.model.FeedbackApp;
import org.ril.hrss.feedback.model.FeedbackHistory;
import org.ril.hrss.feedback.repository.ApplicationInfoRepository;
import org.ril.hrss.feedback.repository.FeedbackAppRepository;
import org.ril.hrss.feedback.repository.FeedbackHistoryRepository;
import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class FeedbackUtil {

	protected static final Logger logger = Logger.getLogger(FeedbackUtil.class.getName());

	public FeedbackUtil() {
		super();
	}

	public void setFeedbackHistoryObj(FeedbackHistory saveObj, Feedback input, FeedbackAppRepository feedbackAppRepo,
			FeedbackHistoryRepository feedbackHistoryRepo) {
		logger.info("FeedbackUtil.setFeedbackHistoryObj()");
		saveObj.setAppId(feedbackAppRepo.getFeedbackAppIdByAppName(input.getAppName()));
		feedbackHistoryRepo.save(saveObj);
		List<FeedbackHistory> list = feedbackHistoryRepo.fetchFeedbackHistoryByAppName(input.getAppName());
		FeedbackApp appObj = feedbackAppRepo.getFeedbackAppByAppName(input.getAppName());
		Double avgRating = Double.parseDouble(DateUtil.DECIMAL_FORMATTER_1
				.format(list.parallelStream().mapToDouble(FeedbackHistory::getAppRating).sum() / list.size()));
		appObj.setAppAvgRating(avgRating);
		feedbackAppRepo.save(appObj);
	}

	public ApplicationInfo setApplicationInfoObj(ApplicationInfo appInfo, Feedback input,
			ApplicationInfoRepository applicationInfoRepo) {
		logger.info("FeedbackUtil.setApplicationInfoObj()");
		appInfo = new ApplicationInfo();
		appInfo.setAppName(input.getAppName());
		applicationInfoRepo.save(appInfo);
		return appInfo;
	}

	public void saveFeedbackAppObj(FeedbackApp fetchedAppObj, ApplicationInfo appInfo,
			FeedbackAppRepository feedbackAppRepo) {
		logger.info("FeedbackUtil.saveFeedbackAppObj()");
		fetchedAppObj = new FeedbackApp();
		fetchedAppObj.setAppId(appInfo.getId());
		fetchedAppObj.setAppAvgRating(HRSSConstantUtil.ZERO);
		feedbackAppRepo.save(fetchedAppObj);
	}

}