package org.ril.hrss.feedback.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "feedback_app")
public class FeedbackApp {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotNull(message = "The AppId is a required field")
	private Integer appId;

	@NotNull(message = "The AppRating is a required field")
	@Min(value = 0, message = "The AppRating should be between 0 and 5")
	@Max(value = 5, message = "The AppRating should be between 0 and 5")
	private Double appAvgRating;

	public FeedbackApp() {
		super();
	}

	public FeedbackApp(Integer id, Integer appId, Double appAvgRating) {
		super();
		this.id = id;
		this.appId = appId;
		this.appAvgRating = appAvgRating;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Double getAppAvgRating() {
		return appAvgRating;
	}

	public void setAppAvgRating(Double appAvgRating) {
		this.appAvgRating = appAvgRating;
	}

	@Override
	public String toString() {
		return "FeedbackApp [id=" + id + ", appId=" + appId + ", appAvgRating=" + appAvgRating + "]";
	}

}