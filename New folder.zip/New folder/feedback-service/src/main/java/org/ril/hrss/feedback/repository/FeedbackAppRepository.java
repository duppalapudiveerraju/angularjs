package org.ril.hrss.feedback.repository;

import org.ril.hrss.feedback.model.FeedbackApp;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface FeedbackAppRepository extends CrudRepository<FeedbackApp, Long> {

	@Query("SELECT a.appId FROM FeedbackApp a WHERE a.appId = (SELECT b.id FROM ApplicationInfo b WHERE b.appName=:appName)")
	Integer getFeedbackAppIdByAppName(@Param("appName") String appName);

	@Query("SELECT a FROM FeedbackApp a WHERE a.appId = (SELECT b.id FROM ApplicationInfo b WHERE b.appName=:appName)")
	FeedbackApp getFeedbackAppByAppName(@Param("appName") String appName);

}
