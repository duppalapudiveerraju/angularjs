package org.ril.hrss.feedback.repository;

import java.util.List;

import org.ril.hrss.feedback.model.FeedbackHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface FeedbackHistoryRepository extends CrudRepository<FeedbackHistory, Long> {

	@Query("SELECT a FROM FeedbackHistory a WHERE a.appId=(SELECT b.id FROM ApplicationInfo b WHERE b.appName=:appName)")
	List<FeedbackHistory> fetchFeedbackHistoryByAppName(@Param("appName") String appName);

}
