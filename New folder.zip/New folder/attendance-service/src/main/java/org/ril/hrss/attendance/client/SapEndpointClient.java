package org.ril.hrss.attendance.client;

import org.ril.hrss.attendance.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.GET, value = "/sap/attendance/userId/{userId}/filter/{month}/{year}")
	String getAttendanceDetailsMonthWise(@PathVariable("userId") String userId, @PathVariable("month") String month,
			@PathVariable("year") String year);

}
