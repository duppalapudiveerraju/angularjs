package org.ril.hrss.attendance.model;

public enum CalenderHexColorCode {

	REGULARIZE_ONE_TOUCH("#4a90e2"), REGULARIZE("#c14f5f"), ABSENT("#c14f5f"), NORMAL("#000000"), COMPANY_EVENT(
			"#bf5900"), PERSONAL_REMINDER("#006690");
	private String hexColorCode;

	private CalenderHexColorCode(String hexColorCode) {
		this.hexColorCode = hexColorCode;
	}

	public String getHexColorCode() {
		return hexColorCode;
	}
}
