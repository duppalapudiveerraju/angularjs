package org.ril.hrss.attendance.interfaces;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.ril.hrss.attendance.model.AttendanceDetail;
import org.ril.hrss.attendance.model.CalenderCategory;

import com.netflix.client.ClientException;

public interface AttendanceServiceRepo {

	public List<AttendanceDetail> getAllAttendanceDetail(String userId, String month, String year)
			throws ClientException;

	public List<Date> getNonWorkingDaysMonthwise(String userId, String month, String year) throws ClientException;

	public Map<CalenderCategory, List<AttendanceDetail>> setRegAbsentGrouping(
			Map<CalenderCategory, List<AttendanceDetail>> map) throws ClientException;

}