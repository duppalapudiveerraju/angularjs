package org.ril.hrss.attendance.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.attendance.interfaces.AttendanceServiceRepo;
import org.ril.hrss.attendance.model.AttendanceDetail;
import org.ril.hrss.attendance.model.CalenderCategory;
import org.ril.hrss.attendance.model.UserInfoDetail;
import org.ril.hrss.attendance.util.AttendanceUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netflix.client.ClientException;

@Service
public class AttendanceService implements AttendanceServiceRepo {
	
	protected static final Logger logger = Logger.getLogger(AttendanceService.class.getName());
	
	@Autowired
	private AttendanceUtil attendanceUtil;
	
	public AttendanceService() {
		super();
	}

	@Override
	public List<AttendanceDetail> getAllAttendanceDetail(String userId, String month, String year) throws ClientException {
		logger.info("AttendanceService.getAllAttendanceDetail()");
		UserInfoDetail userInfoObj = attendanceUtil.getUserInfoObj(userId);
		if (attendanceUtil.isFlexiShift(userInfoObj.getShiftCode())) {
			return attendanceUtil.getFlexiAttendanceDetail(userId, month, year, userInfoObj);
		} else {
			return attendanceUtil.getNonFlexiAttendanceDetail(userId, month, year, userInfoObj);
		}
	}

	@Override
	public List<Date> getNonWorkingDaysMonthwise(String userId, String month, String year) throws ClientException {
		logger.info("AttendanceService.getNonWorkingDaysMonthwise()");
		return getAllAttendanceDetail(userId, month, year).parallelStream()
				.filter(e -> e.getAttCategory().equals(CalenderCategory.WEEKLY_OFF)
						&& e.getAttCategory().equals(CalenderCategory.PUBLIC_HOLIDAY))
				.map(AttendanceDetail::getAttStartDate).collect(Collectors.toList());
	}

	@Override
	public Map<CalenderCategory, List<AttendanceDetail>> setRegAbsentGrouping(
			Map<CalenderCategory, List<AttendanceDetail>> map) throws ClientException {
		logger.info("AttendanceService.setRegAbsentGrouping()");
		if (map.containsKey(CalenderCategory.ABSENT) && map.containsKey(CalenderCategory.REGULARIZE)) {
			map.get(CalenderCategory.REGULARIZE).addAll(map.get(CalenderCategory.ABSENT));
		} else if (!map.containsKey(CalenderCategory.REGULARIZE)) {
			map.put(CalenderCategory.REGULARIZE, map.get(CalenderCategory.ABSENT));
		}
		return map;
	}

}