package org.ril.hrss.attendance.client.fallback;

import org.ril.hrss.attendance.client.UserInfoClient;
import org.ril.hrss.attendance.model.UserInfoDetail;

public class UserInfoFallback implements UserInfoClient {

	@Override
	public UserInfoDetail getUserInfoDetails(String userId) {
		return new UserInfoDetail();
	}

}