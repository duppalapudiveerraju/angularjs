package org.ril.hrss.attendance.model;

import java.util.Calendar;
import java.util.TimeZone;

import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class AttendanceDetailFilter extends StdConverter<AttendanceDetail, AttendanceDetail> {

	private Calendar cal;

	public AttendanceDetailFilter() {
		super();
		cal = Calendar.getInstance(TimeZone.getDefault());
	}

	@Override
	public AttendanceDetail convert(AttendanceDetail obj) {
		cal.setTime(obj.getAttStartDate());
		obj.setWeekOfMonth(HRSSConstantUtil.WEEK_IDENTIFIER + cal.get(Calendar.WEEK_OF_YEAR));
		if (obj.isAbsFlag() && !obj.getLeaveStatus().contains(HRSSConstantUtil.ATT_STATUS_PENDING)
				&& !obj.getRegStatus().contains(HRSSConstantUtil.ATT_STATUS_PENDING)) {
			obj.setAttCategory(CalenderCategory.ABSENT);
			obj.setColorCode(CalenderHexColorCode.ABSENT.getHexColorCode());
		} else if (obj.isAbsFlag() && (obj.getLeaveStatus().contains(HRSSConstantUtil.ATT_STATUS_PENDING)
				|| obj.getLeaveStatus().contains(HRSSConstantUtil.ATT_STATUS_APPROVED))) {
			obj.setAttCategory(CalenderCategory.LEAVE);
		} else if (obj.getAttStatus().toUpperCase().trim().equals(HRSSConstantUtil.ATT_STATUS_WEEKLY_OFF)
				|| obj.getShiftType().toUpperCase().trim().equals(HRSSConstantUtil.SHIFT_TYPE_WEEKLY_OFF)) {
			obj.setAttCategory(CalenderCategory.WEEKLY_OFF);
		} else if (obj.getAttStatus().toUpperCase().trim().equals(HRSSConstantUtil.ATT_STATUS_PUBLIC_HOLIDAY) || obj
				.getAttStatus().toUpperCase().trim().contains(HRSSConstantUtil.ATT_PROCESSED_STATUS_PUBLIC_HOLIDAY)) {
			obj.setAttCategory(CalenderCategory.PUBLIC_HOLIDAY);
		} else if (getActualTime(obj) < getShiftTime(obj)) {
			obj.setAttCategory(CalenderCategory.REGULARIZE);
			obj.setColorCode(CalenderHexColorCode.REGULARIZE.getHexColorCode());
		} else {
			obj.setAttCategory(CalenderCategory.NORMAL);
			obj.setColorCode(CalenderHexColorCode.NORMAL.getHexColorCode());
		}
		return obj;
	}

	private long getShiftTime(AttendanceDetail obj) {
		return DateUtil.getMilsecFromDouble(obj.getShiftTime());
	}

	private long getActualTime(AttendanceDetail obj) {
		return DateUtil.getMilsecFromDouble(obj.getActualTime());
	}

}