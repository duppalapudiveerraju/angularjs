package org.ril.hrss.attendance.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.SAPBooleanSerializer;
import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;
import org.ril.hrss.msf.util.DateUtil;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(converter = AttendanceDetailFilter.class)
public class AttendanceDetail {

	private Date attStartDate;
	private Date attEndDate;
	private Date actualIn;
	private Date actualOut;
	private Date shiftStartTime;
	private Date shiftEndTime;
	private Double shiftTime;
	private Double actualTime;
	private String colorCode;
	private boolean absFlag;
	private String leaveStatus;
	private String regStatus;
	private String attStatus;
	private String shiftType;
	private CalenderCategory attCategory;
	private String weekOfMonth;
	private String userId;
	private String locationCode;
	private String locationDesc;
	private Date planShiftStartTime;
	private Date planShiftEndTime;
	private Double maxWorkingTime;
	private Double minWorkingTime;
	private Date toleranceStartTime;
	private Date toleranceEndTime;

	public AttendanceDetail() {
		super();
	}

	public AttendanceDetail(Date attStartDate, Date attEndDate, Date actualIn, Date actualOut, Date shiftStartTime,
			Date shiftEndTime, Double shiftTime, Double actualTime, String colorCode, boolean absFlag,
			String leaveStatus, String regStatus, String attStatus, String shiftType, CalenderCategory attCategory,
			String weekOfMonth, String userId, String locationCode, String locationDesc, Date planShiftStartTime,
			Date planShiftEndTime, Double maxWorkingTime, Double minWorkingTime, Date toleranceStartTime,
			Date toleranceEndTime) {
		super();
		this.attStartDate = attStartDate;
		this.attEndDate = attEndDate;
		this.actualIn = actualIn;
		this.actualOut = actualOut;
		this.shiftStartTime = shiftStartTime;
		this.shiftEndTime = shiftEndTime;
		this.shiftTime = shiftTime;
		this.actualTime = actualTime;
		this.colorCode = colorCode;
		this.absFlag = absFlag;
		this.leaveStatus = leaveStatus;
		this.regStatus = regStatus;
		this.attStatus = attStatus;
		this.shiftType = shiftType;
		this.attCategory = attCategory;
		this.weekOfMonth = weekOfMonth;
		this.userId = userId;
		this.locationCode = locationCode;
		this.locationDesc = locationDesc;
		this.planShiftStartTime = planShiftStartTime;
		this.planShiftEndTime = planShiftEndTime;
		this.maxWorkingTime = maxWorkingTime;
		this.minWorkingTime = minWorkingTime;
		this.toleranceStartTime = toleranceStartTime;
		this.toleranceEndTime = toleranceEndTime;
	}

	@JsonProperty("attStartDate")
	public Date getAttStartDate() {
		return attStartDate;
	}

	@JsonProperty("Date")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setAttStartDate(Date attStartDate) {
		this.attStartDate = attStartDate;
	}

	public Date getAttEndDate() {
		return DateUtil.getEndOfTheDay(attStartDate);
	}

	public void setAttEndDate(Date attEndDate) {
		this.attEndDate = attEndDate;
	}

	@JsonProperty("colorCode")
	public String getColorCode() {
		return colorCode;
	}

	@JsonProperty("ColorCode")
	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	@JsonProperty("absFlag")
	public boolean isAbsFlag() {
		return absFlag;
	}

	@JsonProperty("AbsFlag")
	@JsonDeserialize(converter = SAPBooleanSerializer.class)
	public void setAbsFlag(boolean absFlag) {
		this.absFlag = absFlag;
	}

	@JsonProperty("leaveStatus")
	public String getLeaveStatus() {
		return leaveStatus;
	}

	@JsonProperty("LevStat")
	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}

	@JsonProperty("regStatus")
	public String getRegStatus() {
		return regStatus;
	}

	@JsonProperty("RegStat")
	public void setRegStatus(String regStatus) {
		this.regStatus = regStatus;
	}

	@JsonProperty("actualIn")
	public Date getActualIn() {
		return actualIn;
	}

	@JsonProperty("ActIn")
	public void setActualIn(String actualInStr) {
		this.actualIn = DateUtil.getDateFromTimeFormat(actualInStr, attStartDate);
	}

	@JsonProperty("actualOut")
	public Date getActualOut() {
		return actualOut;
	}

	@JsonProperty("ActOut")
	public void setActualOut(String actualOutStr) {
		this.actualOut = DateUtil.getDateFromTimeFormat(actualOutStr, attStartDate);
	}

	@JsonProperty("shiftStartTime")
	public Date getShiftStartTime() {
		return shiftStartTime;
	}

	@JsonProperty("ShiftCodeTime")
	public void setShiftStartTime(String shiftTimeStr) {
		this.shiftStartTime = DateUtil.getDateFromNumberFormat(shiftTimeStr, attStartDate, Boolean.TRUE);
		this.shiftEndTime = DateUtil.getDateFromNumberFormat(shiftTimeStr, attStartDate, Boolean.FALSE);
	}

	@JsonProperty("shiftEndTime")
	public Date getShiftEndTime() {
		return shiftEndTime;
	}

	public void setShiftEndTime(Date shiftEndTime) {
		this.shiftEndTime = shiftEndTime;
	}

	@JsonProperty("shiftType")
	public String getShiftType() {
		return shiftType;
	}

	@JsonProperty("ShiftCode")
	public void setShiftType(String shiftType) {
		this.shiftType = shiftType;
	}

	public CalenderCategory getAttCategory() {
		return attCategory;
	}

	public void setAttCategory(CalenderCategory attCategory) {
		this.attCategory = attCategory;
	}

	@JsonProperty("attStatus")
	public String getAttStatus() {
		return attStatus;
	}

	@JsonProperty("AttenStatus")
	public void setAttStatus(String attStatus) {
		this.attStatus = attStatus;
	}

	public String getWeekOfMonth() {
		return weekOfMonth;
	}

	public void setWeekOfMonth(String weekOfMonth) {
		this.weekOfMonth = weekOfMonth;
	}

	@JsonProperty("shiftTime")
	public Double getShiftTime() {
		return shiftTime;
	}

	@JsonProperty("SchHrs")
	public void setShiftTime(Double shiftTime) {
		this.shiftTime = shiftTime;
	}

	@JsonProperty("actualTime")
	public Double getActualTime() {
		return actualTime;
	}

	@JsonProperty("ActHrs")
	public void setActualTime(Double actualTime) {
		this.actualTime = actualTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getLocationDesc() {
		return locationDesc;
	}

	public void setLocationDesc(String locationDesc) {
		this.locationDesc = locationDesc;
	}

	public Date getPlanShiftStartTime() {
		return planShiftStartTime;
	}

	public void setPlanShiftStartTime(Date planShiftStartTime) {
		this.planShiftStartTime = planShiftStartTime;
	}

	public Date getPlanShiftEndTime() {
		return planShiftEndTime;
	}

	public void setPlanShiftEndTime(Date planShiftEndTime) {
		this.planShiftEndTime = planShiftEndTime;
	}

	public Double getMaxWorkingTime() {
		return maxWorkingTime;
	}

	public void setMaxWorkingTime(Double maxWorkingTime) {
		this.maxWorkingTime = maxWorkingTime;
	}

	public Double getMinWorkingTime() {
		return minWorkingTime;
	}

	public void setMinWorkingTime(Double minWorkingTime) {
		this.minWorkingTime = minWorkingTime;
	}

	public Date getToleranceStartTime() {
		return toleranceStartTime;
	}

	public void setToleranceStartTime(Date toleranceStartTime) {
		this.toleranceStartTime = toleranceStartTime;
	}

	public Date getToleranceEndTime() {
		return toleranceEndTime;
	}

	public void setToleranceEndTime(Date toleranceEndTime) {
		this.toleranceEndTime = toleranceEndTime;
	}

	@Override
	public String toString() {
		return "AttendanceDetail [attStartDate=" + attStartDate + ", attEndDate=" + attEndDate + ", actualIn="
				+ actualIn + ", actualOut=" + actualOut + ", shiftStartTime=" + shiftStartTime + ", shiftEndTime="
				+ shiftEndTime + ", shiftTime=" + shiftTime + ", actualTime=" + actualTime + ", colorCode=" + colorCode
				+ ", absFlag=" + absFlag + ", leaveStatus=" + leaveStatus + ", regStatus=" + regStatus + ", attStatus="
				+ attStatus + ", shiftType=" + shiftType + ", attCategory=" + attCategory + ", weekOfMonth="
				+ weekOfMonth + ", userId=" + userId + ", locationCode=" + locationCode + ", locationDesc="
				+ locationDesc + ", planShiftStartTime=" + planShiftStartTime + ", planShiftEndTime=" + planShiftEndTime
				+ ", maxWorkingTime=" + maxWorkingTime + ", minWorkingTime=" + minWorkingTime + ", toleranceStartTime="
				+ toleranceStartTime + ", toleranceEndTime=" + toleranceEndTime + "]";
	}

}