package org.ril.hrss.attendance.client.fallback;

import org.ril.hrss.attendance.client.SapEndpointClient;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getAttendanceDetailsMonthWise(String userId, String month, String year) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}
