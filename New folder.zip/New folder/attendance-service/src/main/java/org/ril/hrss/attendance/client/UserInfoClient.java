package org.ril.hrss.attendance.client;

import org.ril.hrss.attendance.client.fallback.UserInfoFallback;
import org.ril.hrss.attendance.model.UserInfoDetail;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "user-info-service", fallback = UserInfoFallback.class)
public interface UserInfoClient {

	@RequestMapping(value = "/info/{userId}", method = RequestMethod.GET, produces = "application/json")
	UserInfoDetail getUserInfoDetails(@PathVariable("userId") String userId);

}