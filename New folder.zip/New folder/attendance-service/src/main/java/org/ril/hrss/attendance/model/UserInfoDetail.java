package org.ril.hrss.attendance.model;

import java.util.Date;

public class UserInfoDetail {

	private String userId;
	private String locationCode;
	private String locationDesc;
	private String shiftCode;
	private Date planShiftStartTime;
	private Date planShiftEndTime;
	private Date userShiftStartTime;
	private Date userShiftEndTime;
	private Date toleranceStartTime;
	private Date toleranceEndTime;
	private Double planWorkingTime;
	private Double maxWorkingTime;
	private Double minWorkingTime;

	public UserInfoDetail() {
		super();
	}

	public UserInfoDetail(String userId, String locationCode, String locationDesc, String shiftCode,
			Date planShiftStartTime, Date planShiftEndTime, Date userShiftStartTime, Date userShiftEndTime,
			Date toleranceStartTime, Date toleranceEndTime, Double planWorkingTime, Double maxWorkingTime,
			Double minWorkingTime) {
		super();
		this.userId = userId;
		this.locationCode = locationCode;
		this.locationDesc = locationDesc;
		this.shiftCode = shiftCode;
		this.planShiftStartTime = planShiftStartTime;
		this.planShiftEndTime = planShiftEndTime;
		this.userShiftStartTime = userShiftStartTime;
		this.userShiftEndTime = userShiftEndTime;
		this.toleranceStartTime = toleranceStartTime;
		this.toleranceEndTime = toleranceEndTime;
		this.planWorkingTime = planWorkingTime;
		this.maxWorkingTime = maxWorkingTime;
		this.minWorkingTime = minWorkingTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getLocationDesc() {
		return locationDesc;
	}

	public void setLocationDesc(String locationDesc) {
		this.locationDesc = locationDesc;
	}

	public String getShiftCode() {
		return shiftCode;
	}

	public void setShiftCode(String shiftCode) {
		this.shiftCode = shiftCode;
	}

	public Date getPlanShiftStartTime() {
		return planShiftStartTime;
	}

	public void setPlanShiftStartTime(Date planShiftStartTime) {
		this.planShiftStartTime = planShiftStartTime;
	}

	public Date getPlanShiftEndTime() {
		return planShiftEndTime;
	}

	public void setPlanShiftEndTime(Date planShiftEndTime) {
		this.planShiftEndTime = planShiftEndTime;
	}

	public Date getUserShiftStartTime() {
		return userShiftStartTime;
	}

	public void setUserShiftStartTime(Date userShiftStartTime) {
		this.userShiftStartTime = userShiftStartTime;
	}

	public Date getUserShiftEndTime() {
		return userShiftEndTime;
	}

	public void setUserShiftEndTime(Date userShiftEndTime) {
		this.userShiftEndTime = userShiftEndTime;
	}

	public Date getToleranceStartTime() {
		return toleranceStartTime;
	}

	public void setToleranceStartTime(Date toleranceStartTime) {
		this.toleranceStartTime = toleranceStartTime;
	}

	public Date getToleranceEndTime() {
		return toleranceEndTime;
	}

	public void setToleranceEndTime(Date toleranceEndTime) {
		this.toleranceEndTime = toleranceEndTime;
	}

	public Double getPlanWorkingTime() {
		return planWorkingTime;
	}

	public void setPlanWorkingTime(Double planWorkingTime) {
		this.planWorkingTime = planWorkingTime;
	}

	public Double getMaxWorkingTime() {
		return maxWorkingTime;
	}

	public void setMaxWorkingTime(Double maxWorkingTime) {
		this.maxWorkingTime = maxWorkingTime;
	}

	public Double getMinWorkingTime() {
		return minWorkingTime;
	}

	public void setMinWorkingTime(Double minWorkingTime) {
		this.minWorkingTime = minWorkingTime;
	}

	@Override
	public String toString() {
		return "UserInfoDetail [userId=" + userId + ", locationCode=" + locationCode + ", locationDesc=" + locationDesc
				+ ", shiftCode=" + shiftCode + ", planShiftStartTime=" + planShiftStartTime + ", planShiftEndTime="
				+ planShiftEndTime + ", userShiftStartTime=" + userShiftStartTime + ", userShiftEndTime="
				+ userShiftEndTime + ", toleranceStartTime=" + toleranceStartTime + ", toleranceEndTime="
				+ toleranceEndTime + ", planWorkingTime=" + planWorkingTime + ", maxWorkingTime=" + maxWorkingTime
				+ ", minWorkingTime=" + minWorkingTime + "]";
	}

}