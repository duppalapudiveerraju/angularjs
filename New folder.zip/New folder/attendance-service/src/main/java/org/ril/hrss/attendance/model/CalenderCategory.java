package org.ril.hrss.attendance.model;

public enum CalenderCategory {

	REGULARIZE_ONE_TOUCH, REGULARIZE, ABSENT, LEAVE, WEEKLY_OFF, PUBLIC_HOLIDAY, NORMAL, COMPANY_EVENT, PERSONAL_REMINDER;

}
