package org.ril.hrss.attendance.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.attendance.client.SapEndpointClient;
import org.ril.hrss.attendance.client.UserInfoClient;
import org.ril.hrss.attendance.model.AttendanceDetail;
import org.ril.hrss.attendance.model.CalenderCategory;
import org.ril.hrss.attendance.model.CalenderHexColorCode;
import org.ril.hrss.attendance.model.UserInfoDetail;
import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;

@RefreshScope
@Component
public class AttendanceUtil {

	protected static final Logger logger = Logger.getLogger(AttendanceUtil.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private UserInfoClient userInfoClient;

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	@Value("${attendance.flexi.shift:null}")
	private String flexiShiftStr;

	private List<String> flexiShiftList;

	public AttendanceUtil() {
		super();
	}

	public UserInfoDetail getUserInfoObj(String userId) {
		logger.info("attendance.getUserInfoObj()");
		return userInfoClient.getUserInfoDetails(userId);
	}

	public boolean isFlexiShift(String shiftCode) {
		logger.info("attendance.isFlexiShift()");
		flexiShiftList = Arrays.asList(flexiShiftStr.split(HRSSConstantUtil.COMMA));
		if (flexiShiftList.contains(shiftCode)) {
			return true;
		} else {
			return false;
		}
	}

	@SuppressWarnings("deprecation")
	public List<AttendanceDetail> getFlexiAttendanceDetail(String userId, String month, String year,
			UserInfoDetail userInfoObj) {
		logger.info("attendance.getFlexiAttendanceDetail()");
		Date obj = new Date();
		int curMonth = DateUtil.getActualMonth(obj.getMonth());
		int curYear = DateUtil.getActualYear(obj.getYear());
		CompletableFuture<String> prevMonthStr = null;
		CompletableFuture<String> monthStr = null;
		CompletableFuture<String> nextMonthStr = null;
		List<AttendanceDetail> result = null;
		if (Integer.parseInt(year) == curYear) {
			if (Integer.parseInt(month) < curMonth) {
				prevMonthStr = setPrevMonthString(userId, month, year);
				monthStr = setCurMonthString(userId, month, year);
				nextMonthStr = setNextMonthString(userId, month, year);
				CompletableFuture.allOf(prevMonthStr, monthStr, nextMonthStr).join();
				result = setFinalAttendanceList(prevMonthStr, monthStr, nextMonthStr, month, userId, userInfoObj);
				return result;
			} else if (Integer.parseInt(month) > curMonth) {
				monthStr = setCurMonthString(userId, month, year);
				CompletableFuture.allOf(monthStr).join();
				result = setFinalAttendanceList(null, monthStr, null, month, userId, userInfoObj);
				return result;
			} else {
				prevMonthStr = setPrevMonthString(userId, month, year);
				monthStr = setCurMonthString(userId, month, year);
				CompletableFuture.allOf(prevMonthStr, monthStr).join();
				result = setFinalAttendanceList(prevMonthStr, monthStr, null, month, userId, userInfoObj);
				return result;
			}
		} else if (Integer.parseInt(year) > curYear) {
			monthStr = setCurMonthString(userId, month, year);
			CompletableFuture.allOf(monthStr).join();
			result = setFinalAttendanceList(null, monthStr, null, month, userId, userInfoObj);
			return result;
		} else {
			prevMonthStr = setPrevMonthString(userId, month, year);
			monthStr = setCurMonthString(userId, month, year);
			nextMonthStr = setNextMonthString(userId, month, year);
			CompletableFuture.allOf(prevMonthStr, monthStr, nextMonthStr).join();
			result = setFinalAttendanceList(prevMonthStr, monthStr, nextMonthStr, month, userId, userInfoObj);
			return result;
		}
	}

	public List<AttendanceDetail> getNonFlexiAttendanceDetail(String userId, String month, String year,
			UserInfoDetail userInfoObj) {
		logger.info("attendance.getNonFlexiAttendanceDetail()");
		CompletableFuture<String> monthStr = setCurMonthString(userId, month, year);
		return setFinalAttendanceList(null, monthStr, null, month, userId, userInfoObj);
	}

	private List<AttendanceDetail> getAttendanceList(String feed, String userId) {
		logger.info("attendance.getAttendanceList()");
		List<AttendanceDetail> list = new ArrayList<AttendanceDetail>();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapperUtil.get().readTree(feed);
				list = objectMapperUtil.get().readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<AttendanceDetail>>() {
						});
			}
		} catch (JsonParseException e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
		} catch (JsonMappingException e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
		} catch (IOException e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
		}
		return list;
	}

	private List<AttendanceDetail> processListOfOneTouchWorkWeek(List<AttendanceDetail> list) {
		logger.info("attendance.processListOfOneTouchWorkWeek()");
		if (list != null) {
			Optional<AttendanceDetail> obj = list.parallelStream()
					.filter(e -> !e.getAttCategory().equals(CalenderCategory.WEEKLY_OFF)
							&& !e.getAttCategory().equals(CalenderCategory.PUBLIC_HOLIDAY)
							&& e.getAttStatus().contains(HRSSConstantUtil.SAP_ATTENDANCE_PROCESSED))
					.findFirst();
			AttendanceDetail optionalObj = new AttendanceDetail();
			optionalObj.setShiftTime(HRSSConstantUtil.DEFAULT_SHIFT_TIME);
			obj.orElse(optionalObj);
			return list.parallelStream().filter(e -> e.getAttCategory().equals(CalenderCategory.WEEKLY_OFF))
					.filter(e -> e.getShiftTime() > HRSSConstantUtil.ZERO && e.getActualTime() < e.getShiftTime()
							&& (e.getAttStatus().trim().equals(HRSSConstantUtil.WEEKLY_OFF_SHFALL_IDENTIFIER)
									|| e.getAttStatus().trim().equals(HRSSConstantUtil.WEEKLY_OFF_PROCESSED)))
					.filter(e -> e.getActualTime() >= ((obj.get().getShiftTime()
							* (e.getShiftTime() / obj.get().getShiftTime()))
							- (e.getShiftTime() / obj.get().getShiftTime())))
					.collect(Collectors.toList());
		} else {
			return new ArrayList<>();
		}
	}

	private List<AttendanceDetail> processListOfNormalWorkWeek(List<AttendanceDetail> list) {
		logger.info("attendance.processListOfNormalWorkWeek()");
		if (list != null) {
			return list.parallelStream().filter(e -> e.getAttCategory().equals(CalenderCategory.WEEKLY_OFF))
					.filter(e -> e.getShiftTime() > HRSSConstantUtil.ZERO && e.getActualTime() >= e.getShiftTime()
							&& e.getAttStatus().trim().equals(HRSSConstantUtil.WEEKLY_OFF_ATT_STATUS))
					.collect(Collectors.toList());
		} else {
			return new ArrayList<>();
		}
	}

	private Map<String, List<AttendanceDetail>> processMapOfWorkDays(List<AttendanceDetail> list) {
		logger.info("attendance.processMapOfWorkDays()");
		if (list != null) {
			return list.parallelStream()
					.filter(e -> !e.getAttCategory().equals(CalenderCategory.PUBLIC_HOLIDAY)
							&& !e.getAttCategory().equals(CalenderCategory.WEEKLY_OFF)
							&& !e.getAttCategory().equals(CalenderCategory.LEAVE))
					.collect(Collectors.groupingBy(AttendanceDetail::getWeekOfMonth));
		} else {
			return new HashMap<String, List<AttendanceDetail>>();
		}
	}

	private void setOneTouchDays(final List<AttendanceDetail> actualList) {
		logger.info("attendance.setOneTouchDays()");
		if (isFlexiShift(actualList.get(HRSSConstantUtil.ZERO.intValue()).getShiftType())) {
			List<AttendanceDetail> listOfOneTouchWeekOff = processListOfOneTouchWorkWeek(actualList);
			Map<String, List<AttendanceDetail>> mapOfWorkWeek = processMapOfWorkDays(actualList);
			if (!listOfOneTouchWeekOff.isEmpty() && !mapOfWorkWeek.isEmpty()) {
				for (AttendanceDetail obj : listOfOneTouchWeekOff) {
					long shWeek = getShiftTime(obj) - getActualTime(obj);
					if (mapOfWorkWeek.containsKey(obj.getWeekOfMonth())) {
						for (AttendanceDetail curDayObj : mapOfWorkWeek.get(obj.getWeekOfMonth())) {
							Optional<AttendanceDetail> actualObj = actualList.parallelStream()
									.filter(e -> e.getAttStartDate().equals(curDayObj.getAttStartDate())).findFirst();
							if (actualObj.isPresent()) {
								if (shWeek > HRSSConstantUtil.ZERO
										&& actualObj.get().getActualTime() < actualObj.get().getShiftTime()
										&& !actualObj.get().isAbsFlag()) {
									shWeek = shWeek - (getShiftTime(curDayObj) - getActualTime(curDayObj));
									actualObj.get().setAttCategory(CalenderCategory.REGULARIZE_ONE_TOUCH);
									actualObj.get()
											.setColorCode(CalenderHexColorCode.REGULARIZE_ONE_TOUCH.getHexColorCode());
								} else if (actualObj.get().isAbsFlag()) {
									shWeek = shWeek - (getShiftTime(curDayObj) - getActualTime(curDayObj));
								} else {
									actualObj.get().setAttCategory(CalenderCategory.NORMAL);
									actualObj.get().setColorCode(CalenderHexColorCode.NORMAL.getHexColorCode());
								}
							}
						}
					}
				}
			}
		}
	}

	private void setNormalDays(final List<AttendanceDetail> actualList) {
		logger.info("attendance.setNormalDays()");
		if (isFlexiShift(actualList.get(HRSSConstantUtil.ZERO.intValue()).getShiftType())) {
			List<AttendanceDetail> listOfNormalWeekOff = processListOfNormalWorkWeek(actualList);
			Map<String, List<AttendanceDetail>> mapOfWorkWeek = processMapOfWorkDays(actualList);
			if (!listOfNormalWeekOff.isEmpty() && !mapOfWorkWeek.isEmpty()) {
				for (AttendanceDetail obj : listOfNormalWeekOff) {
					if (mapOfWorkWeek.containsKey(obj.getWeekOfMonth())) {
						for (AttendanceDetail curDayObj : mapOfWorkWeek.get(obj.getWeekOfMonth())) {
							Optional<AttendanceDetail> actualObj = actualList.parallelStream()
									.filter(e -> e.getAttStartDate().equals(curDayObj.getAttStartDate())).findFirst();
							if (actualObj.isPresent()
									&& curDayObj.getAttCategory().equals(CalenderCategory.REGULARIZE)) {
								actualObj.get().setAttCategory(CalenderCategory.NORMAL);
							}
						}
					}
				}
			}
		}
	}

	private void setNonFlexiRegDays(List<AttendanceDetail> actualList) {
		logger.info("attendance.setNonFlexiRegDays()");
		if (!isFlexiShift(actualList.get(HRSSConstantUtil.ZERO.intValue()).getShiftType())) {
			List<AttendanceDetail> listOfRegDays = actualList.parallelStream()
					.filter(e -> e.getAttCategory().equals(CalenderCategory.REGULARIZE)
							&& e.getToleranceStartTime() != null && e.getToleranceStartTime() != null
							&& e.getToleranceEndTime().after(e.getToleranceStartTime()))
					.collect(Collectors.toList());
			for (AttendanceDetail regDayObj : listOfRegDays) {
				Optional<AttendanceDetail> actualObj = actualList.parallelStream()
						.filter(e -> e.getAttStartDate().equals(regDayObj.getAttStartDate())).findFirst();
				if (actualObj.isPresent()) {
					long shiftMillis = DateUtil.getMilsecFromDouble(actualObj.get().getShiftTime());
					long actualMillis = DateUtil.getMilsecFromDouble(actualObj.get().getActualTime());
					long tolMillis = actualObj.get().getToleranceEndTime().getTime()
							- actualObj.get().getToleranceStartTime().getTime();
					if ((actualMillis + tolMillis) >= shiftMillis) {
						actualObj.get().setAttCategory(CalenderCategory.NORMAL);
					}
				}
			}
		}
	}

	private void setShiftMaster(List<AttendanceDetail> result, UserInfoDetail userInfoObj) {
		logger.info("attendance.setShiftMaster()");
		if (result != null && userInfoObj != null) {
			result.parallelStream().forEach(e -> BeanUtils.copyProperties(userInfoObj, e));
			List<AttendanceDetail> listOfNormalWorkDays = result.parallelStream()
					.filter(e -> !e.getAttCategory().equals(CalenderCategory.WEEKLY_OFF)
							&& !e.getAttCategory().equals(CalenderCategory.PUBLIC_HOLIDAY)
							&& (e.getShiftTime() == null || e.getShiftTime().equals(HRSSConstantUtil.ZERO)
									|| (e.getActualTime() == null || e.getActualTime().equals(HRSSConstantUtil.ZERO)))
							&& e.getActualIn() != null && e.getActualOut() != null)
					.collect(Collectors.toList());
			for (AttendanceDetail workDayObj : listOfNormalWorkDays) {
				Optional<AttendanceDetail> actualObj = result.parallelStream()
						.filter(e -> e.getAttStartDate().equals(workDayObj.getAttStartDate())).findFirst();
				if (actualObj.isPresent()) {
					AttendanceDetail obj = actualObj.get();
					setShiftTime(obj);
					setActualTime(obj);
				}
			}
		}
	}

	private void setShiftTime(AttendanceDetail obj) {
		logger.info("attendance.setShiftTime()");
		obj.setShiftTime(DateUtil.getDoubleFromDateTime(obj.getShiftStartTime(), obj.getShiftEndTime()));
	}

	private void setActualTime(AttendanceDetail obj) {
		logger.info("attendance.setActualTime()");
		Date dateStart = null;
		Date dateEnd = null;
		if (!isFlexiShift(obj.getShiftType())) {
			if (obj.getActualIn().equals(obj.getActualOut())) {
				obj.setActualTime(HRSSConstantUtil.ZERO);
			} else if (obj.getShiftStartTime().before(obj.getShiftEndTime())
					|| obj.getShiftStartTime().equals(obj.getShiftEndTime())) {
				dateStart = obj.getShiftStartTime().after(obj.getActualIn()) ? obj.getShiftStartTime()
						: obj.getActualIn();
				dateEnd = obj.getShiftEndTime().before(obj.getActualOut()) ? obj.getShiftEndTime() : obj.getActualOut();
				obj.setActualTime(DateUtil.getDoubleFromDateTime(dateStart, dateEnd));
			} else {
				dateStart = obj.getShiftStartTime().after(obj.getActualIn()) ? obj.getShiftStartTime()
						: obj.getActualIn();
				long dateEndMillis = obj.getShiftEndTime().before(obj.getActualOut()) ? obj.getShiftEndTime().getTime()
						: obj.getActualOut().getTime();
				dateEnd = new Date(dateEndMillis + DateUtil.getDaysOffset(1));
				obj.setActualTime(DateUtil.getDoubleFromDateTime(dateStart, dateEnd));
			}
		}
	}

	private void setWeeklyData(List<AttendanceDetail> result) {
		logger.info("attendance.setWeeklyData()");
		if (isFlexiShift(result.get(HRSSConstantUtil.ZERO.intValue()).getShiftType())) {
			result = result.parallelStream().sorted((o1, o2) -> o1.getAttStartDate().compareTo(o2.getAttStartDate()))
					.collect(Collectors.toList());
			Double counter = HRSSConstantUtil.ZERO;
			for (AttendanceDetail obj : result) {
				if (obj.getAttCategory().equals(CalenderCategory.WEEKLY_OFF)) {
					obj.setShiftTime(counter);
					counter = HRSSConstantUtil.ZERO;
				} else {
					counter += obj.getShiftTime();
				}
			}
		}
	}

	private long getShiftTime(AttendanceDetail obj) {
		logger.info("attendance.getShiftTime()");
		return DateUtil.getMilsecFromDouble(obj.getShiftTime());
	}

	private long getActualTime(AttendanceDetail obj) {
		logger.info("attendance.getActualTime()");
		return DateUtil.getMilsecFromDouble(obj.getActualTime());
	}

	private List<AttendanceDetail> setFinalAttendanceList(CompletableFuture<String> prevMonthStr,
			CompletableFuture<String> monthStr, CompletableFuture<String> nextMonthStr, String month, String userId,
			UserInfoDetail userInfoObj) {
		logger.info("attendance.setFinalAttendanceList()");
		List<AttendanceDetail> result = new ArrayList<AttendanceDetail>();
		try {
			result.addAll(getAttendanceList(monthStr.get(), userId));
			if (prevMonthStr != null) {
				List<AttendanceDetail> prevMonthList = getAttendanceList(prevMonthStr.get(), userId);
				result.addAll(prevMonthList.parallelStream()
						.skip((long) (prevMonthList.size() - HRSSConstantUtil.NO_OF_DAYS_IN_WEEK))
						.collect(Collectors.toList()));
			}
			if (nextMonthStr != null) {
				List<AttendanceDetail> nextMonthList = getAttendanceList(nextMonthStr.get(), userId);
				result.addAll(nextMonthList.parallelStream().limit(HRSSConstantUtil.NO_OF_DAYS_IN_WEEK)
						.collect(Collectors.toList()));
			}
		} catch (InterruptedException | ExecutionException e) {
			logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
		}
		setShiftMaster(result, userInfoObj);
		setWeeklyData(result);
		setNormalDays(result);
		setOneTouchDays(result);
		setNonFlexiRegDays(result);
		int monthInt = Integer.parseInt(month);
		Calendar cal = Calendar.getInstance();
		return result.stream().filter(e -> {
			cal.setTime(e.getAttStartDate());
			if (monthInt == DateUtil.getActualMonth(cal.get(Calendar.MONTH))) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}
		}).sorted((o1, o2) -> o1.getAttStartDate().compareTo(o2.getAttStartDate())).collect(Collectors.toList());
	}

	private CompletableFuture<String> setPrevMonthString(String userId, String month, String year) {
		logger.info("attendance.setPrevMonthString()");
		return CompletableFuture.supplyAsync(new Supplier<String>() {
			@Override
			public String get() {
				return sapEndpointClient.getAttendanceDetailsMonthWise(userId, DateUtil.getPrevMonthStr(month),
						DateUtil.getPrevYearStr(month, year));
			}
		});
	}

	private CompletableFuture<String> setCurMonthString(String userId, String month, String year) {
		logger.info("attendance.setCurMonthString()");
		return CompletableFuture.supplyAsync(new Supplier<String>() {
			@Override
			public String get() {
				return sapEndpointClient.getAttendanceDetailsMonthWise(userId, month, year);
			}
		});
	}

	private CompletableFuture<String> setNextMonthString(String userId, String month, String year) {
		logger.info("attendance.setNextMonthString()");
		return CompletableFuture.supplyAsync(new Supplier<String>() {
			@Override
			public String get() {
				return sapEndpointClient.getAttendanceDetailsMonthWise(userId, DateUtil.getNextMonthStr(month),
						DateUtil.getNextYearStr(month, year));
			}
		});
	}

}