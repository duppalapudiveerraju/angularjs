package org.ril.hrss.attendance.api;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.attendance.interfaces.AttendanceServiceRepo;
import org.ril.hrss.attendance.model.AttendanceDetail;
import org.ril.hrss.attendance.model.CalenderCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/attendance")
@Api(value = "Attendance details", description = "Operations pertaining to find Attendance details")
public class ApplicationController {

	@Autowired
	private AttendanceServiceRepo attendanceServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/details/userId/{userId}/filter/{month}/{year}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of attendance details of specified month/year", response = Map.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public Map<CalenderCategory, List<AttendanceDetail>> getAttendanceDetails(@PathVariable("userId") String userId,
			@PathVariable("month") String month, @PathVariable("year") String year) throws ClientException {
		logger.info("attendance.getAttendanceDetails()");
		List<AttendanceDetail> result = attendanceServiceRepo.getAllAttendanceDetail(userId, month, year);
		return attendanceServiceRepo.setRegAbsentGrouping(
				result.parallelStream().collect(Collectors.groupingBy(AttendanceDetail::getAttCategory)));
	}

	@RequestMapping(value = "/details/day/list/userId/{userId}/filter/{month}/{year}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of attendance details of specified month/year", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<AttendanceDetail> getAttendanceDetailsMonthWise(@PathVariable("userId") String userId,
			@PathVariable("month") String month, @PathVariable("year") String year) throws ClientException {
		logger.info("attendance.getAttendanceDetailsMonthWise()");
		return attendanceServiceRepo.getAllAttendanceDetail(userId, month, year);
	}

	@RequestMapping(value = "/offDays/{userId}/{month}/{year}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of non working attendance day details of specified month/year", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<Date> getNonWorkingDaysMonthwise(@PathVariable("userId") String userId,
			@PathVariable("month") String month, @PathVariable("year") String year) throws ClientException {
		logger.info("attendance.getNonWorkingDaysMonthwise()");
		return attendanceServiceRepo.getNonWorkingDaysMonthwise(userId, month, year);
	}

}