package org.ril.hrss.financial.utility.client.fallback;

import org.ril.hrss.financial.utility.client.SapEndpointClient;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public ResponseEntity<ByteArrayResource> getTaxDetails(String userId, String month, String year) {
		return new ResponseEntity<ByteArrayResource>(HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ByteArrayResource> getCtcDetails(String userId) {
		return new ResponseEntity<ByteArrayResource>(HttpStatus.OK);
	}

	@Override
	public String getRetiralDetails(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}