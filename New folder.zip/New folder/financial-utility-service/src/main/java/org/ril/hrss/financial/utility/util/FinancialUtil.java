package org.ril.hrss.financial.utility.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.financial.utility.model.RetiralDetails;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class FinancialUtil {

	protected static final Logger logger = Logger.getLogger(FinancialUtil.class.getName());

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public List<RetiralDetails> getRetiralDetails(String feed) {
		logger.info("FinancialUtil.getRetiralDetails()");
		List<RetiralDetails> list = new ArrayList<RetiralDetails>();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapperUtil.get().readTree(feed);
				list = objectMapperUtil.get().readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<RetiralDetails>>() {
						});
			}
		} catch (JsonParseException e) {
			logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
		} catch (JsonMappingException e) {
			logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
		} catch (IOException e) {
			logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
		}
		return list;
	}

	public ResponseEntity<ByteArrayResource> getDocFromResourceStream(ByteArrayResource resource) {
		logger.info("FinancialUtil.getDocFromResourceStream()");
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION,
						HRSSConstantUtil.HTTP_HEADER_FILE_ATTACHMENT + HRSSConstantUtil.SEMI_COLON
								+ HRSSConstantUtil.HTTP_HEADER_FILE_NAME + HRSSConstantUtil.STRING_EQUAL
								+ resource.getFilename())
				.contentType(MediaType.APPLICATION_PDF).contentLength(resource.contentLength()).body(resource);
	}

}