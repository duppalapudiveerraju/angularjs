package org.ril.hrss.financial.utility.interfaces;

import java.util.List;

import org.ril.hrss.financial.utility.model.RetiralDetails;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

public interface FinancialUtilityRepo {

	public ResponseEntity<ByteArrayResource> getTaxDetails(String userId, String month, String year);

	public ResponseEntity<ByteArrayResource> getCtcDetails(String userId);

	public List<RetiralDetails> getRetiralDetails(String userId);
	
}