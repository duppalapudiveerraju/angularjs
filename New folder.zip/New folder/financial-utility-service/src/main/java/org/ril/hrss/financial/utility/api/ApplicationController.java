package org.ril.hrss.financial.utility.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.financial.utility.interfaces.FinancialUtilityRepo;
import org.ril.hrss.financial.utility.model.RetiralDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import feign.FeignException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Financial Utility Service details", description = "Operations pertaining to Financial Utility details")
public class ApplicationController {

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());
	
	@Autowired
	private FinancialUtilityRepo financialUtilityRepo;

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/tax/{month}/{year}", method = RequestMethod.GET, produces = "application/octet-stream")
	@ApiOperation(value = "Get HR Utility Tax Details", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrived HR Utility Tax Details"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<ByteArrayResource> getTaxDetails(@NotNull @RequestHeader("userId") String userId,
			@NotNull @PathVariable("month") String month, @NotNull @PathVariable("year") String year)
			throws FeignException, ClientException {
		logger.info("ApplicationController.getTaxDetails()");
		return financialUtilityRepo.getTaxDetails(userId, month, year);
	}

	@RequestMapping(value = "/ctc", method = RequestMethod.GET, produces = "application/octet-stream")
	@ApiOperation(value = "Get HR Utility CTC Details", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrived HR Utility CTC Details"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<ByteArrayResource> getCtcDetails(@NotNull @RequestHeader("userId") String userId)
			throws FeignException, ClientException {
		logger.info("ApplicationController.getCtcDetails()");
		return financialUtilityRepo.getCtcDetails(userId);
	}

	@RequestMapping(value = "/retirals", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get HR Utility retiral Details", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrived HR Utility retiral Details"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<RetiralDetails> getRetiralDetails(@NotNull @RequestHeader("userId") String userId)
			throws FeignException, ClientException {
		logger.info("ApplicationController.getRetiralDetails()");
		return financialUtilityRepo.getRetiralDetails(userId);
	}

}