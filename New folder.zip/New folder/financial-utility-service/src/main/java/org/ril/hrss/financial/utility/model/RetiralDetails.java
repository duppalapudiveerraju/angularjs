package org.ril.hrss.financial.utility.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RetiralDetails {

	private String retiralType;
	private Double retiralAmount;

	public RetiralDetails() {
		super();
	}

	public RetiralDetails(String retiralType, Double retiralAmount) {
		this();
		this.retiralType = retiralType;
		this.retiralAmount = retiralAmount;
	}

	@JsonProperty("retiralType")
	public String getRetiralType() {
		return retiralType;
	}

	@JsonProperty("TYPE")
	public void setRetiralType(String retiralType) {
		this.retiralType = retiralType;
	}

	@JsonProperty("retiralAmount")
	public Double getRetiralAmount() {
		return retiralAmount;
	}

	@JsonProperty("AMOUNT")
	public void setRetiralAmount(Double retiralAmount) {
		this.retiralAmount = retiralAmount;
	}

	@Override
	public String toString() {
		return "RetiralDetails [retiralType=" + retiralType + ", retiralAmount=" + retiralAmount + "]";
	}

}