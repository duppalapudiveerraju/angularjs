package org.ril.hrss.financial.utility.service;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.financial.utility.client.SapEndpointClient;
import org.ril.hrss.financial.utility.interfaces.FinancialUtilityRepo;
import org.ril.hrss.financial.utility.model.RetiralDetails;
import org.ril.hrss.financial.utility.util.FinancialUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class FinancialUtilityService implements FinancialUtilityRepo {

	protected static final Logger logger = Logger.getLogger(FinancialUtilityService.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private FinancialUtil financialUtil;

	@Override
	public ResponseEntity<ByteArrayResource> getTaxDetails(String userId, String month, String year) {
		return financialUtil.getDocFromResourceStream(sapEndpointClient.getTaxDetails(userId, month, year).getBody());
	}

	@Override
	public ResponseEntity<ByteArrayResource> getCtcDetails(String userId) {
		return financialUtil.getDocFromResourceStream(sapEndpointClient.getCtcDetails(userId).getBody());
	}

	@Override
	public List<RetiralDetails> getRetiralDetails(String userId) {
		return financialUtil.getRetiralDetails(sapEndpointClient.getRetiralDetails(userId));
	}

}