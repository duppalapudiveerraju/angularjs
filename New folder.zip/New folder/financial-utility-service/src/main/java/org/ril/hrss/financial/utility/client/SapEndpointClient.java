package org.ril.hrss.financial.utility.client;

import javax.validation.constraints.NotNull;

import org.ril.hrss.financial.utility.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(value = "/sap/financial/tax/{month}/{year}", method = RequestMethod.GET, produces = "application/octet-stream")
	ResponseEntity<ByteArrayResource> getTaxDetails(@NotNull @RequestHeader("userId") String userId,
			@NotNull @PathVariable("month") String month, @NotNull @PathVariable("year") String year);
	
	@RequestMapping(value = "/sap/financial/ctc", method = RequestMethod.GET, produces = "application/octet-stream")
	ResponseEntity<ByteArrayResource> getCtcDetails(@NotNull @RequestHeader("userId") String userId);
	
	@RequestMapping(value = "/sap/financial/retirals", method = RequestMethod.GET, produces = "application/json")
	String getRetiralDetails(@NotNull @RequestHeader("userId") String userId);

}