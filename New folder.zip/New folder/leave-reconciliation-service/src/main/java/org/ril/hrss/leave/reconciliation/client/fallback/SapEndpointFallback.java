package org.ril.hrss.leave.reconciliation.client.fallback;

import org.ril.hrss.leave.reconciliation.client.SapEndpointClient;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getLeaveReconciliationInfo(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public String getLeaveReconciliationDetails(String userId, String quotaType, String leaveCode) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public String getLeaveReconciliationCrAvFlag(String userId, String id) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}