package org.ril.hrss.leave.reconciliation.model;

import org.ril.hrss.msf.custom.serializer.StrToDoubleSerializer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LeaveReconciliationInfoResponse {

	private String leaveCode;
	private String quotaType;
	private String leaveText;
	private String leaveGroup;
	private Double totalEarn;
	private Double totalAvail;
	private Double appToAvail;
	private Double balance;
	private Double pendApproval;
	private String flagCredited;

	public LeaveReconciliationInfoResponse() {
		super();
	}

	public LeaveReconciliationInfoResponse(String leaveCode, String quotaType, String leaveText, String leaveGroup,
			Double totalEarn, Double totalAvail, Double appToAvail, Double balance, Double pendApproval,
			String flagCredited) {
		this();
		this.leaveCode = leaveCode;
		this.quotaType = quotaType;
		this.leaveText = leaveText;
		this.setLeaveGroup(leaveGroup);
		this.totalEarn = totalEarn;
		this.totalAvail = totalAvail;
		this.appToAvail = appToAvail;
		this.balance = balance;
		this.pendApproval = pendApproval;
		this.flagCredited = flagCredited;
	}

	@JsonProperty("leaveCode")
	public String getLeaveCode() {
		return leaveCode;
	}

	@JsonProperty("LeaveCode")
	public void setLeaveCode(String leaveCode) {
		this.leaveCode = leaveCode;
	}

	@JsonProperty("quotaType")
	public String getQuotaType() {
		return quotaType;
	}

	@JsonProperty("QuotaType")
	public void setQuotaType(String quotaType) {
		this.quotaType = quotaType;
	}

	@JsonProperty("leaveText")
	public String getLeaveText() {
		return leaveText;
	}

	@JsonProperty("LeaveText")
	public void setLeaveText(String leaveText) {
		this.leaveText = leaveText;
	}

	@JsonProperty("totalEarn")
	public Double getTotalEarn() {
		return totalEarn;
	}

	@JsonProperty("TotalEarn")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setTotalEarn(Double totalEarn) {
		this.totalEarn = totalEarn;
	}

	@JsonProperty("totalAvail")
	public Double getTotalAvail() {
		return totalAvail;
	}

	@JsonProperty("TotalAvail")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setTotalAvail(Double totalAvail) {
		this.totalAvail = totalAvail;
	}

	@JsonProperty("appToAvail")
	public Double getAppToAvail() {
		return appToAvail;
	}

	@JsonProperty("AppToAvail")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setAppToAvail(Double appToAvail) {
		this.appToAvail = appToAvail;
	}

	@JsonProperty("balance")
	public Double getBalance() {
		return balance;
	}

	@JsonProperty("Balance")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setBalance(Double balance) {
		this.balance = balance;
	}

	@JsonProperty("pendApproval")
	public Double getPendApproval() {
		return pendApproval;
	}

	@JsonProperty("PendApproval")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setPendApproval(Double pendApproval) {
		this.pendApproval = pendApproval;
	}

	@JsonProperty("flagCredited")
	public String getFlagCredited() {
		return flagCredited;
	}

	@JsonProperty("FlagCredited")
	public void setFlagCredited(String flagCredited) {
		this.flagCredited = flagCredited;
	}

	@JsonIgnore
	public String getLeaveGroup() {
		return leaveGroup;
	}

	public void setLeaveGroup(String leaveGroup) {
		this.leaveGroup = leaveGroup;
	}

	@Override
	public String toString() {
		return "LeaveReconciliationInfoResponse [leaveCode=" + leaveCode + ", quotaType=" + quotaType + ", leaveText="
				+ leaveText + ", totalEarn=" + totalEarn + ", totalAvail=" + totalAvail + ", appToAvail=" + appToAvail
				+ ", balance=" + balance + ", pendApproval=" + pendApproval + ", flagCredited=" + flagCredited + "]";
	}

}