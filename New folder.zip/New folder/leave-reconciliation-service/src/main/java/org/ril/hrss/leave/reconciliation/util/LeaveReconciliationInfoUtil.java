package org.ril.hrss.leave.reconciliation.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationCrAvResponse;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationDetailResponse;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationInfoResponse;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RefreshScope
@Component
public class LeaveReconciliationInfoUtil {

	protected static final Logger logger = Logger.getLogger(LeaveReconciliationInfoUtil.class.getName());

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	@Value("${util.leaveMapStr}")
	private String leaveMapStr;
	
	public LeaveReconciliationInfoUtil() {
		super();
	}

	private Map<String, String> setLeaveMap() {
		return (Map<String, String>) Arrays.asList(leaveMapStr.split(HRSSConstantUtil.COMMA)).stream()
				.map(s -> s.split(HRSSConstantUtil.COLON)).collect(Collectors
						.toMap(e -> e[HRSSConstantUtil.ZERO.intValue()], e -> e[HRSSConstantUtil.ONE.intValue()]));
	}

	public Map<String, List<LeaveReconciliationInfoResponse>> getLeaveReconciliationInfoDetail(String feed) {
		logger.info("LeaveReconciliationInfoUtil.getLeaveReconciliationInfoDetail()");
		List<LeaveReconciliationInfoResponse> leaveReconcilitionInfoObj = new ArrayList<>();
		Map<String, List<LeaveReconciliationInfoResponse>> leaveReconcilitionResp = new HashMap<>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		Map<String, String> leaveMap = setLeaveMap();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapper.readTree(feed);
				leaveReconcilitionInfoObj = objectMapper.readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<LeaveReconciliationInfoResponse>>() {
						});
				leaveReconcilitionInfoObj.parallelStream().forEach(e -> {
					e.setLeaveGroup(leaveMap.get(e.getLeaveText()));
				});
				leaveReconcilitionResp = leaveReconcilitionInfoObj.parallelStream()
						.collect(Collectors.groupingBy(LeaveReconciliationInfoResponse::getLeaveGroup));
			}
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return leaveReconcilitionResp;
	}

	public List<LeaveReconciliationDetailResponse> getLeaveReconciliationDetail(String feed) {
		logger.info("LeaveReconciliationInfoUtil.getLeaveReconciliationDetail()");
		List<LeaveReconciliationDetailResponse> leaveReconcilitionDetailObj = new ArrayList<>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapper.readTree(feed);
				leaveReconcilitionDetailObj = objectMapper.readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<LeaveReconciliationDetailResponse>>() {
						});
			}
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return leaveReconcilitionDetailObj;
	}

	public List<LeaveReconciliationCrAvResponse> getLeaveReconciliationCrAvDetail(String feed) {
		logger.info("LeaveReconciliationInfoUtil.getLeaveReconciliationCrAvDetail()");
		List<LeaveReconciliationCrAvResponse> leaveReconcilitionCrAvDetailObj = new ArrayList<>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapper.readTree(feed);
				leaveReconcilitionCrAvDetailObj = objectMapper.readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<LeaveReconciliationCrAvResponse>>() {
						});
			}
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return leaveReconcilitionCrAvDetailObj;
	}

}