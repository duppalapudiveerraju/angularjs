package org.ril.hrss.leave.reconciliation.service;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.ril.hrss.leave.reconciliation.client.SapEndpointClient;
import org.ril.hrss.leave.reconciliation.interfaces.LeaveReconciliationServiceRepo;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationCrAvResponse;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationDetailResponse;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationInfoResponse;
import org.ril.hrss.leave.reconciliation.util.LeaveReconciliationInfoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.netflix.client.ClientException;

import feign.FeignException;

@Service
public class LeaveReconciliationInfoService implements LeaveReconciliationServiceRepo {

	protected static final Logger logger = Logger.getLogger(LeaveReconciliationInfoUtil.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	public LeaveReconciliationInfoUtil leaveInfoUtil;

	@Override
	public Map<String, List<LeaveReconciliationInfoResponse>> getleaveInfo(String userId)
			throws ClientException, FeignException {
		logger.info("LeaveReconciliationInfoService.getleaveInfo()");
		return leaveInfoUtil.getLeaveReconciliationInfoDetail(sapEndpointClient.getLeaveReconciliationInfo(userId));
	}

	@Override
	public List<LeaveReconciliationDetailResponse> getleaveDetail(String userId, String leaveCode, String quotaType)
			throws ClientException, FeignException {
		logger.info("LeaveReconciliationInfoService.getleaveDetail()");
		return leaveInfoUtil.getLeaveReconciliationDetail(
				sapEndpointClient.getLeaveReconciliationDetails(userId, leaveCode, quotaType));
	}

	@Override
	public List<LeaveReconciliationCrAvResponse> getleaveCrAvDetail(String userId, String id) {
		logger.info("LeaveReconciliationInfoService.getleaveCrAvDetail()");
		return leaveInfoUtil
				.getLeaveReconciliationCrAvDetail(sapEndpointClient.getLeaveReconciliationCrAvFlag(userId, id));
	}

}