package org.ril.hrss.leave.reconciliation.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;
import org.ril.hrss.msf.custom.serializer.StrToDoubleSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LeaveReconciliationCrAvResponse {

	private String availed;
	private String leaveText;
	private Date fromDate;
	private Date toDate;
	private Double noOfDays;

	public LeaveReconciliationCrAvResponse() {
		super();
	}

	public LeaveReconciliationCrAvResponse(String availed, String leaveText, Date fromDate, Date toDate,
			Double noOfDays) {
		this();
		this.availed = availed;
		this.leaveText = leaveText;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.noOfDays = noOfDays;
	}

	@JsonProperty("availed")
	public String getAvailed() {
		return availed;
	}

	@JsonProperty("AvailedFlag")
	public void setAvailed(String availed) {
		this.availed = availed;
	}

	@JsonProperty("leaveText")
	public String getLeaveText() {
		return leaveText;
	}

	@JsonProperty("LeaveText")
	public void setLeaveText(String leaveText) {
		this.leaveText = leaveText;
	}

	@JsonProperty("fromDate")
	public Date getFromDate() {
		return fromDate;
	}

	@JsonProperty("FromDate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	@JsonProperty("toDate")
	public Date getToDate() {
		return toDate;
	}

	@JsonProperty("ToDate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	@JsonProperty("noOfDays")
	public Double getNoOfDays() {
		return noOfDays;
	}

	@JsonProperty("NoOfDays")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setNoOfDays(Double noOfDays) {
		this.noOfDays = noOfDays;
	}

	@Override
	public String toString() {
		return "LeaveReconciliationCrAvResponse [availed=" + availed + ", leaveText=" + leaveText + ", fromDate="
				+ fromDate + ", toDate=" + toDate + ", noOfDays=" + noOfDays + "]";
	}

}
