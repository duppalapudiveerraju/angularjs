package org.ril.hrss.leave.reconciliation.api;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.leave.reconciliation.interfaces.LeaveReconciliationServiceRepo;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationCrAvResponse;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationDetailResponse;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationInfoResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import feign.FeignException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class ApplicationController {

	@Autowired
	private LeaveReconciliationServiceRepo leaveReconciliationServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get Leave Reconciliation Info", response = Map.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved leave info object"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public Map<String, List<LeaveReconciliationInfoResponse>> getLeaveReconciliationInfoDetails(
			@NotNull @RequestHeader("userId") String userId) throws FeignException, ClientException {
		logger.info("leaveReconciliationInfoController.getLeaveReconciliationInfoDetails()");
		return leaveReconciliationServiceRepo.getleaveInfo(userId);
	}

	@RequestMapping(value = "/details/{leaveCode}/{quotaType}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get Leave Reconciliation details", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved leave detail object"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<LeaveReconciliationDetailResponse> getLeaveReconciliationDetails(
			@NotNull @RequestHeader("userId") String userId, @PathVariable("leaveCode") String leaveCode,
			@PathVariable("quotaType") String quotaType) throws FeignException, ClientException {
		logger.info("leaveReconciliationDetailController.getLeaveReconciliationDetails()");
		return leaveReconciliationServiceRepo.getleaveDetail(userId, leaveCode, quotaType);
	}

	@RequestMapping(value = "/usage/{id}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Get Leave Reconciliation credited and availed info", response = List.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully retrieved leave credited and availed info object"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<LeaveReconciliationCrAvResponse> getLeaveReconciliationDetails(
			@NotNull @RequestHeader("userId") String userId, @PathVariable("id") String id)
			throws FeignException, ClientException {
		logger.info("leaveReconciliationDetailController.getLeaveReconciliationDetails()");
		return leaveReconciliationServiceRepo.getleaveCrAvDetail(userId, id);
	}

}