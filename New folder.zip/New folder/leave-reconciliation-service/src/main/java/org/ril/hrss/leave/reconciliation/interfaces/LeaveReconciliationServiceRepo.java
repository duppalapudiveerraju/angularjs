package org.ril.hrss.leave.reconciliation.interfaces;

import java.util.List;
import java.util.Map;

import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationCrAvResponse;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationDetailResponse;
import org.ril.hrss.leave.reconciliation.model.LeaveReconciliationInfoResponse;

import com.netflix.client.ClientException;

import feign.FeignException;

public interface LeaveReconciliationServiceRepo {

	public Map<String, List<LeaveReconciliationInfoResponse>> getleaveInfo(String userId) throws ClientException, FeignException;

	public List<LeaveReconciliationDetailResponse> getleaveDetail(String userId, String leaveCode, String quotaType) throws ClientException, FeignException;

	public List<LeaveReconciliationCrAvResponse> getleaveCrAvDetail(String userId, String id);

}