package org.ril.hrss.leave.reconciliation.model;

import org.ril.hrss.msf.custom.serializer.StrToDoubleSerializer;
import org.ril.hrss.msf.custom.serializer.StrToIntegerSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class LeaveReconciliationDetailResponse {

	private String leaveCode;
	private String quotaType;
	private Integer year;
	private Double opening;
	private Double credited;
	private Double availed;
	private Double balance;
	private String creditedLeaveToken;
	private String availedLeaveToken;

	public LeaveReconciliationDetailResponse() {
		super();
	}

	public LeaveReconciliationDetailResponse(String leaveCode, String quotaType, Integer year, Double opening,
			Double credited, Double availed, Double balance, String creditedLeaveToken, String availedLeaveToken) {
		this();
		this.leaveCode = leaveCode;
		this.quotaType = quotaType;
		this.year = year;
		this.opening = opening;
		this.credited = credited;
		this.availed = availed;
		this.balance = balance;
		this.creditedLeaveToken = creditedLeaveToken;
		this.availedLeaveToken = availedLeaveToken;
	}

	@JsonProperty("leaveCode")
	public String getLeaveCode() {
		return leaveCode;
	}

	@JsonProperty("LeaveCode")
	public void setLeaveCode(String leaveCode) {
		this.leaveCode = leaveCode;
	}

	@JsonProperty("quotaType")
	public String getQuotaType() {
		return quotaType;
	}

	@JsonProperty("QuotaType")
	public void setQuotaType(String quotaType) {
		this.quotaType = quotaType;
	}

	@JsonProperty("year")
	public Integer getYear() {
		return year;
	}

	@JsonProperty("Year")
	@JsonDeserialize(converter = StrToIntegerSerializer.class)
	public void setYear(Integer year) {
		this.year = year;
	}

	@JsonProperty("opening")
	public Double getOpening() {
		return opening;
	}

	@JsonProperty("Opening")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setOpening(Double opening) {
		this.opening = opening;
	}

	@JsonProperty("credited")
	public Double getCredited() {
		return credited;
	}

	@JsonProperty("Credited")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setCredited(Double credited) {
		this.credited = credited;
	}

	@JsonProperty("availed")
	public Double getAvailed() {
		return availed;
	}

	@JsonProperty("Availed")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setAvailed(Double availed) {
		this.availed = availed;
	}

	@JsonProperty("balance")
	public Double getBalance() {
		return balance;
	}

	@JsonProperty("Balance")
	@JsonDeserialize(converter = StrToDoubleSerializer.class)
	public void setBalance(Double balance) {
		this.balance = balance;
	}

	@JsonProperty("creditedFlag")
	public String getCreditedLeaveToken() {
		return creditedLeaveToken;
	}

	@JsonProperty("CreditedFlag")
	public void setCreditedLeaveToken(String creditedLeaveToken) {
		this.creditedLeaveToken = creditedLeaveToken;
	}

	@JsonProperty("availedFlag")
	public String getAvailedLeaveToken() {
		return availedLeaveToken;
	}

	@JsonProperty("AvailedFlag")
	public void setAvailedLeaveToken(String availedLeaveToken) {
		this.availedLeaveToken = availedLeaveToken;
	}

	@Override
	public String toString() {
		return "LeaveReconciliationDetailResponse [leaveCode=" + leaveCode + ", quotaType=" + quotaType + ", year="
				+ year + ", opening=" + opening + ", credited=" + credited + ", availed=" + availed + ", balance="
				+ balance + ", creditedLeaveToken=" + creditedLeaveToken + ", availedLeaveToken=" + availedLeaveToken
				+ "]";
	}

}