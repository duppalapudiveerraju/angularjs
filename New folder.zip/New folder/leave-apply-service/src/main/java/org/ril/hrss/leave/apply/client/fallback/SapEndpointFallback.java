package org.ril.hrss.leave.apply.client.fallback;

import java.util.HashMap;
import java.util.Map;

import org.ril.hrss.leave.apply.client.SapEndpointClient;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public Map<String, String> applyLeaveRequest(String userId, String leaveJSONString) {
		return new HashMap<String, String>();
	}

	@Override
	public Map<String, String> saveLeaveAttachmentRequest(String userId, String filename, byte[] bytes) {
		return new HashMap<String, String>();
	}

}