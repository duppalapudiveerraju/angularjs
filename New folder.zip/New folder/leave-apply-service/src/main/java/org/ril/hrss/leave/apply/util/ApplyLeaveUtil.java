package org.ril.hrss.leave.apply.util;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.leave.apply.client.LeavePendingClient;
import org.ril.hrss.leave.apply.client.ManagerClient;
import org.ril.hrss.leave.apply.client.NotificationClient;
import org.ril.hrss.leave.apply.client.SapEndpointClient;
import org.ril.hrss.leave.apply.client.UserInfoClient;
import org.ril.hrss.leave.apply.model.ApplyLeave;
import org.ril.hrss.leave.apply.model.ApplyLeaveJson;
import org.ril.hrss.leave.apply.model.UserSubordinateDetail;
import org.ril.hrss.msf.model.LeavePendingApprovalDetail;
import org.ril.hrss.msf.model.NotificationJson;
import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.FindDateRange;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.MessagePlaceHolder;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.ril.hrss.msf.util.SAPErrorHandlerUtil;
import org.ril.hrss.msf.util.enumeration.NotificationDetails;
import org.ril.hrss.msf.util.enumeration.SAPGenericError;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.client.ClientException;

@Component
public class ApplyLeaveUtil {

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	@Autowired
	private SAPErrorHandlerUtil sapErrorHandlerUtil;

	@Autowired
	private UserInfoClient userInfoClient;

	protected static final Logger logger = Logger.getLogger(ApplyLeaveUtil.class.getName());

	@Value("${leave.apply.config.url.serviceEndPoint:http://proxyserver.centralindia.cloudapp.azure.com/api/approval-service/apply/leave/}")
	private String leaveServiceEndPoint;

	public ApplyLeaveUtil() {
		super();
	}

	public NotificationJson getNotificationRequest(String managerId, String userId, List<ApplyLeaveJson> list,
			List<Object> leavePayload) {
		logger.info("ApplyLeaveUtil.getNotificationRequest()");
		List<String> fromToDateList = new ArrayList<>();
		List<Date> leaveDateList = new ArrayList<>();

		ObjectMapper objectMapper = objectMapperUtil.get();
		if (leavePayload != null) {
			leavePayload.stream().forEach(obj -> {
				try {
					LeavePendingApprovalDetail leaveObj = objectMapper.readValue(objectMapper.writeValueAsString(obj),
							new TypeReference<LeavePendingApprovalDetail>() {
							});
					if (leaveObj != null && leaveObj.getLeaveFromDate().equals(leaveObj.getLeaveToDate())) {
						leaveDateList.add(leaveObj.getLeaveFromDate());
					} else {
						leaveDateList.addAll(DateUtil.getListOfDaysBetweenTwoDates(leaveObj.getLeaveFromDate(),
								leaveObj.getLeaveToDate()));
					}
				} catch (IOException e1) {
					logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
				}
			});
		}

		fromToDateList = FindDateRange.findRange(leaveDateList);
		List<ApplyLeaveJson> successList = list.parallelStream()
				.filter(e -> e.getRequestStatus().equals(HRSSConstantUtil.POST_RESPONSE_STATUS_SUCCESS))
				.collect(Collectors.toList());
		if (list.size() == successList.size()) {
			return setNotificationRequest(managerId,
					MessagePlaceHolder.formater(HRSSConstantUtil.LEAVE_SUCCESS_MSG, getEmployeeName(managerId, userId),
							String.join(HRSSConstantUtil.SPACE_COMMA, fromToDateList)),
					NotificationDetails.PLAN_MY_LEAVE.getNotificationTitle(), leavePayload);
		} else if (successList.size() > 0 && list.size() > successList.size()) {
			return setNotificationRequest(managerId,
					MessagePlaceHolder.formater(HRSSConstantUtil.LEAVE_SUCCESS_MSG, getEmployeeName(managerId, userId),
							String.join(HRSSConstantUtil.SPACE_COMMA, fromToDateList)),
					NotificationDetails.PLAN_MY_LEAVE.getNotificationTitle(), leavePayload);
		} else {
			return setNotificationRequest(userId,
					MessagePlaceHolder.formater(HRSSConstantUtil.LEAVE_FAIL_MSG, getEmployeeName(managerId, userId),
							String.join(HRSSConstantUtil.SPACE_COMMA, fromToDateList)),
					NotificationDetails.PLAN_MY_LEAVE.getNotificationTitle(), new ArrayList<>());
		}
	}

	private NotificationJson setNotificationRequest(String userId, String message, String title,
			List<Object> leavePayload) {
		logger.info("ApplyLeaveUtil.setNotificationRequest()");
		if (!leavePayload.isEmpty()) {
			return new NotificationJson(message, title, leavePayload, new String[] { userId },
					HRSSConstantUtil.LEAVE_APPLY, leaveServiceEndPoint);
		} else {
			return new NotificationJson(message, title, new ArrayList<>(), new String[] { userId },
					HRSSConstantUtil.LEAVE_APPLY, leaveServiceEndPoint);
		}
	}

	private String getEmployeeName(String managerId, String userId) {
		logger.info("ApplyLeaveUtil.getEmployeeName()");
		Optional<String> optionalEmpName = userInfoClient.getUserSubordinateDetails(managerId).parallelStream()
				.filter(e -> e.getUserId().equals(userId.substring(1))).map(UserSubordinateDetail::getUsername)
				.findFirst();
		return optionalEmpName.isPresent() ? optionalEmpName.get().trim() : userId.trim();
	}

	public List<ApplyLeave> convertStringToJSON(String jsonStr) throws ClientException {
		logger.info("ApplyLeaveUtil.convertStringToJSON()");
		List<ApplyLeave> list = new ArrayList<>();
		ObjectMapper objectMapper = getObjectMapper();
		try {
			if (jsonStr != null) {
				JsonNode rootNode = objectMapper.readTree(jsonStr);
				list = objectMapper.readValue(rootNode.toString(), new TypeReference<List<ApplyLeave>>() {
				});
			}
		} catch (JsonParseException e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
		} catch (JsonMappingException e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
		} catch (IOException e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
		}
		return list;
	}

	public ObjectMapper getObjectMapper() {
		logger.info("ApplyLeaveUtil.getObjectMapper()");
		ObjectMapper objectMapper = objectMapperUtil.get(HRSSConstantUtil.TIMEZONE_IST);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		objectMapper.setDateFormat(df);
		return objectMapper;
	}

	public void setRequestStatus(ApplyLeave obj, Map<String, String> map, List<MultipartFile> uploadFileList) {
		logger.info("ApplyLeaveUtil.setRequestStatus()");
		if (uploadFileList != null && !uploadFileList.isEmpty()) {
			uploadFileList.remove(HRSSConstantUtil.ZERO.intValue());
		}
		obj.setRequestStatus(map.get(HRSSConstantUtil.POST_RESPONSE_STATUS));
		obj.setSystemErrMsg(map.get(HRSSConstantUtil.POST_RESPONSE_SYSTEM_ERR_MSG));
		obj.setRequestErrMsg(sapErrorHandlerUtil.setCustomErrMsg(map, SAPGenericError.APPLY_LEAVE));
	}

	public void processLeaveList(List<ApplyLeaveJson> result, List<ApplyLeave> leaveList, String userId,
			SapEndpointClient sapEndpointClient) {
		logger.info("ApplyLeaveUtil.processLeaveList()");
		for (ApplyLeave obj : leaveList) {
			try {
				Map<String, String> leaveMap = sapEndpointClient.applyLeaveRequest(userId,
						getObjectMapper().writeValueAsString(obj));
				setRequestStatus(obj, leaveMap, null);
				ApplyLeaveJson resultObj = new ApplyLeaveJson();
				BeanUtils.copyProperties(obj, resultObj);
				result.add(resultObj);
			} catch (JsonProcessingException e) {
				logger.log(Level.SEVERE, e.getMessage(), e);
			}
		}
	}

	public void processAttachLeaveList(List<ApplyLeaveJson> result, List<ApplyLeave> attachLeaveList, String userId,
			List<MultipartFile> uploadFileList, ManagerClient managerClient, SapEndpointClient sapEndpointClient,
			LeavePendingClient leavePendingClient, NotificationClient notificationClient) {
		logger.info("ApplyLeaveUtil.processAttachLeaveList()");
		Optional<String> managerId = Optional
				.of(managerClient.getManagerInfoDetails(userId).get(HRSSConstantUtil.ZERO.intValue()));
		for (ApplyLeave obj : attachLeaveList) {
			try {
				MultipartFile fileObj = uploadFileList.get(HRSSConstantUtil.ZERO.intValue());
				Map<String, String> attachResponseMap = sapEndpointClient.saveLeaveAttachmentRequest(userId,
						fileObj.getOriginalFilename(), fileObj.getBytes());
				if (attachResponseMap.get(HRSSConstantUtil.POST_RESPONSE_STATUS)
						.equalsIgnoreCase(HRSSConstantUtil.POST_RESPONSE_STATUS_SUCCESS)) {
					Map<String, String> leaveMap = sapEndpointClient.applyLeaveRequest(userId,
							getObjectMapper().writeValueAsString(obj));
					setRequestStatus(obj, leaveMap, uploadFileList);
				} else {
					setRequestStatus(obj, attachResponseMap, uploadFileList);
				}
				ApplyLeaveJson resultObj = new ApplyLeaveJson();
				BeanUtils.copyProperties(obj, resultObj);
				result.add(resultObj);
			} catch (JsonProcessingException e) {
				logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
			} catch (IOException e) {
				logger.info(HRSSConstantUtil.UNEXPECTED_ERROR_OCCURRED);
			}
		}
		processNotificationRequest(managerId, userId, attachLeaveList, result, leavePendingClient, notificationClient);
	}

	public void processNotificationRequest(Optional<String> managerId, String userId, List<ApplyLeave> inputList,
			List<ApplyLeaveJson> result, LeavePendingClient leavePendingClient, NotificationClient notificationClient) {
		logger.info("ApplyLeaveUtil.processNotificationRequest()");
		new Thread(() -> {
			List<Object> leavePayload = new ArrayList<>();
			inputList.stream().forEach(e -> {
				if (managerId.isPresent() && !managerId.get().equals(HRSSConstantUtil.DEFAULT_EMPLYEEID)) {
					List<Object> listObj = leavePendingClient.getLeavePendingApproval(
							HRSSConstantUtil.SAP_PERSON_PREFIX + managerId.get(), userId,
							DateUtil.getUTCDateFormat(e.getLeaveStartDate()).getTime(),
							DateUtil.getUTCDateFormat(e.getLeaveEndDate()).getTime());
					if (listObj != null) {
						leavePayload.add(listObj.get(HRSSConstantUtil.ZERO.intValue()));
					}
				}
			});
			notificationClient.saveNotificationRequest(getNotificationRequest(
					managerId.isPresent() ? HRSSConstantUtil.SAP_PERSON_PREFIX + managerId.get() : userId, userId,
					result, leavePayload));
		}).start();
	}

}