package org.ril.hrss.leave.apply.interfaces;

import java.util.List;

import org.ril.hrss.leave.apply.model.ApplyLeave;
import org.ril.hrss.leave.apply.model.ApplyLeaveJson;
import org.springframework.web.multipart.MultipartFile;

import com.netflix.client.ClientException;

public interface ApplyLeaveServiceRepo {
	
	public List<ApplyLeaveJson> processPostResponse(String userId, List<ApplyLeave> inputList) throws ClientException;
	
	public List<ApplyLeaveJson> processAttachPostResponse(String userId, String jsonStr,
			List<MultipartFile> uploadFileList) throws ClientException;

}