package org.ril.hrss.leave.apply.client;

import java.util.List;

import org.ril.hrss.leave.apply.client.fallback.LeavePendingFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "leave-pending-approval-service", fallback = LeavePendingFallback.class)
public interface LeavePendingClient {
	@RequestMapping(value = "/leave/{managerId}/{userId}/{leaveFromDate}/{leaveToDate}", method = RequestMethod.GET, produces = "application/json", consumes = "application/json")
	public List<Object> getLeavePendingApproval(@PathVariable("managerId") String managerId, @PathVariable("userId") String userId,
			@PathVariable("leaveFromDate") Long leaveFromDate, @PathVariable("leaveToDate") Long leaveToDate);

}
