package org.ril.hrss.leave.apply.client.fallback;

import java.util.ArrayList;
import java.util.List;

import org.ril.hrss.leave.apply.client.ManagerClient;
import org.springframework.stereotype.Component;

@Component
public class ManagerFallback implements ManagerClient {

	@Override
	public List<String> getManagerInfoDetails(String userId) {
		return new ArrayList<>();
	}

}
