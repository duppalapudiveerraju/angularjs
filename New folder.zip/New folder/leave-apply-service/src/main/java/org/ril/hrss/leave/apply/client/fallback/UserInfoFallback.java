package org.ril.hrss.leave.apply.client.fallback;

import java.util.ArrayList;
import java.util.List;

import org.ril.hrss.leave.apply.client.UserInfoClient;
import org.ril.hrss.leave.apply.model.UserSubordinateDetail;

public class UserInfoFallback implements UserInfoClient {

	@Override
	public List<UserSubordinateDetail> getUserSubordinateDetails(String userId) {
		return new ArrayList<>();
	}

}
