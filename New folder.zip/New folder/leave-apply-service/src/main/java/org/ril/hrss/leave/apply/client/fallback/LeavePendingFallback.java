package org.ril.hrss.leave.apply.client.fallback;

import java.util.ArrayList;
import java.util.List;

import org.ril.hrss.leave.apply.client.LeavePendingClient;

public class LeavePendingFallback implements LeavePendingClient {

	@Override
	public List<Object> getLeavePendingApproval(String managerId, String userId, Long leaveFromDate, Long leaveToDate) {
		return new ArrayList<>();
	}

}