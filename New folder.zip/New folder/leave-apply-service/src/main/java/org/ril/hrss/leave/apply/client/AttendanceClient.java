package org.ril.hrss.leave.apply.client;

import java.util.Date;
import java.util.List;

import org.ril.hrss.leave.apply.client.fallback.AttendanceFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "attendance-service", fallback = AttendanceFallback.class)
public interface AttendanceClient {

	@RequestMapping(value = "/attendance/offDays/{userId}/{month}/{year}", method = RequestMethod.GET, produces = "application/json")
	List<Date> getNonWorkingDaysMonthwise(@PathVariable("userId") String userId, @PathVariable("month") String month,
			@PathVariable("year") String year);

}