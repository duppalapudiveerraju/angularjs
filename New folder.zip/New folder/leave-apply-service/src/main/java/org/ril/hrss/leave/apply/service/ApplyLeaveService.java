package org.ril.hrss.leave.apply.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.ril.hrss.leave.apply.client.LeavePendingClient;
import org.ril.hrss.leave.apply.client.ManagerClient;
import org.ril.hrss.leave.apply.client.NotificationClient;
import org.ril.hrss.leave.apply.client.SapEndpointClient;
import org.ril.hrss.leave.apply.interfaces.ApplyLeaveServiceRepo;
import org.ril.hrss.leave.apply.model.ApplyLeave;
import org.ril.hrss.leave.apply.model.ApplyLeaveJson;
import org.ril.hrss.leave.apply.util.ApplyLeaveUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.SAPErrorHandlerUtil;
import org.ril.hrss.msf.util.enumeration.SAPGenericError;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.netflix.client.ClientException;

@Service
public class ApplyLeaveService implements ApplyLeaveServiceRepo {

	protected static final Logger logger = Logger.getLogger(ApplyLeaveService.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private NotificationClient notificationClient;

	@Autowired
	private ManagerClient managerClient;

	@Autowired
	private LeavePendingClient leavePendingClient;

	@Autowired
	private SAPErrorHandlerUtil sapErrorHandlerUtil;

	@Autowired
	private ApplyLeaveUtil applyLeaveUtil;

	public ApplyLeaveService() {
		super();
	}

	@Override
	public List<ApplyLeaveJson> processPostResponse(String userId, List<ApplyLeave> inputList) throws ClientException {
		logger.info("ApplyLeaveService.processPostResponse()");
		List<ApplyLeaveJson> result = new ArrayList<ApplyLeaveJson>();
		Optional<String> managerId = Optional
				.of(managerClient.getManagerInfoDetails(userId).get(HRSSConstantUtil.ZERO.intValue()));
		for (ApplyLeave obj : inputList) {
			try {
				Map<String, String> map = sapEndpointClient.applyLeaveRequest(userId,
						applyLeaveUtil.getObjectMapper().writeValueAsString(obj));
				obj.setRequestStatus(map.get(HRSSConstantUtil.POST_RESPONSE_STATUS));
				obj.setSystemErrMsg(map.get(HRSSConstantUtil.POST_RESPONSE_SYSTEM_ERR_MSG));
				obj.setRequestErrMsg(sapErrorHandlerUtil.setCustomErrMsg(map, SAPGenericError.APPLY_LEAVE));
				ApplyLeaveJson resultObj = new ApplyLeaveJson();
				BeanUtils.copyProperties(obj, resultObj);
				result.add(resultObj);
			} catch (JsonProcessingException e) {
				logger.info(e.getMessage());
			}
		}
		applyLeaveUtil.processNotificationRequest(managerId, userId, inputList, result, leavePendingClient,
				notificationClient);
		return result;
	}

	@Override
	public List<ApplyLeaveJson> processAttachPostResponse(String userId, String jsonStr,
			List<MultipartFile> uploadFileList) throws ClientException {
		logger.info("ApplyLeaveService.processPostResponse()");
		List<ApplyLeave> inputList = applyLeaveUtil.convertStringToJSON(jsonStr);
		List<ApplyLeaveJson> result = new ArrayList<ApplyLeaveJson>();
		List<ApplyLeave> attachLeaveList = inputList.parallelStream().filter(e -> e.isAttachFlag())
				.collect(Collectors.toList());
		List<ApplyLeave> leaveList = inputList.parallelStream().filter(e -> !e.isAttachFlag())
				.collect(Collectors.toList());
		applyLeaveUtil.processLeaveList(result, leaveList, userId, sapEndpointClient);
		if (uploadFileList != null && !attachLeaveList.isEmpty()) {
			applyLeaveUtil.processAttachLeaveList(result, attachLeaveList, userId, uploadFileList, managerClient,
					sapEndpointClient, leavePendingClient, notificationClient);
		}
		return result;
	}

}