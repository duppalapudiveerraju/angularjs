package org.ril.hrss.leave.apply.model;

import java.util.Date;

import org.ril.hrss.msf.util.DateUtil;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ApplyLeaveJson {

	private String halfDayCheck;
	private String halfDayFlag;
	private String halfDayStartTime;
	private String halfDayEndTime;
	private String leaveCode;
	private Date leaveStartDate;
	private Date leaveEndDate;
	private String leavePlanHrs;
	private String remark;
	private Double leaveBalance;
	private boolean attachFlag;
	private String requestStatus;
	private String requestErrMsg;
	private String systemErrMsg;

	public ApplyLeaveJson() {
		super();
	}

	public ApplyLeaveJson(String halfDayCheck, String halfDayFlag, String halfDayStartTime, String halfDayEndTime,
			String leaveCode, Date leaveStartDate, Date leaveEndDate, String leavePlanHrs, String remark,
			Double leaveBalance, boolean attachFlag, String requestStatus, String requestErrMsg, String systemErrMsg) {
		super();
		this.halfDayCheck = halfDayCheck;
		this.halfDayFlag = halfDayFlag;
		this.halfDayStartTime = halfDayStartTime;
		this.halfDayEndTime = halfDayEndTime;
		this.leaveCode = leaveCode;
		this.leaveStartDate = leaveStartDate;
		this.leaveEndDate = leaveEndDate;
		this.leavePlanHrs = leavePlanHrs;
		this.remark = remark;
		this.leaveBalance = leaveBalance;
		this.attachFlag = attachFlag;
		this.requestStatus = requestStatus;
		this.requestErrMsg = requestErrMsg;
		this.setSystemErrMsg(systemErrMsg);
	}

	@JsonProperty("halfDayCheck")
	public boolean getHalfDayCheckJson() {
		return halfDayCheck.equals("X");
	}

	public String getHalfDayCheck() {
		return halfDayCheck;
	}

	public void setHalfDayCheck(String halfDayCheck) {
		this.halfDayCheck = halfDayCheck;
	}

	@JsonProperty("halfDayFlag")
	public boolean getHalfDayFlagJson() {
		return halfDayFlag.equals("X");
	}

	public String getHalfDayFlag() {
		return halfDayCheck;
	}

	public void setHalfDayFlag(String halfDayFlag) {
		this.halfDayFlag = halfDayFlag;
	}

	@JsonProperty("halfDayStartTime")
	public Date getHalfDayStartTimeJson() {
		Date date = DateUtil.getDateFromTimeFormat(halfDayStartTime, leaveStartDate);
		return date.equals(leaveStartDate) ? null : date;
	}

	public void setHalfDayStartTime(String halfDayStartTime) {
		this.halfDayStartTime = halfDayStartTime;
	}

	@JsonProperty("halfDayEndTime")
	public Date getHalfDayEndTimeJson() {
		Date date = DateUtil.getDateFromTimeFormat(halfDayEndTime, leaveStartDate);
		return date.equals(leaveStartDate) ? null : date;
	}

	public String getHalfDayEndTime() {
		return halfDayEndTime;
	}

	public void setHalfDayEndTime(String halfDayEndTime) {
		this.halfDayEndTime = halfDayEndTime;
	}

	public String getLeaveCode() {
		return leaveCode;
	}

	public void setLeaveCode(String leaveCode) {
		this.leaveCode = leaveCode;
	}

	public Date getLeaveStartDate() {
		return leaveStartDate;
	}

	public void setLeaveStartDate(Date leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}

	public Date getLeaveEndDate() {
		return leaveEndDate;
	}

	public void setLeaveEndDate(Date leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}

	@JsonProperty("leavePlanHrs")
	public Double getLeavePlanHrsJson() {
		return Double.parseDouble(leavePlanHrs);
	}

	public String getLeavePlanHrs() {
		return leavePlanHrs;
	}

	public void setLeavePlanHrs(String leavePlanHrs) {
		this.leavePlanHrs = leavePlanHrs;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Double getLeaveBalance() {
		return leaveBalance;
	}

	public void setLeaveBalance(Double leaveBalance) {
		this.leaveBalance = leaveBalance;
	}

	public boolean isAttachFlag() {
		return attachFlag;
	}

	public void setAttachFlag(boolean attachFlag) {
		this.attachFlag = attachFlag;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public String getSystemErrMsg() {
		return systemErrMsg;
	}

	public void setSystemErrMsg(String systemErrMsg) {
		this.systemErrMsg = systemErrMsg;
	}

	@Override
	public String toString() {
		return "ApplyLeaveJson [halfDayCheck=" + halfDayCheck + ", halfDayFlag=" + halfDayFlag + ", halfDayStartTime="
				+ halfDayStartTime + ", halfDayEndTime=" + halfDayEndTime + ", leaveCode=" + leaveCode
				+ ", leaveStartDate=" + leaveStartDate + ", leaveEndDate=" + leaveEndDate + ", leavePlanHrs="
				+ leavePlanHrs + ", remark=" + remark + ", leaveBalance=" + leaveBalance + ", attachFlag=" + attachFlag
				+ ", requestStatus=" + requestStatus + ", requestErrMsg=" + requestErrMsg + ", systemErrMsg="
				+ systemErrMsg + "]";
	}

}