package org.ril.hrss.leave.apply.client.fallback;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.ril.hrss.leave.apply.client.AttendanceClient;
import org.springframework.stereotype.Component;

@Component
public class AttendanceFallback implements AttendanceClient {

	@Override
	public List<Date> getNonWorkingDaysMonthwise(String userId, String month, String year) {
		return new ArrayList<Date>();
	}

}