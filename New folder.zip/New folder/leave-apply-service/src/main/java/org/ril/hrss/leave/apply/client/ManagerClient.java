package org.ril.hrss.leave.apply.client;

import java.util.List;

import org.ril.hrss.leave.apply.client.fallback.ManagerFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "manager-info-service", fallback = ManagerFallback.class)
public interface ManagerClient {
	@RequestMapping(value = "/info/{userId}", method = RequestMethod.GET, produces = "application/json", consumes = "application/json")
	List<String> getManagerInfoDetails(@PathVariable("userId") String userId);
}