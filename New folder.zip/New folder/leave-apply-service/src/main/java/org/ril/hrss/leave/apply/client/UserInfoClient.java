package org.ril.hrss.leave.apply.client;

import java.util.List;

import org.ril.hrss.leave.apply.client.fallback.UserInfoFallback;
import org.ril.hrss.leave.apply.model.UserSubordinateDetail;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "user-info-service", fallback = UserInfoFallback.class)
public interface UserInfoClient {

	@RequestMapping(value = "/info/subordinate/{userId}", method = RequestMethod.GET, produces = "application/json")
	List<UserSubordinateDetail> getUserSubordinateDetails(@PathVariable("userId") String userId);

}
