package org.ril.hrss.leave.apply.client;

import java.util.Map;

import org.ril.hrss.leave.apply.client.fallback.SapEndpointFallback;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.POST, value = "/sap/leave/apply/userId/{userId}", produces = "application/json", consumes = "application/json")
	Map<String, String> applyLeaveRequest(@PathVariable("userId") String userId, @RequestBody String leaveJSONString);

	@RequestMapping(method = RequestMethod.POST, value = "/sap/leave/attachment/userId/{userId}", produces = "application/json")
	Map<String, String> saveLeaveAttachmentRequest(@PathVariable("userId") String userId,
			@RequestParam("filename") String filename, @RequestBody byte[] bytes);

}