package org.ril.hrss.leave.apply.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.BooleanToSAPSerializer;
import org.ril.hrss.msf.util.DateUtil;
import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class ApplyLeave {

	private boolean halfDayCheck;
	private boolean halfDayFlag;
	private Date halfDayStartTime;
	private Date halfDayEndTime;
	private String leaveCode;
	private Date leaveStartDate;
	private Date leaveEndDate;
	private Double leavePlanHrs;
	private boolean attachFlag;
	private Double leaveBalance;
	private String remark;
	private String requestStatus;
	private String requestErrMsg;
	private String systemErrMsg;
	
	public ApplyLeave() {
		super();
	}

	public ApplyLeave(boolean halfDayCheck, boolean halfDayFlag, Date halfDayStartTime, Date halfDayEndTime,
			String leaveCode, Date leaveStartDate, Date leaveEndDate, Double leavePlanHrs, boolean attachFlag,
			Double leaveBalance, String remark, String requestStatus, String requestErrMsg, String systemErrMsg) {
		super();
		this.halfDayCheck = halfDayCheck;
		this.halfDayFlag = halfDayFlag;
		this.halfDayStartTime = halfDayStartTime;
		this.halfDayEndTime = halfDayEndTime;
		this.leaveCode = leaveCode;
		this.leaveStartDate = leaveStartDate;
		this.leaveEndDate = leaveEndDate;
		this.leavePlanHrs = leavePlanHrs;
		this.attachFlag = attachFlag;
		this.leaveBalance = leaveBalance;
		this.remark = remark;
		this.requestStatus = requestStatus;
		this.requestErrMsg = requestErrMsg;
		this.systemErrMsg = systemErrMsg;
	}

	@JsonProperty("HDCheck")
	public String getHalfDayCheck() {
		return halfDayCheck ? "X" : HRSSConstantUtil.EMPTY_STRING;
	}

	@JsonProperty("halfDayCheck")
	public void setHalfDayCheck(boolean halfDayCheck) {
		this.halfDayCheck = halfDayCheck;
	}

	@JsonIgnore
	@JsonProperty("HalfDay")
	public String getHalfDayFlag() {
		return halfDayFlag ? "X" : HRSSConstantUtil.EMPTY_STRING;
	}

	@JsonProperty("halfDayFlag")
	public void setHalfDayFlag(boolean halfDayFlag) {
		this.halfDayFlag = halfDayFlag;
	}

	@JsonProperty("Halfbeguz")
	public String getHalfDayStartTime() {
		String str = DateUtil.getFormattedStrFromDate(halfDayStartTime);
		return str != null ? str : "PT00H00M00S";
	}

	@JsonProperty("halfDayStartTime")
	public void setHalfDayStartTime(Date halfDayStartTime) {
		this.halfDayStartTime = halfDayStartTime;
	}

	@JsonProperty("Halfenduz")
	public String getHalfDayEndTime() {
		String str = DateUtil.getFormattedStrFromDate(halfDayEndTime);
		return str != null ? str : "PT00H00M00S";
	}

	@JsonProperty("halfDayEndTime")
	public void setHalfDayEndTime(Date halfDayEndTime) {
		this.halfDayEndTime = halfDayEndTime;
	}

	@JsonProperty("LeaveType")
	public String getLeaveCode() {
		return leaveCode;
	}

	@JsonProperty("leaveCode")
	public void setLeaveCode(String leaveCode) {
		this.leaveCode = leaveCode;
	}

	@JsonProperty("Leavefrm")
	public Date getLeaveStartDate() {
		return leaveStartDate;
	}

	@JsonProperty("leaveStartDate")
	public void setLeaveStartDate(Date leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}

	@JsonProperty("Leaveto")
	public Date getLeaveEndDate() {
		return leaveEndDate;
	}

	@JsonProperty("leaveEndDate")
	public void setLeaveEndDate(Date leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}

	@JsonProperty("PlanHrs")
	public String getLeavePlanHrs() {
		return leavePlanHrs.toString();
	}

	@JsonProperty("leavePlanHrs")
	public void setLeavePlanHrs(Double leavePlanHrs) {
		this.leavePlanHrs = leavePlanHrs;
	}

	@JsonProperty("Attachdoc")
	@JsonSerialize(converter = BooleanToSAPSerializer.class)
	public boolean isAttachFlag() {
		return attachFlag;
	}

	@JsonProperty("attachFlag")
	public void setAttachFlag(boolean attachFlag) {
		this.attachFlag = attachFlag;
	}

	@JsonProperty("Remarks")
	public String getRemark() {
		return remark;
	}

	@JsonProperty("remark")
	public void setRemark(String remark) {
		this.remark = remark;
	}

	@JsonIgnore
	public Double getLeaveBalance() {
		return leaveBalance;
	}

	@JsonProperty("leaveBalance")
	public void setLeaveBalance(Double leaveBalance) {
		this.leaveBalance = leaveBalance;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public String getRequestStatus() {
		return requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestStatus")
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public String getRequestErrMsg() {
		return requestErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("requestErrMsg")
	public void setRequestErrMsg(String requestErrMsg) {
		this.requestErrMsg = requestErrMsg;
	}
	
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public String getSystemErrMsg() {
		return systemErrMsg;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@JsonProperty("systemErrMsg")
	public void setSystemErrMsg(String systemErrMsg) {
		this.systemErrMsg = systemErrMsg;
	}

	@Override
	public String toString() {
		return "ApplyLeave [halfDayCheck=" + halfDayCheck + ", halfDayFlag=" + halfDayFlag + ", halfDayStartTime="
				+ halfDayStartTime + ", halfDayEndTime=" + halfDayEndTime + ", leaveCode=" + leaveCode
				+ ", leaveStartDate=" + leaveStartDate + ", leaveEndDate=" + leaveEndDate + ", leavePlanHrs="
				+ leavePlanHrs + ", attachFlag=" + attachFlag + ", leaveBalance=" + leaveBalance + ", remark=" + remark
				+ ", requestStatus=" + requestStatus + ", requestErrMsg=" + requestErrMsg + ", systemErrMsg="
				+ systemErrMsg + "]";
	}
	
}