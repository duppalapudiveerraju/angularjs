package org.ril.hrss.leave.apply.api;

import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.leave.apply.interfaces.ApplyLeaveServiceRepo;
import org.ril.hrss.leave.apply.model.ApplyLeave;
import org.ril.hrss.leave.apply.model.ApplyLeaveJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/leave")
@Api(value = "Leave details", description = "Operations pertaining to find Leave details")
public class ApplicationController {

	@Autowired
	private ApplyLeaveServiceRepo applyLeaveServiceRepo;

	protected static final Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	@RequestMapping(value = "/apply/userId/{userId}", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save a list of leave request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully saved list of leave request"),
			@ApiResponse(code = 201, message = "Successfully saved list of regularize request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<ApplyLeaveJson> applyLeaveRequest(@PathVariable("userId") String userId,
			@RequestBody List<ApplyLeave> inputList) throws ClientException {
		logger.info("regularize-apply-service.applyLeaveRequest()");
		return applyLeaveServiceRepo.processPostResponse(userId, inputList);
	}

	@RequestMapping(value = "/apply/attachment/userId/{userId}", method = RequestMethod.POST)
	@ApiOperation(value = "Save a list of leave request", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully saved list of leave request"),
			@ApiResponse(code = 201, message = "Successfully saved list of regularize request"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<ApplyLeaveJson> applyAttachLeaveRequest(@PathVariable("userId") String userId,
			@RequestParam("jsonStr") String jsonStr, @RequestParam("files") List<MultipartFile> uploadFileList)
			throws ClientException {
		logger.info("regularize-apply-service.applyAttachLeaveRequest()");
		return applyLeaveServiceRepo.processAttachPostResponse(userId, jsonStr, uploadFileList);
	}

}