package org.ril.hrss.auth.util;

import java.util.Base64;
import java.util.logging.Logger;

import org.ril.hrss.msf.model.UserAuth;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class AuthUtil {

	protected static final Logger logger = Logger.getLogger(AuthUtil.class.getName());

	public AuthUtil() {
		super();
	}

	public UserAuth getUserAuthObj(String authStr) {
		logger.info("AuthUtil.getUserAuthObj()");
		if (authStr != null) {
			byte[] bytes = Base64.getDecoder().decode(authStr);
			String decodedAuth = new String(bytes);
			int index = decodedAuth.indexOf(HRSSConstantUtil.AUTH_DELIMITER);
			String userId = decodedAuth.substring(HRSSConstantUtil.ZERO.intValue(), index);
			String userPass = decodedAuth.substring(index + 1, decodedAuth.length());
			return new UserAuth(userId, userPass);
		}
		return new UserAuth();
	}

	public boolean isAuthPropertySet(UserAuth userAuthObj) {
		logger.info("AuthUtil.isAuthPropertySet()");
		if (userAuthObj != null && !userAuthObj.getUserId().isEmpty() && !userAuthObj.getUserPass().isEmpty()) {
			return true;
		}
		return false;
	}

}