package org.ril.hrss.auth.client;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.ril.hrss.auth.client.fallback.SapEndpointFallback;
import org.ril.hrss.msf.model.UserAuth;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	@RequestMapping(method = RequestMethod.POST, value = "/sap/auth/login", produces = "application/json", consumes = "application/json")
	ResponseEntity<UserAuth> validateAuth(@Valid @RequestBody UserAuth userAuthObj);

	@RequestMapping(method = RequestMethod.GET, value = "/sap/auth/logout", produces = "application/json", consumes = "application/json")
	ResponseEntity<Object> unregisterAuth(@NotNull @RequestHeader("userId") String userId);

}