package org.ril.hrss.auth.api;

import java.util.logging.Logger;

import org.ril.hrss.auth.intefaces.AuthServiceRepo;
import org.ril.hrss.msf.model.UserAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import feign.FeignException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Auth Operation", description = "Operations pertaining to get Auth")
public class AuthController {

	@Autowired
	private AuthServiceRepo authServiceRepo;

	protected static final Logger logger = Logger.getLogger(AuthController.class.getName());

	public AuthController() {
		super();
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "Login Into App", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully login"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<UserAuth> validateAuth(@RequestHeader(value = "AuthDigest", required = true) String authStr)
			throws ClientException, FeignException {
		logger.info("AuthController.validateAuth()");
		return authServiceRepo.validateAuth(authStr);
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Logout From App", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully logout"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> unregisterAuth(@RequestHeader(value = "userId", required = true) String userId)
			throws ClientException, FeignException {
		logger.info("AuthController.unregisterAuth()");
		return authServiceRepo.unregisterAuth(userId);
	}

}