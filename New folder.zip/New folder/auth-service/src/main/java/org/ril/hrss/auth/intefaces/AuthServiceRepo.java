package org.ril.hrss.auth.intefaces;

import org.ril.hrss.msf.model.UserAuth;
import org.springframework.http.ResponseEntity;

import com.netflix.client.ClientException;

import feign.FeignException;

public interface AuthServiceRepo {

	public ResponseEntity<UserAuth> validateAuth(String authStr) throws ClientException, FeignException;

	public ResponseEntity<Object> unregisterAuth(String employeeId) throws ClientException;

}