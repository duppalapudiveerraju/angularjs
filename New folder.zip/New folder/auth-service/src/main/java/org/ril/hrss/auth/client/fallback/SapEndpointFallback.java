package org.ril.hrss.auth.client.fallback;

import org.ril.hrss.auth.client.SapEndpointClient;
import org.ril.hrss.msf.model.UserAuth;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public ResponseEntity<UserAuth> validateAuth(UserAuth userAuthObj) {
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	@Override
	public ResponseEntity<Object> unregisterAuth(String employeeId) {
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

}