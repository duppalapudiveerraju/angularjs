package org.ril.hrss.auth.service;

import java.util.logging.Logger;

import org.ril.hrss.auth.client.SapEndpointClient;
import org.ril.hrss.auth.intefaces.AuthServiceRepo;
import org.ril.hrss.auth.util.AuthUtil;
import org.ril.hrss.msf.model.UserAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.netflix.client.ClientException;

import feign.FeignException;

@Service
public class AuthService implements AuthServiceRepo {

	protected static final Logger logger = Logger.getLogger(AuthService.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private AuthUtil authUtil;

	public AuthService() {
		super();
	}

	@Override
	public ResponseEntity<UserAuth> validateAuth(String authStr) throws ClientException, FeignException {
		logger.info("AuthService.validateAuth()");
		UserAuth userAuthObj = authUtil.getUserAuthObj(authStr);
		if (authUtil.isAuthPropertySet(userAuthObj)) {
			return sapEndpointClient.validateAuth(userAuthObj);
		}
		return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
	}

	@Override
	public ResponseEntity<Object> unregisterAuth(String employeeId) throws ClientException {
		logger.info("AuthService.unregisterAuth()");
		return sapEndpointClient.unregisterAuth(employeeId);
	}

}