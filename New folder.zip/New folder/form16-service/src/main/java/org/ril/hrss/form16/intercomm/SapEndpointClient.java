package org.ril.hrss.form16.intercomm;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "sap-endpoint-service", fallback = SapEndpointFallback.class)
public interface SapEndpointClient {

	// form16 yearList
	@RequestMapping(method = RequestMethod.GET, value = "/sap/form16/yearlist/{userId}")
	String getForm16YearListDetail(@PathVariable("userId") String userId);

	// form16 pdf view
	@RequestMapping(value = "/sap/form16/view/{userId}/{fyear}", method = RequestMethod.GET,produces = "application/pdf")
	public  String getForm16(@PathVariable("userId") String userId ,@PathVariable("fyear")String fyear);

	// form16 pdf download
	@RequestMapping(value = "sap/form16/pdf/{userId}/{fyear}", method = RequestMethod.GET, produces = "application/pdf")
	public  String getForm16PdfDownload(@PathVariable("userId") String userId,@PathVariable("fyear")String fyear);

	

}
