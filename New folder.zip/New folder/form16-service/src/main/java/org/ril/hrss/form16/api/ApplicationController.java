package org.ril.hrss.form16.api;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletResponse;

import org.ril.hrss.form16.model.Form16YearListDetail;
import org.ril.hrss.form16.util.Form16Util;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/form16")
@Api(value = "Form16 details", description = "Operations pertaining to find form16 details")
public class ApplicationController {

	@Autowired
	private Form16Util form16Util;

	protected Logger logger = Logger.getLogger(ApplicationController.class.getName());

	public ApplicationController() {
		super();
	}

	/* FORM16 YEAR LIST */
	@RequestMapping(value = "/yearList/{userId}", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "View a list of form16", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public List<Form16YearListDetail> getForm16YearListDetail(@PathVariable("userId") String userId) {
		logger.info("form16-service-controller.getForm16YearListDetail()");
		return form16Util.getForm16YearListDetail(userId);
	}

	/* FORM16 PDF VIEW */
	@RequestMapping(value = "/view/{userId}/{fyear}", method = RequestMethod.GET, produces = "application/pdf")

	@ApiOperation(value = "View  of form16", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public String getForm16View(@PathVariable("userId") String userId, HttpServletResponse response,
			@PathVariable("fyear") String fyear) {
		logger.info("form16-service-controller.getForm16()");
		response.setContentType(HRSSConstantUtil.HTTP_APPICATION_PDF);
		return form16Util.getForm16(userId, fyear);
	}

	/* FORM16 PDF DOWNLOAD */
	@RequestMapping(value = "/download/{userId}/{fyear}", method = RequestMethod.GET, produces = "application/pdf")
	@ApiOperation(value = "downlaod  of form16", response = List.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public String getForm16PdfDownload(@PathVariable("userId") String userId, HttpServletResponse response,
			@PathVariable("fyear") String fyear) {
		logger.info("form16-service-controller.getForm16PdfDownload()");
		response.setContentType(HRSSConstantUtil.HTTP_APPICATION_PDF);
		response.setHeader(HRSSConstantUtil.HTTP_HEADER_CONTENT_DISPOSITION,
				HRSSConstantUtil.HTTP_HEADER_CONTENT_DISPOSITION_ATTACH_FILE + userId);
		return form16Util.getForm16PdfDownload(userId, fyear);
	}

}