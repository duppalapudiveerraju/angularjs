package org.ril.hrss.form16.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Form16YearListDetail {

	@JsonProperty("IvPernr")
	private String investmentPernr;

	@JsonProperty("Fyear")
	private String financialYear;

	@JsonProperty("Ftext")
	private String displayText;

	public Form16YearListDetail() {
		super();
	}

	@Override
	public String toString() {
		return "Form16Detail [IvPernr=" + investmentPernr + ", Fyear=" + financialYear + ", Ftext=" + displayText
				+ " ]";
	}

	public Form16YearListDetail(String investmentPernr, String financialYear, String displayText) {
		super();
		this.investmentPernr = investmentPernr;
		this.financialYear = financialYear;
		this.displayText = displayText;
	}

	public String getInvestmentPernr() {
		return investmentPernr;
	}

	public void setInvestmentPernr(String investmentPernr) {
		this.investmentPernr = investmentPernr;
	}

	public String getFinancialYear() {
		return financialYear;
	}

	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}

	public String getDisplayText() {
		return displayText;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

}
