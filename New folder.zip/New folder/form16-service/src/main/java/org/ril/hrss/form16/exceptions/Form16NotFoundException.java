package org.ril.hrss.form16.exceptions;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(org.springframework.http.HttpStatus.NOT_FOUND)
public class Form16NotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public Form16NotFoundException(String fyear) {
		super("Form16 Not available for finacial year : " + fyear);
	}

}