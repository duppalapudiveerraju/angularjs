package org.ril.hrss.form16.intercomm;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getForm16YearListDetail(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	public String getForm16(String userId, String fyear) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

	@Override
	public String getForm16PdfDownload(String userId, String fyear) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}