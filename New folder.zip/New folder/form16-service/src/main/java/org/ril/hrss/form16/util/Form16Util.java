package org.ril.hrss.form16.util;

import java.io.IOException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.form16.intercomm.SapEndpointClient;
import org.ril.hrss.form16.model.Form16YearListDetail;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Form16Util {

	protected Logger logger = Logger.getLogger(Form16Util.class.getName());

	@Autowired
	private SapEndpointClient sapEndpointClient;

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	public Form16Util() {
		super();
	}

	public List<Form16YearListDetail> getForm16YearListDetail(String userId) {
		logger.info("Form16Util.getForm16YearListDetail()");
		return getForm16YearListDetailObjectMapped(sapEndpointClient.getForm16YearListDetail(userId));
	}

	private List<Form16YearListDetail> getForm16YearListDetailObjectMapped(String feed) {
		logger.info("Form16Util.getForm16YearList()");
		List<Form16YearListDetail> list = new ArrayList<Form16YearListDetail>();
		try {
			ObjectMapper objectMapper = objectMapperUtil.get();
			JsonNode rootNode = objectMapper.readTree(feed);
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
			objectMapper.setDateFormat(df);
			list = objectMapper.readValue(
					rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
					new TypeReference<List<Form16YearListDetail>>() {
					});
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list;
	}

	// form16 PDF view

	public String getForm16(String userId, String fyear) {

		logger.info("Form16Util.getForm16ViewDetail()");

		return sapEndpointClient.getForm16(userId, fyear);

	}

	// form16 PDF download
	public String getForm16PdfDownload(String userId, String fyear) {

		logger.info("Form16Util.getForm16PdfDownload()");

		return sapEndpointClient.getForm16PdfDownload(userId, fyear);

	}

}