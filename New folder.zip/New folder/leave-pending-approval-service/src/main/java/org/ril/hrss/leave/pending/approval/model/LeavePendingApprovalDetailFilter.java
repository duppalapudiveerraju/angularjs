package org.ril.hrss.leave.pending.approval.model;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.ril.hrss.msf.util.HRSSConstantUtil;

import com.fasterxml.jackson.databind.util.StdConverter;

public class LeavePendingApprovalDetailFilter
		extends StdConverter<LeavePendingApprovalDetail, LeavePendingApprovalDetail> {

	@Override
	public LeavePendingApprovalDetail convert(LeavePendingApprovalDetail obj) {
		long applyDateMillis = obj.getApplyDate().getTime();
		long currentDateMiilis = new Date().getTime();
		obj.setSlaBreached(Math.abs(TimeUnit.DAYS.convert(currentDateMiilis - applyDateMillis, TimeUnit.DAYS)
				/ 86400000) > HRSSConstantUtil.REGULARIZE_PENDING_SLA);
		return obj;
	}

}
