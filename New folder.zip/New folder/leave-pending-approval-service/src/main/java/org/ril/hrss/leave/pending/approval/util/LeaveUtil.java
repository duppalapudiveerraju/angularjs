package org.ril.hrss.leave.pending.approval.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.ril.hrss.leave.pending.approval.intercomm.SapEndpointClient;
import org.ril.hrss.leave.pending.approval.model.LeavePendingApprovalDetail;
import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.ril.hrss.msf.util.ObjectMapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.client.ClientException;

@Component
public class LeaveUtil {

	protected static final Logger logger = Logger.getLogger(LeaveUtil.class.getName());

	@Autowired
	private ObjectMapperUtil objectMapperUtil;

	@Autowired
	private SapEndpointClient sapEndpointClient;

	public LeaveUtil() {
		super();
	}

	public Map<Pair<String, Long>, List<LeavePendingApprovalDetail>> getLeavePendingApprovalDetails(String userId)
			throws ClientException {
		logger.info("LeaveUtil.getLeavePendingApprovalDetails()");
		return getLeavePendingApprovalDetailList(sapEndpointClient.getLeavePendingApprovalDetails(userId))
				.parallelStream()
				.collect(Collectors.groupingBy(p -> Pair.of(p.getEmployeeId(), p.getApplyDate().getTime())));
	}

	private List<LeavePendingApprovalDetail> getLeavePendingApprovalDetailList(String feed) {
		logger.info("LeaveUtil.getLeavePendingApprovalDetailList()");
		List<LeavePendingApprovalDetail> list = new ArrayList<LeavePendingApprovalDetail>();
		ObjectMapper objectMapper = objectMapperUtil.get();
		try {
			if (feed != null) {
				JsonNode rootNode = objectMapper.readTree(feed);
				list = objectMapper.readValue(
						rootNode.get(HRSSConstantUtil.SAP_JSON_ROOT).get(HRSSConstantUtil.SAP_JSON_RESULTS).toString(),
						new TypeReference<List<LeavePendingApprovalDetail>>() {
						});
			}
		} catch (JsonParseException e) {
			logger.info(e.getMessage());
		} catch (JsonMappingException e) {
			logger.info(e.getMessage());
		} catch (IOException e) {
			logger.info(e.getMessage());
		}
		return list;
	}

	public List<LeavePendingApprovalDetail> getLeavePendingApproval(String managerId, String userId, Long leaveFromDate,
			Long leaveToDate) {
		logger.info("LeaveUtil.getLeavePendingApproval()");
		return getLeavePendingApprovalDetailList(sapEndpointClient.getLeavePendingApprovalDetails(managerId))
				.parallelStream()
				.filter(e -> e.getLeaveFromDate().getTime() == leaveFromDate
						&& e.getLeaveToDate().getTime() == leaveToDate && e.getEmployeeId().equals(userId.substring(1)))
				.collect(Collectors.toList());
	}

}