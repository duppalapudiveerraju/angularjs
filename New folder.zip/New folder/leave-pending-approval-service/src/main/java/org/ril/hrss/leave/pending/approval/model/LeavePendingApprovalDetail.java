package org.ril.hrss.leave.pending.approval.model;

import java.util.Date;

import org.ril.hrss.msf.custom.serializer.SAPStringToDateSerializer;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(converter = LeavePendingApprovalDetailFilter.class)
public class LeavePendingApprovalDetail {

	private String attachDocId;
	private Date applyDate;
	private String leaveRequestId;
	private boolean slaBreached;
	private String employeeId;
	private String employeeName;
	private Date leaveFromDate;
	private Date leaveToDate;
	private String leaveDesc;
	private Double leaveNoOfDays;
	private String leaveRemark;

	public LeavePendingApprovalDetail() {
		super();
	}

	public LeavePendingApprovalDetail(String attachDocId, Date applyDate, String leaveRequestId, boolean slaBreached,
			String employeeId, String employeeName, Date leaveFromDate, Date leaveToDate, String leaveDesc,
			Double leaveNoOfDays, String leaveRemark) {
		super();
		this.attachDocId = attachDocId;
		this.applyDate = applyDate;
		this.leaveRequestId = leaveRequestId;
		this.slaBreached = slaBreached;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.leaveFromDate = leaveFromDate;
		this.leaveToDate = leaveToDate;
		this.leaveDesc = leaveDesc;
		this.leaveNoOfDays = leaveNoOfDays;
		this.leaveRemark = leaveRemark;
	}

	@JsonProperty("attachDocId")
	public String getAttachDocId() {
		return attachDocId;
	}

	@JsonProperty("ArcDocId")
	public void setAttachDocId(String attachDocId) {
		this.attachDocId = attachDocId;
	}

	@JsonProperty("applyDate")
	public Date getApplyDate() {
		return applyDate;
	}

	@JsonProperty("Ersda")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	@JsonProperty("leaveRequestId")
	public String getLeaveRequestId() {
		return leaveRequestId;
	}

	@JsonProperty("RequestId")
	public void setLeaveRequestId(String leaveRequestId) {
		this.leaveRequestId = leaveRequestId;
	}

	@JsonProperty("slaBreached")
	public boolean isSlaBreached() {
		return slaBreached;
	}

	public void setSlaBreached(boolean slaBreached) {
		this.slaBreached = slaBreached;
	}

	@JsonProperty("employeeId")
	public String getEmployeeId() {
		return employeeId;
	}

	@JsonProperty("EmpNo")
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@JsonProperty("employeeName")
	public String getEmployeeName() {
		return employeeName;
	}

	@JsonProperty("EmpName")
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	@JsonProperty("leaveFromDate")
	public Date getLeaveFromDate() {
		return leaveFromDate;
	}

	@JsonProperty("FromDate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setLeaveFromDate(Date leaveFromDate) {
		this.leaveFromDate = leaveFromDate;
	}

	@JsonProperty("leaveToDate")
	public Date getLeaveToDate() {
		return leaveToDate;
	}

	@JsonProperty("ToDate")
	@JsonDeserialize(converter = SAPStringToDateSerializer.class)
	public void setLeaveToDate(Date leaveToDate) {
		this.leaveToDate = leaveToDate;
	}

	@JsonProperty("leaveDesc")
	public String getLeaveDesc() {
		return leaveDesc;
	}

	@JsonProperty("LeaveDesc")
	public void setLeaveDesc(String leaveDesc) {
		this.leaveDesc = leaveDesc;
	}

	@JsonProperty("leaveNoOfDays")
	public Double getLeaveNoOfDays() {
		return leaveNoOfDays;
	}

	@JsonProperty("NoOfDays")
	public void setLeaveNoOfDays(Double leaveNoOfDays) {
		this.leaveNoOfDays = leaveNoOfDays;
	}

	@JsonProperty("leaveRemark")
	public String getLeaveRemark() {
		return leaveRemark;
	}

	@JsonProperty("Remarks")
	public void setLeaveRemark(String leaveRemark) {
		this.leaveRemark = leaveRemark;
	}

}