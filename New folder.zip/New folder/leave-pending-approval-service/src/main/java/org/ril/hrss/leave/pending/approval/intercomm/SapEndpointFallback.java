package org.ril.hrss.leave.pending.approval.intercomm;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.stereotype.Component;

@Component
public class SapEndpointFallback implements SapEndpointClient {

	@Override
	public String getLeavePendingApprovalDetails(String userId) {
		return HRSSConstantUtil.EMPTY_STRING;
	}

}
