package org.ril.hrss.cache.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.ril.hrss.cache.interfaces.CacheServiceRepo;
import org.ril.hrss.cache.model.TokenStore;
import org.ril.hrss.cache.repository.TokenStoreRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class CacheService implements CacheServiceRepo {

	protected static final Logger logger = Logger.getLogger(CacheService.class.getName());

	@Autowired
	private TokenStoreRepository repository;

	public CacheService() {
		super();
	}

	@Override
	public ResponseEntity<List<String>> findByUserId(String userId) {
		logger.info("CacheService.findByUserId()");
		TokenStore obj = repository.findOne(userId);
		if (obj != null) {
			return new ResponseEntity<>(obj.getSsoToken(), HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<List<TokenStore>> findAll() {
		logger.info("CacheService.findAll()");
		List<TokenStore> result = new ArrayList<>();
		repository.findAll().forEach(result::add);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> saveOrUpdate(TokenStore obj) {
		logger.info("CacheService.saveOrUpdate()");
		TokenStore actualObj = repository.findOne(obj.getUserId());
		if (actualObj == null) {
			repository.save(obj);
			return new ResponseEntity<>(obj.getUserId(), HttpStatus.CREATED);
		} else {
			BeanUtils.copyProperties(obj, actualObj);
			repository.save(actualObj);
			return new ResponseEntity<>(obj.getUserId(), HttpStatus.CREATED);
		}
	}

	@Override
	public ResponseEntity<Object> delete(String userId) {
		logger.info("CacheService.delete()");
		repository.delete(userId);
		if (repository.findOne(userId) == null) {
			return new ResponseEntity<>(HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

}