package org.ril.hrss.cache.model;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.validation.constraints.NotNull;

import org.ril.hrss.msf.util.HRSSConstantUtil;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.TimeToLive;

@RedisHash("TokenStore")
public class TokenStore implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@NotNull
	private String userId;
	
	@NotNull
	private List<String> ssoToken;
	
	@TimeToLive(unit = TimeUnit.MILLISECONDS)
	private Integer ttlMillis;

	public TokenStore() {
		super();
		this.ttlMillis = HRSSConstantUtil.REDIS_CACHE_TTL_MILLIS;
	}

	public TokenStore(String userId, List<String> ssoToken) {
		this();
		this.userId = userId;
		this.ssoToken = ssoToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getSsoToken() {
		return ssoToken;
	}

	public void setSsoToken(List<String> ssoToken) {
		this.ssoToken = ssoToken;
	}
	
	public Integer getTtlMillis() {
		return ttlMillis;
	}

	public void setTtlMillis(Integer ttlMillis) {
		this.ttlMillis = ttlMillis;
	}

	@Override
	public String toString() {
		return "TokenStore [userId=" + userId + ", ssoToken=" + ssoToken + ", ttlMillis=" + ttlMillis + "]";
	}

}