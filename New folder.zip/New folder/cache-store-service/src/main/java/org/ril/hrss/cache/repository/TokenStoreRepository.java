package org.ril.hrss.cache.repository;

import org.ril.hrss.cache.model.TokenStore;
import org.springframework.data.repository.CrudRepository;

public interface TokenStoreRepository extends CrudRepository<TokenStore, String> {

}
