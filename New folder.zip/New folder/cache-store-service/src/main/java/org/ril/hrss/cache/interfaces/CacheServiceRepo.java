package org.ril.hrss.cache.interfaces;

import java.util.List;

import org.ril.hrss.cache.model.TokenStore;
import org.springframework.http.ResponseEntity;

public interface CacheServiceRepo {
	
	public ResponseEntity<List<String>> findByUserId(String employeeId);
	
	public ResponseEntity<List<TokenStore>> findAll();
	
	public ResponseEntity<String> saveOrUpdate(TokenStore obj);
	
	public ResponseEntity<Object> delete(String employeeId);

}