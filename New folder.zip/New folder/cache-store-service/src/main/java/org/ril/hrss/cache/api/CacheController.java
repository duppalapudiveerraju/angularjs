package org.ril.hrss.cache.api;

import java.util.List;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.ril.hrss.cache.interfaces.CacheServiceRepo;
import org.ril.hrss.cache.model.TokenStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.client.ClientException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "Cache Store Details", description = "Operations pertaining to get Cache Store details")
public class CacheController {

	@Autowired
	private CacheServiceRepo cacheServiceRepo;

	protected static final Logger logger = Logger.getLogger(CacheController.class.getName());

	public CacheController() {
		super();
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	@ApiOperation(value = "Save Token into Cache", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully saved or updated"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<String> saveOrUpdate(@NotNull @RequestHeader("userId") String userId,
			@NotNull @RequestBody List<String> authToken) throws ClientException {
		logger.info("CacheController.saveOrUpdate()");
		return cacheServiceRepo.saveOrUpdate(new TokenStore(userId, authToken));
	}

	@RequestMapping(value = "/delete", method = RequestMethod.DELETE, produces = "application/json")
	@ApiOperation(value = "Delete Token from Cache", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully deleted"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> delete(@NotNull @RequestHeader("userId") String userId) throws ClientException {
		logger.info("CacheController.delete()");
		return cacheServiceRepo.delete(userId);
	}

	@RequestMapping(value = "/find", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Find specific Token in Cache", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully found token"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<List<String>> find(@NotNull @RequestHeader("userId") String userId) throws ClientException {
		logger.info("CacheController.find()");
		return cacheServiceRepo.findByUserId(userId);
	}

	@RequestMapping(value = "/findAll", method = RequestMethod.GET, produces = "application/json")
	@ApiOperation(value = "Find All Token in Cache", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully found all tokens"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<List<TokenStore>> findAll() throws ClientException {
		logger.info("CacheController.findAll()");
		return cacheServiceRepo.findAll();
	}

}